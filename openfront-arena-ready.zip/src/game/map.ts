import { geoEquirectangular, geoMercator, geoPath } from "d3-geo";
import { feature } from "topojson-client";
import type { Topology } from "topojson-specification";
import landTopology from "world-atlas/land-50m.json";

export const GRID_WIDTH = 640;
export const GRID_HEIGHT = 360;

export interface MapConfig {
  name: string;
  region: string;
  projection: "mercator" | "equirectangular";
  center: [number, number];
  longitude: number;
  latitude: number;
}

export const MAPS = {
  europe: {
    name: "Büyük Avrupa",
    region: "Atlas'tan Ural'a",
    projection: "mercator",
    center: [16, 48.5],
    longitude: 90,
    latitude: 52,
  },
  mediterranean: {
    name: "Akdeniz & Anadolu",
    region: "İmparatorluklar denizi",
    projection: "mercator",
    center: [19.5, 38.2],
    longitude: 70,
    latitude: 36,
  },
  western_europe: {
    name: "Batı Avrupa",
    region: "Feodal çekirdek",
    projection: "mercator",
    center: [4.5, 47.6],
    longitude: 46,
    latitude: 27,
  },
  eurasia: {
    name: "Avrasya",
    region: "Bozkırdan okyanusa",
    projection: "equirectangular",
    center: [46, 45],
    longitude: 150,
    latitude: 82,
  },
  world: {
    name: "Dünya",
    region: "Tüm kıtalar",
    projection: "equirectangular",
    center: [0, 12],
    longitude: 352,
    latitude: 162,
  },
} as const satisfies Record<string, MapConfig>;

export type MapId = keyof typeof MAPS;

// Terrain types:
// 0 = sea, 1 = plains (ova), 2 = steppe/arid (bozkır/çöl), 3 = forest/highland (orman/yayla), 4 = mountain (dağ)
export interface TerrainMap {
  id: MapId;
  width: number;
  height: number;
  land: Uint8Array;
  terrain: Uint8Array;
  texture: HTMLCanvasElement;
  landCount: number;
  waterways: Uint8Array;
  tradeableWater: Uint8Array;
  lonLatToCell: (lon: number, lat: number) => number | null;
}

const mapCache = new Map<MapId, TerrainMap>();
const topology = landTopology as unknown as Topology;
const landFeature = feature(topology, topology.objects.land);

function noise(x: number, y: number): number {
  const value = Math.sin(x * 127.1 + y * 311.7) * 43758.5453;
  return value - Math.floor(value);
}

function smoothNoise(x: number, y: number): number {
  const ix = Math.floor(x);
  const iy = Math.floor(y);
  const fx = (x - ix) ** 2 * (3 - 2 * (x - ix));
  const fy = (y - iy) ** 2 * (3 - 2 * (y - iy));
  const top = noise(ix, iy) * (1 - fx) + noise(ix + 1, iy) * fx;
  const bottom = noise(ix, iy + 1) * (1 - fx) + noise(ix + 1, iy + 1) * fx;
  return top * (1 - fy) + bottom * fy;
}

function region(
  lon: number,
  lat: number,
  centerLon: number,
  centerLat: number,
  radiusLon: number,
  radiusLat: number,
  angleDeg = 0,
): number {
  const rad = (angleDeg * Math.PI) / 180;
  const dx = lon - centerLon;
  const dy = lat - centerLat;
  const rx = (dx * Math.cos(rad) + dy * Math.sin(rad)) / radiusLon;
  const ry = (-dx * Math.sin(rad) + dy * Math.cos(rad)) / radiusLat;
  return Math.exp(-(rx * rx + ry * ry));
}

function terrainAt(lon: number, lat: number, x: number, y: number): number {
  const macro = smoothNoise(x / 11, y / 11) - 0.5;
  const meso = smoothNoise(x / 5.5, y / 5.5) - 0.5;
  const micro = smoothNoise(x / 2.8, y / 2.8) - 0.5;
  const ridge = 1 - Math.abs(smoothNoise(x / 4.2, y / 4.2) - 0.5) * 2;
  const variation = macro * 0.46 + meso * 0.34 + micro * 0.2;

  // Domain-warp coordinates so mountain ranges & plateaus look rugged, never oval
  const wLon = lon + macro * 4.4 + meso * 2.1;
  const wLat = lat + (smoothNoise((x + 31) / 10, (y + 17) / 10) - 0.5) * 2.9 + micro * 0.9;

  const mountains = Math.max(
    region(wLon, wLat, 10.2, 46.5, 5.0, 1.3, 14),  // Alpler
    region(wLon, wLat, 0.2, 42.7, 3.1, 0.7, -8),   // Pireneler
    region(wLon, wLat, 24.4, 46.7, 3.0, 1.8, -35), // Karpatlar
    region(wLon, wLat, 13.8, 42.6, 1.0, 2.7, -32), // Apeninler
    region(wLon, wLat, 20.5, 42.3, 2.4, 1.7, -28), // Dinar & Balkan Dağları
    region(wLon, wLat, 43.8, 42.3, 4.3, 1.15, -18),// Kafkaslar
    region(wLon, wLat, 37.5, 38.4, 4.6, 1.4, 12),  // Toroslar & Doğu Anadolu
    region(wLon, wLat, 11.2, 62.6, 2.3, 4.6, 28),  // İskandinav Dağları
    region(wLon, wLat, -4.6, 57.1, 1.5, 1.25, 20), // İskoç Yaylası
    region(wLon, wLat, -3.5, 33.8, 4.6, 0.95, 14), // Atlas Dağları
    region(wLon, wLat, 80, 31, 12, 4.2, -10),      // Himalaya Batı
    region(wLon, wLat, 95, 30, 13, 4.2, 10),       // Himalaya Doğu
    region(wLon, wLat, -74, -37, 4.2, 17, 4),      // And Güney
    region(wLon, wLat, -73, -15, 3.8, 16, -15),    // And Orta
    region(wLon, wLat, -119, 47, 7.5, 13, -22),    // Kayalık Dağları
  );

  const forests = Math.max(
    region(wLon, wLat, 9.5, 49.5, 5.4, 2.9, 10),   // Kara Orman / Germanya
    region(wLon, wLat, 23.0, 54.0, 8.5, 4.5, 12),  // Baltık / Litvanya Ormanları
    region(wLon, wLat, 36.0, 57.5, 11.5, 4.8, 8),  // Rus Orman Kuşağı
    region(wLon, wLat, 16.0, 61.5, 6.8, 4.2, 22),  // İsveç & Finlandiya Ormanları
    region(wLon, wLat, 1.5, 47.0, 4.5, 2.8, -10),  // Galya Ormanları
  );

  const arid = Math.max(
    region(wLon, wLat, -3, 25, 32, 12),            // Sahra Batı
    region(wLon, wLat, 27, 24, 30, 11),            // Sahra Doğu
    region(wLon, wLat, 47, 24, 18, 10),            // Arabistan
    region(wLon, wLat, -4.2, 39.8, 3.8, 2.1, 8),   // İber Yaylası
    region(wLon, wLat, 33.0, 39.2, 3.8, 1.3),      // Orta Anadolu Bozkırı
    region(wLon, wLat, 45.0, 47.5, 10.5, 3.8, 15), // Karadeniz-Hazar Bozkırı
    region(wLon, wLat, 89, 40, 23, 10),            // Orta Asya
    region(wLon, wLat, 133, -26, 21, 14),          // Avustralya
  );

  if (Math.abs(lat) > 70) return 4;
  const peakScore = mountains * (0.64 + ridge * 0.48) + variation * 0.48;
  if (peakScore > 0.56) return 4;
  if (peakScore > 0.35) return 3;
  if (arid + variation * 0.45 > 0.54) return 2;
  if (forests + variation * 0.48 > 0.49) return 3;
  if (variation > 0.24) return 3;
  return 1;
}

export function getTerrainMap(id: MapId): TerrainMap {
  const cached = mapCache.get(id);
  if (cached) return cached;

  const width = GRID_WIDTH;
  const height = GRID_HEIGHT;
  const detail = 3;
  const pixelWidth = width * detail;
  const pixelHeight = height * detail;
  const config = MAPS[id];

  const projection =
    config.projection === "mercator"
      ? (() => {
          const radLon = (config.longitude * Math.PI) / 180;
          const scale = (pixelWidth * 0.96) / radLon;
          return geoMercator()
            .center([config.center[0], config.center[1]])
            .scale(scale)
            .translate([pixelWidth / 2, pixelHeight / 2])
            .precision(0.12);
        })()
      : (() => {
          const scale = Math.min(
            (pixelWidth * 0.99) / ((config.longitude * Math.PI) / 180),
            (pixelHeight * 0.99) / ((config.latitude * Math.PI) / 180),
          );
          return geoEquirectangular()
            .center([config.center[0], config.center[1]])
            .scale(scale)
            .translate([pixelWidth / 2, pixelHeight / 2])
            .precision(0.12);
        })();

  const maskCanvas = document.createElement("canvas");
  maskCanvas.width = pixelWidth;
  maskCanvas.height = pixelHeight;
  const maskContext = maskCanvas.getContext("2d", { willReadFrequently: true })!;
  maskContext.fillStyle = "#ffffff";
  maskContext.beginPath();
  geoPath(projection, maskContext)(landFeature);
  maskContext.fill();
  const mask = maskContext.getImageData(0, 0, pixelWidth, pixelHeight).data;

  const land = new Uint8Array(width * height);
  const terrain = new Uint8Array(width * height);
  const waterways = new Uint8Array(width * height);
  let landCount = 0;

  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      let hits = 0;
      for (let dy = 0; dy < detail; dy++) {
        for (let dx = 0; dx < detail; dx++) {
          if (mask[((y * detail + dy) * pixelWidth + x * detail + dx) * 4 + 3] > 96) hits++;
        }
      }
      const index = y * width + x;
      if (hits >= 2) {
        land[index] = 1;
        const coords = projection.invert?.([(x + 0.5) * detail, (y + 0.5) * detail]);
        const lon = coords ? coords[0] : config.center[0];
        const lat = coords ? coords[1] : config.center[1];
        terrain[index] = terrainAt(lon, lat, x, y);
        landCount++;
      }
    }
  }

  // Şehir ölçeğinde su geçişleri: İstanbul Boğazı ve Süveyş Kanalı
  // gerçek coğrafi konumlarında, iki hücre genişliğinde açılır.
  const corridors: Array<{ id: MapId; segments: Array<Array<[number, number]>>; halfWidth: number }> = [
    {
      id: "europe",
      halfWidth: 1.25,
      segments: [
        [[28.98, 41.24], [29.05, 41.10], [29.12, 40.97], [29.18, 40.83], [29.26, 40.72]],
        [[32.30, 31.25], [32.34, 30.95], [32.38, 30.55], [32.42, 30.10], [32.55, 29.93]],
        [[26.15, 40.05], [26.35, 40.18], [26.55, 40.30], [26.75, 40.45], [27.00, 40.60], [27.50, 40.75], [28.20, 40.82], [28.70, 40.95]],
      ],
    },
    {
      id: "mediterranean",
      halfWidth: 1.2,
      segments: [
        [[28.98, 41.24], [29.05, 41.10], [29.12, 40.97], [29.18, 40.83], [29.26, 40.72]],
        [[32.30, 31.25], [32.34, 30.95], [32.38, 30.55], [32.42, 30.10], [32.55, 29.93]],
        [[26.15, 40.05], [26.35, 40.18], [26.55, 40.30], [26.75, 40.45], [27.00, 40.60], [27.50, 40.75], [28.20, 40.82], [28.70, 40.95]],
      ],
    },
    {
      id: "eurasia",
      halfWidth: 1.3,
      segments: [
        [[28.98, 41.24], [29.06, 41.08], [29.16, 40.90], [29.25, 40.72]],
        [[26.15, 40.05], [26.40, 40.22], [26.70, 40.42], [27.05, 40.62], [27.60, 40.78], [28.30, 40.90]],
      ],
    },
    {
      id: "world",
      halfWidth: 0.85,
      segments: [
        [[28.98, 41.24], [29.06, 41.08], [29.16, 40.90], [29.25, 40.72]],
        [[32.30, 31.25], [32.36, 30.85], [32.43, 30.30], [32.55, 29.93]],
        [[26.15, 40.05], [26.40, 40.22], [26.70, 40.42], [27.05, 40.62], [27.60, 40.78], [28.30, 40.90]],
      ],
    },
  ];

  for (const corridor of corridors) {
    if (corridor.id !== id) continue;
    const projectedSegments = corridor.segments
      .map((segment) =>
        segment
          .map(([lon, lat]) => projection([lon, lat]))
          .filter((point): point is [number, number] => !!point)
          .map(([px, py]) => [px / detail, py / detail] as [number, number]),
      )
      .filter((segment) => segment.length >= 2);

    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const cell = y * width + x;
        if (!land[cell]) continue;
        let distance = Infinity;
        for (const projected of projectedSegments) {
          for (let k = 0; k + 1 < projected.length; k++) {
            const [ax, ay] = projected[k];
            const [bx, by] = projected[k + 1];
            const vx = bx - ax;
            const vy = by - ay;
            const len2 = vx * vx + vy * vy || 1;
            const t = Math.max(0, Math.min(1, ((x - ax) * vx + (y - ay) * vy) / len2));
            const dx = x - (ax + t * vx);
            const dy = y - (ay + t * vy);
            distance = Math.min(distance, dx * dx + dy * dy);
          }
        }
        if (distance <= corridor.halfWidth * corridor.halfWidth) {
          land[cell] = 0;
          landCount--;
          waterways[cell] = 1;
        }
      }
    }
  }

  // Reject inland lakes and closed basins as trade ports. Only connected seas
  // large enough to support genuine routes count as navigable trade water.
  const tradeableWater = new Uint8Array(width * height);
  const visitedWater = new Uint8Array(width * height);
  const waterQueue = new Int32Array(width * height);
  for (let start = 0; start < land.length; start++) {
    if (land[start] || visitedWater[start]) continue;
    let head = 0;
    let tail = 0;
    waterQueue[tail++] = start;
    visitedWater[start] = 1;
    while (head < tail) {
      const current = waterQueue[head++];
      for (const next of cellNeighbors8(current, width, height)) {
        if (land[next] || visitedWater[next]) continue;
        visitedWater[next] = 1;
        waterQueue[tail++] = next;
      }
    }
    if (tail >= 450) {
      for (let i = 0; i < tail; i++) tradeableWater[waterQueue[i]] = 1;
    }
  }

  const texture = document.createElement("canvas");
  texture.width = pixelWidth;
  texture.height = pixelHeight;
  const textureContext = texture.getContext("2d")!;
  const pixels = textureContext.createImageData(pixelWidth, pixelHeight);
  const palette: Record<number, [number, number, number]> = {
    1: [173, 195, 134],
    2: [215, 198, 148],
    3: [142, 166, 114],
    4: [228, 222, 204],
  };

  for (let py = 0; py < pixelHeight; py++) {
    for (let px = 0; px < pixelWidth; px++) {
      const offset = (py * pixelWidth + px) * 4;
      const cx = Math.floor(px / detail);
      const cy = Math.floor(py / detail);
      const cell = cy * width + cx;
      const carved = waterways[cell] === 1;
      const onLand = mask[offset + 3] > 96 && !carved;

      let coastalWater = false;
      let coastalLand = false;
      if (!onLand) {
        for (let oy = -2; oy <= 2 && !coastalWater; oy += 2) {
          for (let ox = -2; ox <= 2; ox += 2) {
            const nx = px + ox;
            const ny = py + oy;
            if (nx >= 0 && nx < pixelWidth && ny >= 0 && ny < pixelHeight) {
              const ncell = Math.floor(ny / detail) * width + Math.floor(nx / detail);
              if (mask[(ny * pixelWidth + nx) * 4 + 3] > 96 && !waterways[ncell]) {
                coastalWater = true;
                break;
              }
            }
          }
        }
      } else {
        for (let oy = -1; oy <= 1 && !coastalLand; oy++) {
          for (let ox = -1; ox <= 1; ox++) {
            const nx = px + ox;
            const ny = py + oy;
            if (nx >= 0 && nx < pixelWidth && ny >= 0 && ny < pixelHeight) {
              const ncell = Math.floor(ny / detail) * width + Math.floor(nx / detail);
              if (mask[(ny * pixelWidth + nx) * 4 + 3] <= 96 || waterways[ncell]) {
                coastalLand = true;
                break;
              }
            }
          }
        }
      }

      const variation = (noise(px, py) - 0.5) * 20 + Math.sin(px * 0.045 + py * 0.065) * 4;
      const base = onLand
        ? palette[terrain[cell] || 1]
        : coastalWater
          ? [70, 134, 174]
          : [48, 108, 149];

      let tint = onLand ? variation : variation * 0.28 + Math.sin(py * 0.14) * 1.4;
      if (coastalLand) tint -= 18;

      pixels.data[offset] = Math.max(0, Math.min(255, base[0] + tint));
      pixels.data[offset + 1] = Math.max(0, Math.min(255, base[1] + tint));
      pixels.data[offset + 2] = Math.max(0, Math.min(255, base[2] + tint));
      pixels.data[offset + 3] = 255;
    }
  }
  textureContext.putImageData(pixels, 0, 0);

  const lonLatToCell = (lon: number, lat: number): number | null => {
    const pt = projection([lon, lat]);
    if (!pt) return null;
    const gx = Math.round(pt[0] / detail);
    const gy = Math.round(pt[1] / detail);
    if (gx < 5 || gx >= width - 5 || gy < 5 || gy >= height - 5) return null;
    for (let r = 0; r <= 9; r++) {
      for (let dy = -r; dy <= r; dy++) {
        for (let dx = -r; dx <= r; dx++) {
          const x = gx + dx;
          const y = gy + dy;
          if (x < 5 || x >= width - 5 || y < 5 || y >= height - 5) continue;
          const idx = y * width + x;
          if (land[idx] && terrain[idx] !== 4) return idx;
        }
      }
    }
    return null;
  };

  const result: TerrainMap = {
    id,
    width,
    height,
    land,
    terrain,
    texture,
    landCount,
    waterways,
    tradeableWater,
    lonLatToCell,
  };
  mapCache.set(id, result);
  return result;
}

export function cellNeighbors(index: number, width = GRID_WIDTH, height = GRID_HEIGHT): number[] {
  const x = index % width;
  const y = Math.floor(index / width);
  const neighbors: number[] = [];
  if (x > 0) neighbors.push(index - 1);
  if (x < width - 1) neighbors.push(index + 1);
  if (y > 0) neighbors.push(index - width);
  if (y < height - 1) neighbors.push(index + width);
  return neighbors;
}

export function cellNeighbors8(index: number, width = GRID_WIDTH, height = GRID_HEIGHT): number[] {
  const x = index % width;
  const y = Math.floor(index / width);
  const neighbors: number[] = [];
  for (let dy = -1; dy <= 1; dy++) {
    for (let dx = -1; dx <= 1; dx++) {
      if (dx === 0 && dy === 0) continue;
      const nx = x + dx;
      const ny = y + dy;
      if (nx >= 0 && nx < width && ny >= 0 && ny < height) {
        neighbors.push(ny * width + nx);
      }
    }
  }
  return neighbors;
}
