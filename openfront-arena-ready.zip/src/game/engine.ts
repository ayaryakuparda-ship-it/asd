import { cellNeighbors, cellNeighbors8, type TerrainMap } from "./map";

export const PLAYER_ID = 1;
export const STEP_SECONDS = 0.078;

export const BUILDINGS = {
  castle: {
    name: "Kale",
    cost: 1500,
    description: "Sur ve garnizonla bölgeyi korur. Seviyesi yükseltilebilir.",
  },
  barracks: {
    name: "Kışla",
    cost: 1050,
    description: "Yakındaki kasabayla kapasite sağlar; piyadeyi zamanla yerel garnizonda eğitir.",
  },
  town: {
    name: "Kasaba",
    cost: 1250,
    description: "Ordu kapasitesini +8.500 artırır ve düşük vergi geliri sağlar.",
  },
  market: {
    name: "Pazar",
    cost: 1350,
    description: "Kasaba, kale, kışla ve limanlar arasında kervan yolları kurar; her duraktan karşılıklı gelir.",
  },
  port: {
    name: "Liman",
    cost: 1200,
    description: "Açık denize bağlı kıyılardan otomatik ticaret gemileri üretir ve çıkarma sağlar.",
  },
  siegeworks: {
    name: "Kuşatma Atölyesi",
    cost: 2500,
    description: "Kuşatma gücünü artırır; mancınık bombardımanı açar.",
  },
} as const;

export type BuildingType = keyof typeof BUILDINGS;

export const BUILDING_DETAILS: Record<BuildingType, { short: string; details: string[] }> = {
  castle: {
    short: "Kale",
    details: [
      "+1.800 asker kapasitesi, sabit 1.100 sur",
      "Kale seviyesi geçici olarak kapalı · Savaş sırasında yeni kale kurulamaz",
      "İkmal menzili: 19 birim (her bölgeye ayrı kale gerekir)",
      "Koruma alanındaki topraklar, kale düşmeden alınamaz",
      "Normal kaleler arası en az 16; ileri kale 10 birim ve sınıra 6 birim yakın olmalı",
    ],
  },
  barracks: {
    short: "Kışla",
    details: [
      "Seviye başına +4.200 asker kapasitesi",
      "1 seviye: 700 ◆ → 1.200 piyade / 11 sn · 5 seviye: ≈4.320 piyade / 4 sn",
      "Toplam kışla seviyesi arttıkça eğitim hem daha kalabalık hem daha hızlı olur",
      "Aynı kışlada eşzamanlı emir = seviye × 2 · garnizon kapasitesi = seviye × 4.800",
      "24 birim içinde kasaba gerekir. Bölge başına kışla sayısı sınırsız",
    ],
  },
  town: {
    short: "Kasaba",
    details: [
      "Seviye başına +8.500 asker kapasitesi",
      "Seviye başına +4,3 altın/sn vergi geliri",
      "Kışlaların kurulabilmesi için gereklidir. Aynı yere basarak seviyesi artar",
    ],
  },
  market: {
    short: "Pazar",
    details: [
      "Seviye başına +8,6 altın/sn vergi geliri",
      "Kasaba, kale, kışla ve limanlara düzenli kervan gönderir; her durakta iki taraf da kazanır",
      "Kervan menzili seviyeyle artar: 23 + seviye × 7 birim. Savaşta olmadığın komşuların iç yapılarına da gidebilir",
      "Seviye yükseldikçe daha sık kervan ve daha yüksek kargo",
    ],
  },
  port: {
    short: "Liman",
    details: [
      "Seviye başına +900 asker kapasitesi",
      "Aynı limana tekrar bas: Sv.5'e kadar. Seviye ticaret gemisi üretimini artırır",
      "Gelir liman mesafesine göre sigmoid artar (300 birim civarı kırılım). Liman seviyesi ek bonus verir",
      "Kargo hedefe vardığında KAYNAK ve HEDEF limanın sahibi de kazanır",
      "Bu sürümde sadece ticaret gemileri vardır; savaş gemileri geçici olarak devre dışı",
      "Liman yalnızca açık denize bağlı kıyılara kurulur · Çıkarma 700 ◆",
    ],
  },
  siegeworks: {
    short: "Atölye",
    details: [
      "Kuşatmada sur hasarı seviye başına +%35 (en çok +%85)",
      "Mancınık bombardımanı: 1.400 ◆, sura 320 + 90 × toplam seviye hasar",
      "Aynı atölyeye tekrar basarak seviye yükseltilebilir",
    ],
  },
};
export type GamePhase = "spawn" | "playing" | "won" | "lost";
export type Difficulty = "easy" | "normal" | "hard";
export type RelationStatus = "peace" | "war" | "truce" | "alliance";
export type CommanderStance = "idle" | "march" | "battle" | "siege" | "retreat" | "embarked";

export interface Commander {
  x: number;
  y: number;
  targetX: number | null;
  targetY: number | null;
  route: number[];
  army: number;
  stance: CommanderStance;
  engagedWith: number | null;
  siegingCastle: number | null;
  autoSiege: boolean;
  retreatTicks: number;
  beachheadTicks: number;
  siegeWeapons: number;
  regroupTicks: number;
}

export interface Building {
  type: BuildingType;
  owner: number;
  level: number;
  wallHp: number;
  maxWallHp: number;
  garrison: number;
}

export interface BattleDice {
  aId: number;
  bId: number;
  aDice: [number, number];
  bDice: [number, number];
  totalA: number;
  totalB: number;
  swing: number;
}

export interface Faction {
  id: number;
  name: string;
  color: string;
  botKind?: "major" | "minor";
  reserveTroops: number;
  gold: number;
  land: number;
  tiles: Set<number>;
  buildings: Record<BuildingType, number>;
  buildingLevels: Record<BuildingType, number>;
  commander: Commander;
  mobilizationRatio: number;
  warCooldownUntil: number;
  peaceOfferFromPlayerCooldown: number;
  exhaustionUntil: number;
  tradeLedger: Array<{ tick: number; amount: number }>;
}

export interface Relation {
  status: RelationStatus;
  sinceTick: number;
  truceUntil: number;
  warStartTick: number;
  warLossesA: number;
  warLossesB: number;
}

export interface DiplomaticOffer {
  id: number;
  fromId: number;
  fromName: string;
  fromColor: string;
  type: "peace" | "alliance";
  expiresAtTick: number;
}

export interface TrainingOrder {
  id: number;
  owner: number;
  buildingIndex: number;
  amount: number;
  remainingTicks: number;
  totalTicks: number;
}

export interface TradeShip {
  id: number;
  owner: number;
  fromPort: number;
  toPort: number;
  path: number[];
  pathProgress: number;
  direction: 1 | -1;
  distance: number;
  cargoValue: number;
  hp: number;
  status: "outbound" | "returning" | "captured";
  x: number;
  y: number;
  heading: number;
  speed: number;
  laneOffset: number;
  capturedFrom?: number;
  capturedBy?: number;
}

export interface Landing {
  from: number;
  target: number;
  owner: number;
  army: number;
  finalTarget: number;
  path: number[];
  pathProgress: number;
  x: number;
  y: number;
  heading: number;
}

export interface Caravan {
  id: number;
  owner: number;
  fromMarket: number;
  toCell: number;
  path: number[];
  pathProgress: number;
  direction: 1 | -1;
  x: number;
  y: number;
  heading: number;
  cargoValue: number;
  speed: number;
  status: "outbound" | "returning";
  done: boolean;
}

export interface GameEffect {
  index: number;
  x: number;
  y: number;
  started: number;
  type: "bombard" | "landing" | "battle" | "siege_fall" | "war" | "gold";
  amount?: number;
  mine?: boolean;
}

export interface ActiveBattleView {
  attackerId: number;
  defenderId: number;
  attackerName: string;
  defenderName: string;
  attackerArmy: number;
  defenderArmy: number;
  x: number;
  y: number;
}

export interface ActiveSiegeView {
  castleIndex: number;
  attackerId: number;
  defenderId: number;
  attackerName: string;
  defenderName: string;
  level: number;
  wallHp: number;
  maxWallHp: number;
  attackerArmy: number;
}

export interface GameNotification {
  id: number;
  kind: "peace_offer" | "alliance_offer" | "alliance_broken" | "trade_lost" | "trade_captured" | "war" | "info";
  title: string;
  message: string;
  fromId?: number;
  fromName?: string;
  fromColor?: string;
  offerId?: number;
  actionable: boolean;
  createdAt: number;
  expiresAtTick: number;
}

export interface PendingLanding {
  id: number;
  from: number;
  target: number;
  owner: number;
  army: number;
  finalTarget: number;
  path: number[];
  rallyTicks: number;
  totalRallyTicks: number;
  startX: number;
  startY: number;
}

export interface GameState {
  map: TerrainMap;
  owners: Int16Array;
  factions: Faction[];
  buildings: Map<number, Building>;
  relations: Map<string, Relation>;
  offers: DiplomaticOffer[];
  trainingOrders: TrainingOrder[];
  tradeShips: TradeShip[];
  caravans: Caravan[];
  roads: Map<string, number[]>;
  landings: Landing[];
  pendingLandings: PendingLanding[];
  notifications: GameNotification[];
  seaRouteCache: Map<string, number[] | null>;
  tradeBlock: Map<string, number>;
  nextNotificationId: number;
  autoExpand: boolean;
  lastBattleDice: BattleDice | null;
  nextShipId: number;
  effects: GameEffect[];
  phase: GamePhase;
  difficulty: Difficulty;
  tick: number;
  revision: number;
  attackRatio: number;
  selected: number | null;
  lastEvent: string;
  preview: boolean;
}

export interface FactionSummary {
  id: number;
  name: string;
  color: string;
  botKind?: "major" | "minor";
  land: number;
  percent: number;
  totalTroops: number;
  fieldArmy: number;
  castles: number;
  relation: RelationStatus;
  truceRemaining: number;
}

export interface GameSnapshot {
  phase: GamePhase;
  tick: number;
  totalTroops: number;
  reserveTroops: number;
  fieldArmy: number;
  capacity: number;
  troopRatePerSec: number;
  gold: number;
  goldRatePerSec: number;
  land: number;
  percent: number;
  attackRatio: number;
  commanderStance: CommanderStance;
  engagedEnemyName: string | null;
  siegingInfo: {
    wallHp: number;
    maxWallHp: number;
    level: number;
    ownerName: string;
    ownerColor: string;
    attackerArmy: number;
    defenderArmy: number;
  } | null;
  lastEvent: string;
  recruitCost: number;
  recruitAmount: number;
  recruitTicks: number;
  trainingOrders: Array<{ buildingIndex: number; amount: number; remainingTicks: number; totalTicks: number }>;
  queuedTroops: number;
  tradeShips: number;
  caravans: number;
  tradeRoutes: number;
  tradeIncomePerMin: number;
  autoExpand: boolean;
  notifications: GameNotification[];
  exhaustionRemaining: number;
  siegeWeapons: number;
  regroupRemaining: number;
  buildingLevels: Record<BuildingType, number>;
  battleDice: BattleDice | null;
  economy: Array<{ label: string; perSec: number }>;
  capacityBreakdown: Array<{ label: string; value: number }>;
  factions: FactionSummary[];
  buildings: Record<BuildingType, number>;
  offers: DiplomaticOffer[];
  activeWarsCount: number;
}

// 1. Tür Bot: Tarihi Büyük Devletler (Gerçek coğrafi koordinatlarında ve biraz daha güçlü başlar)
const HISTORICAL_POWERS: Array<{ name: string; lon: number; lat: number; color: string }> = [
  { name: "İngiltere", lon: -1.3, lat: 52.3, color: "#cf5e52" },
  { name: "Fransa Krallığı", lon: 2.3, lat: 47.6, color: "#4c96b0" },
  { name: "Kutsal Roma (Almanya)", lon: 10.4, lat: 50.8, color: "#d89c46" },
  { name: "Moskova Knezliği (Rusya)", lon: 37.6, lat: 55.7, color: "#69a864" },
  { name: "Kiev Knezliği", lon: 30.5, lat: 50.4, color: "#91a852" },
  { name: "Lehistan", lon: 19.4, lat: 52.1, color: "#cf5d80" },
  { name: "Bizans", lon: 27.6, lat: 41.2, color: "#9d68b9" },
  { name: "Anadolu Selçuklu", lon: 32.8, lat: 38.9, color: "#58a1ab" },
  { name: "Kastilya", lon: -3.7, lat: 40.4, color: "#d3a64a" },
  { name: "Venedik", lon: 12.3, lat: 45.4, color: "#7484c4" },
  { name: "Macaristan", lon: 19.1, lat: 47.2, color: "#cc7449" },
  { name: "Memlük", lon: 31.2, lat: 30.2, color: "#b48653" },
  { name: "İsveç", lon: 15.8, lat: 59.3, color: "#65a08c" },
  { name: "Altın Orda", lon: 45.8, lat: 48.6, color: "#969354" },
  { name: "Napoli", lon: 14.3, lat: 40.9, color: "#ad88be" },
  { name: "İskoçya", lon: -3.9, lat: 56.4, color: "#698bb0" },
  { name: "Bulgar Çarlığı", lon: 25.5, lat: 43.1, color: "#6da464" },
  { name: "Danimarka", lon: 9.8, lat: 56.1, color: "#5a9a94" },
  { name: "Norveç", lon: 10.6, lat: 60.4, color: "#b77191" },
  { name: "Portekiz", lon: -8.4, lat: 39.6, color: "#867ab7" },
  { name: "Merînîler (Fas)", lon: -5.0, lat: 33.9, color: "#c68b67" },
  { name: "İlhanlı (İran)", lon: 51.4, lat: 35.7, color: "#c3735b" },
  { name: "Delhi Sultanlığı", lon: 77.2, lat: 28.6, color: "#6f9f7d" },
  { name: "Yuan (Çin)", lon: 114.0, lat: 34.5, color: "#b57272" },
];

// 2. Tür Bot: Rastgele bölgelerde dengeli dağılan Bağımsız Beylikler / Dükalıklar
const RANDOM_MINOR_NAMES = [
  "Burgonya", "Aragon", "Ceneviz", "Litvanya", "Bavyera", "Sırp Beyliği",
  "Eflak", "Gürcistan", "İrlanda", "Endülüs", "Navarra", "Bohemya",
  "Saksonya", "Trabzon", "Kırım", "Epir", "Mora", "Karaman",
  "Candar", "Toskana", "Flandra", "Novgorod", "Livonya", "Kilikya",
];

const MEDIEVAL_NAMES = [
  ...HISTORICAL_POWERS.map((p) => p.name),
  ...RANDOM_MINOR_NAMES,
];

const FACTION_COLORS = [
  "#cf5e52", "#d89c46", "#9d68b9", "#69a864", "#cf5d80", "#d3a64a", "#58a1ab",
  "#969354", "#cc7449", "#7484c4", "#b48653", "#be5555", "#65a08c", "#ad88be",
  "#91a852", "#b77191", "#4c96b0", "#a69253", "#c3735b", "#6da464", "#867ab7",
  "#c68b67", "#6f9f7d", "#b57272", "#698bb0", "#a8984c", "#9571a7", "#5a9a94",
];

export const MAX_STRUCTURE_LEVEL = 5;
const WALL_TABLE = [1100, 4200, 8200, 14500, 24000];

export function castleMaxWall(_level: number): number {
  return WALL_TABLE[0];
}

export function castleGuardRadius(_level: number): number {
  return 5;
}

export function castleDomainRadius(_level: number): number {
  return 7;
}

export function castleSupplyRadius(_level: number): number {
  return 19;
}

export const CASTLE_BUILD_SPACING = 16;
export const FORWARD_FORT_SPACING = 10;
export const MAX_ENCLOSED_POCKET = 42;

function rollD6(): number {
  return 1 + Math.floor(Math.random() * 6);
}

// OpenFront'taki gibi her yapı türü kendi fiyat merdivenine sahiptir.
// Ekonomik yapılar ikiye katlanır; kaleler stratejik olduğu için ×1,6 artar.
export function getBuildingCost(type: BuildingType, owned: number): number {
  // Yeni yapılar için fiyat merdiveni yumuşak tutulur; seviye yığmak pahalıdır.
  const factor = type === "castle"
    ? Math.pow(1.4, Math.min(owned, 4))
    : Math.pow(1.55, Math.min(owned, 3));
  return Math.round(BUILDINGS[type].cost * factor);
}

export function getStackedUpgradeCost(type: BuildingType, level: number, owned: number): number {
  const base = BUILDINGS[type].cost;
  const levelCost = 2.2 + Math.pow(Math.max(0, level - 1), 1.65) * 1.8;
  const portfolioCost = 1 + Math.max(0, owned - 1) * 0.4;
  return Math.round(base * levelCost * portfolioCost);
}

const UPGRADE_BASE: Partial<Record<BuildingType, number>> = {
  barracks: 1000,
  town: 1100,
  market: 1100,
  port: 1000,
  siegeworks: 1800,
};

export function upgradeCost(building: Building): number | null {
  if (building.type === "castle") return null;
  const base = UPGRADE_BASE[building.type];
  if (!base || building.level >= MAX_STRUCTURE_LEVEL) return null;
  const levelCost = 2.3 + Math.pow(Math.max(0, building.level - 1), 1.7) * 2.05;
  return Math.round(BUILDINGS[building.type].cost * levelCost * 1.35);
}

export function repairCastleCost(building: Building): number {
  const missing = Math.max(0, building.maxWallHp - building.wallHp);
  return Math.max(150, Math.ceil(missing * 0.42));
}

function emptyBuildings(): Record<BuildingType, number> {
  return { castle: 0, barracks: 0, town: 0, market: 0, port: 0, siegeworks: 0 };
}

function emptyLevels(): Record<BuildingType, number> {
  return emptyBuildings();
}

function makeFaction(id: number, name: string, color: string, botKind?: "major" | "minor"): Faction {
  const isMajor = botKind === "major";
  return {
    id,
    name,
    color,
    botKind,
    reserveTroops: isMajor ? 4600 : 3200,
    gold: isMajor ? 3300 : 2100,
    land: 0,
    tiles: new Set(),
    buildings: emptyBuildings(),
    buildingLevels: emptyLevels(),
    commander: {
      x: 0,
      y: 0,
      targetX: null,
      targetY: null,
      route: [],
      army: isMajor ? 6200 : 4400,
      stance: "idle",
      engagedWith: null,
      siegingCastle: null,
      autoSiege: false,
      retreatTicks: 0,
      beachheadTicks: 0,
      siegeWeapons: 0,
      regroupTicks: 0,
    },
    mobilizationRatio: 55,
    warCooldownUntil: 110,
    peaceOfferFromPlayerCooldown: 0,
    exhaustionUntil: 0,
    tradeLedger: [],
  };
}

function relationKey(a: number, b: number): string {
  return a < b ? `${a}:${b}` : `${b}:${a}`;
}

function pushNotification(
  game: GameState,
  data: Omit<GameNotification, "id" | "createdAt" | "expiresAtTick">,
  ttl = 240,
): GameNotification {
  const notification: GameNotification = {
    ...data,
    id: game.nextNotificationId++,
    createdAt: game.tick,
    expiresAtTick: game.tick + ttl,
  };
  game.notifications.push(notification);
  return notification;
}

export function pushDiplomaticOffer(
  game: GameState,
  fromId: number,
  type: "peace" | "alliance",
  ttl = 160,
): void {
  const from = game.factions[fromId - 1];
  if (!from || !from.land) return;
  const offerId = game.nextNotificationId;
  const offer: DiplomaticOffer = {
    id: offerId,
    fromId,
    fromName: from.name,
    fromColor: from.color,
    type,
    expiresAtTick: game.tick + ttl,
  };
  game.offers.push(offer);
  pushNotification(
    game,
    {
      kind: type === "alliance" ? "alliance_offer" : "peace_offer",
      title: type === "alliance" ? "İttifak teklifi" : "Barış teklifi",
      message:
        type === "alliance"
          ? `${from.name} seninle ittifak kurmak istiyor.`
          : `${from.name} savaşı bitirmek için ateşkes istiyor.`,
      fromId,
      fromName: from.name,
      fromColor: from.color,
      offerId,
      actionable: true,
    },
    ttl,
  );
}

export function dismissNotification(game: GameState, id: number): void {
  game.notifications = game.notifications.filter((notification) => notification.id !== id);
}

export function respondToNotification(
  game: GameState,
  id: number,
  action: "accept" | "reject" | "dismiss",
): void {
  const notification = game.notifications.find((item) => item.id === id);
  if (!notification) return;
  game.notifications = game.notifications.filter((item) => item.id !== id);
  if (action === "dismiss" || notification.offerId === undefined) return;
  respondToOffer(game, notification.offerId, action === "accept");
}

export function getRelation(game: GameState, a: number, b: number): Relation {
  if (a === b || a <= 0 || b <= 0) {
    return { status: "peace", sinceTick: 0, truceUntil: 0, warStartTick: 0, warLossesA: 0, warLossesB: 0 };
  }
  const key = relationKey(a, b);
  let rel = game.relations.get(key);
  if (!rel) {
    rel = { status: "peace", sinceTick: 0, truceUntil: 0, warStartTick: 0, warLossesA: 0, warLossesB: 0 };
    game.relations.set(key, rel);
  }
  return rel;
}

function setRelation(game: GameState, a: number, b: number, status: RelationStatus, truceDuration = 0): void {
  const key = relationKey(a, b);
  const current = getRelation(game, a, b);
  current.status = status;
  current.sinceTick = game.tick;
  current.truceUntil = status === "truce" ? game.tick + truceDuration : 0;
  // Ticaret yalnızca savaştaki çift için kesilir; barış/ateşkes/ittifak yeniden açar.
  if (status === "war") suspendTrade(game, a, b);
  else game.tradeBlock.delete(relationKey(a, b));
  if (status === "war") {
    current.warStartTick = game.tick;
    current.warLossesA = 0;
    current.warLossesB = 0;
  }
  game.relations.set(key, current);
  game.revision++;
}

export function createGame(map: TerrainMap, name: string, color: string, difficulty: Difficulty): GameState {
  return {
    map,
    owners: new Int16Array(map.width * map.height),
    factions: [makeFaction(PLAYER_ID, name.trim() || "Anadolu Beyliği", color)],
    buildings: new Map(),
    relations: new Map(),
    offers: [],
    trainingOrders: [],
    tradeShips: [],
    caravans: [],
    roads: new Map(),
    landings: [],
    pendingLandings: [],
    notifications: [],
    seaRouteCache: new Map(),
    tradeBlock: new Map(),
    nextNotificationId: 1,
    autoExpand: true,
    lastBattleDice: null,
    nextShipId: 1,
    effects: [],
    phase: "spawn",
    difficulty,
    tick: 0,
    revision: 0,
    attackRatio: 55,
    selected: null,
    lastEvent: "Başlangıç kaleni kuracağın toprağı seç.",
    preview: false,
  };
}

function claimCell(game: GameState, index: number, owner: number): void {
  const previous = game.owners[index];
  if (previous === owner || !game.map.land[index]) return;

  const structure = game.buildings.get(index);
  if (structure?.type === "market") {
    for (const key of [...game.roads.keys()]) {
      if (key.startsWith(`${index}:`) || key.endsWith(`:${index}`)) game.roads.delete(key);
    }
  }
  if (structure && previous > 0) {
    const previousFaction = game.factions[previous - 1];
    previousFaction.buildings[structure.type] = Math.max(0, previousFaction.buildings[structure.type] - 1);
    previousFaction.buildingLevels[structure.type] = Math.max(0, previousFaction.buildingLevels[structure.type] - structure.level);
    previousFaction.reserveTroops = Math.max(0, previousFaction.reserveTroops - (structure.garrison || 0));
    structure.garrison = 0;
    game.trainingOrders = game.trainingOrders.filter((order) => order.buildingIndex !== index);
  }
  if (previous > 0) {
    const prevFaction = game.factions[previous - 1];
    prevFaction.land--;
    prevFaction.tiles.delete(index);
  }

  game.owners[index] = owner;
  if (owner > 0) {
    const faction = game.factions[owner - 1];
    faction.land++;
    faction.tiles.add(index);
  }

  if (structure) {
    if (owner > 0) {
      structure.owner = owner;
      const newOwner = game.factions[owner - 1];
      newOwner.buildings[structure.type]++;
      newOwner.buildingLevels[structure.type] += structure.level;
      if (structure.type === "castle") {
        structure.wallHp = Math.max(Math.floor(structure.maxWallHp * 0.35), structure.wallHp);
      }
    } else {
      game.buildings.delete(index);
    }
  }
  game.revision++;
}

function claimCircle(game: GameState, center: number, radius: number, owner: number): void {
  const cx = center % game.map.width;
  const cy = Math.floor(center / game.map.width);
  for (let dy = -radius; dy <= radius; dy++) {
    for (let dx = -radius; dx <= radius; dx++) {
      if (dx * dx + dy * dy > radius * radius + 0.6) continue;
      const x = cx + dx;
      const y = cy + dy;
      if (x < 0 || x >= game.map.width || y < 0 || y >= game.map.height) continue;
      const index = y * game.map.width + x;
      if (game.owners[index] === 0 && game.map.land[index]) claimCell(game, index, owner);
    }
  }
}

function placeInitialRealm(game: GameState, faction: Faction, center: number): void {
  const isMajor = faction.botKind === "major";
  claimCircle(game, center, isMajor ? 4 : 3, faction.id);
  const cx = center % game.map.width;
  const cy = Math.floor(center / game.map.width);
  faction.commander.x = cx;
  faction.commander.y = cy;

  const castleWall = castleMaxWall(1);
  game.buildings.set(center, {
    type: "castle",
    owner: faction.id,
    level: 1,
    wallHp: castleWall,
    maxWallHp: castleWall,
    garrison: 0,
  });
  faction.buildings.castle++;
  faction.buildingLevels.castle++;

  const neighbors = cellNeighbors8(center, game.map.width, game.map.height).filter(
    (cell) => game.owners[cell] === faction.id && !game.buildings.has(cell),
  );
  const barracksCell = neighbors[0];
  if (barracksCell !== undefined) {
    game.buildings.set(barracksCell, {
      type: "barracks",
      owner: faction.id,
      level: 1,
      wallHp: 0,
      maxWallHp: 0,
      garrison: faction.reserveTroops,
    });
    faction.buildings.barracks++;
    faction.buildingLevels.barracks++;
  }
  // Tarihi Büyük Devletler başkentlerinde ek bir Kasaba ile biraz daha güçlü başlar
  if (isMajor && neighbors[1] !== undefined) {
    game.buildings.set(neighbors[1], {
      type: "town",
      owner: faction.id,
      level: 1,
      wallHp: 0,
      maxWallHp: 0,
      garrison: 0,
    });
    faction.buildings.town++;
    faction.buildingLevels.town++;
  }
  game.revision++;
}

export function spawnPlayer(game: GameState, index: number, botCount: number): boolean {
  if (game.phase !== "spawn" || !game.map.land[index]) return false;
  const player = game.factions[0];
  player.mobilizationRatio = game.attackRatio;
  placeInitialRealm(game, player, index);
  if (player.land === 0) return false;

  const seeds: number[] = [index];
  const usedNames = new Set<string>([player.name]);

  // 1. TÜR BOT: Tarihi Büyük Devletler — gerçek coğrafi konumlarında ve biraz daha güçlü başlar
  const maxMajors = Math.min(HISTORICAL_POWERS.length, Math.ceil(botCount * 0.6));
  for (const power of HISTORICAL_POWERS) {
    if (game.factions.length >= maxMajors + 1) break;
    if (usedNames.has(power.name)) continue;
    const cell = game.map.lonLatToCell(power.lon, power.lat);
    if (cell === null || game.owners[cell] !== 0) continue;
    const x = cell % game.map.width;
    const y = Math.floor(cell / game.map.width);
    const farEnough = seeds.every((seed) => {
      const dx = x - (seed % game.map.width);
      const dy = y - Math.floor(seed / game.map.width);
      const minSq = seed === index ? 22 * 22 : 17 * 17;
      return dx * dx + dy * dy >= minSq;
    });
    if (!farEnough) continue;

    const id = game.factions.length + 1;
    const bot = makeFaction(id, power.name, power.color, "major");
    bot.warCooldownUntil = 110 + Math.floor(Math.random() * 90);
    game.factions.push(bot);
    placeInitialRealm(game, bot, cell);
    seeds.push(cell);
    usedNames.add(power.name);
  }

  // 2. TÜR BOT: Rastgele Beylikler — En-uzak-nokta (Maximin) örneklemesiyle haritanın boş kalan bölgelerine eşit dağılır
  const possible: number[] = [];
  for (let i = 0; i < game.map.land.length; i++) {
    if (game.map.land[i] && game.owners[i] === 0 && game.map.terrain[i] !== 4) possible.push(i);
  }

  let minorIdx = 0;
  let attempts = 0;
  while (game.factions.length < botCount + 1 && attempts++ < 400 && possible.length) {
    let bestCandidate = -1;
    let bestMinDistSq = -1;
    const sampleCount = 55;
    for (let s = 0; s < sampleCount; s++) {
      const cand = possible[Math.floor(Math.random() * possible.length)];
      if (game.owners[cand] !== 0) continue;
      const cx = cand % game.map.width;
      const cy = Math.floor(cand / game.map.width);
      let nearestSq = Infinity;
      for (const seed of seeds) {
        const dx = cx - (seed % game.map.width);
        const dy = cy - Math.floor(seed / game.map.width);
        const dSq = dx * dx + dy * dy;
        if (dSq < nearestSq) nearestSq = dSq;
      }
      if (nearestSq > bestMinDistSq) {
        bestMinDistSq = nearestSq;
        bestCandidate = cand;
      }
    }
    if (bestCandidate < 0 || bestMinDistSq < 12 * 12) break;

    const baseName = RANDOM_MINOR_NAMES[minorIdx % RANDOM_MINOR_NAMES.length];
    minorIdx++;
    let suffixNumber = 1;
    let name = baseName;
    while (usedNames.has(name)) {
      suffixNumber++;
      name = `${baseName} ${suffixNumber}`;
    }
    usedNames.add(name);

    const id = game.factions.length + 1;
    const color = FACTION_COLORS[(id + 7) % FACTION_COLORS.length];
    const bot = makeFaction(id, name, color, "minor");
    bot.warCooldownUntil = 115 + Math.floor(Math.random() * 95);
    game.factions.push(bot);
    placeInitialRealm(game, bot, bestCandidate);
    seeds.push(bestCandidate);
  }

  game.phase = "playing";
  game.selected = index;
  game.lastEvent = "Başkent Kalen kuruldu! Haritaya tıklayarak komutanını yürüt ve genişle.";
  return true;
}

function distanceSquaredXY(ax: number, ay: number, bx: number, by: number): number {
  const dx = ax - bx;
  const dy = ay - by;
  return dx * dx + dy * dy;
}

function distanceSquared(a: number, b: number, width: number): number {
  return distanceSquaredXY(a % width, Math.floor(a / width), b % width, Math.floor(b / width));
}

function nearestRallyCell(game: GameState, factionId: number, x: number, y: number): number | null {
  let best: number | null = null;
  let bestScore = Infinity;
  for (const [index, building] of game.buildings) {
    if (building.owner !== factionId) continue;
    const weight =
      building.type === "barracks" ? 0.72 : building.type === "castle" ? 0.9 : building.type === "town" ? 1 : 1.5;
    const distance = distanceSquaredXY(index % game.map.width, Math.floor(index / game.map.width), x, y);
    const score = distance * weight;
    if (score < bestScore) {
      bestScore = score;
      best = index;
    }
  }
  return best;
}

function nearestCastleCell(game: GameState, factionId: number, x: number, y: number): number | null {
  let best: number | null = null;
  let bestDist = Infinity;
  for (const [cell, b] of game.buildings) {
    if (b.owner !== factionId || b.type !== "castle") continue;
    const dist = distanceSquaredXY(cell % game.map.width, Math.floor(cell / game.map.width), x, y);
    if (dist < bestDist) {
      bestDist = dist;
      best = cell;
    }
  }
  return best;
}

function isProtectedByEnemyCastle(game: GameState, cell: number, ownerId: number): Building & { index: number } | null {
  if (ownerId <= 0) return null;
  const cx = cell % game.map.width;
  const cy = Math.floor(cell / game.map.width);
  for (const [bIndex, building] of game.buildings) {
    if (building.owner !== ownerId || building.type !== "castle" || building.wallHp <= 0) continue;
    const radius = castleDomainRadius(building.level) + 2;
    const bx = bIndex % game.map.width;
    const by = Math.floor(bIndex / game.map.width);
    if ((cx - bx) ** 2 + (cy - by) ** 2 <= radius * radius) {
      return { ...building, index: bIndex };
    }
  }
  return null;
}

function activeWarEnemies(game: GameState, factionId: number): number[] {
  const enemies: number[] = [];
  for (const other of game.factions) {
    if (other.id === factionId || other.land === 0) continue;
    if (getRelation(game, factionId, other.id).status === "war") {
      enemies.push(other.id);
    }
  }
  return enemies;
}

export function getTotalTroops(faction: Faction): number {
  return faction.reserveTroops + faction.commander.army;
}

export function getCapacity(faction: Faction): number {
  // Toprağın kendisi asker üretmez. Nüfus ve barınma kapasitesi yalnızca
  // kasaba, kışla ve kale yatırımlarıyla büyür.
  return (
    5200 +
    faction.buildingLevels.town * 8500 +
    faction.buildingLevels.barracks * 4200 +
    faction.buildingLevels.castle * 1800 +
    faction.buildingLevels.port * 900
  );
}

export function getTroopRatePerTick(_faction: Faction): number {
  // Küresel/havadan asker üretimi yok. Askerler yalnızca kışlalardaki
  // zamanlı eğitim emirleriyle, eğitildikleri garnizona katılır.
  return 0;
}

// Katsayılar tik başınadır. step 0,078 sn olduğu için eski 1x gelir hızı korunur.
export const ECON = {
  base: 0.42,
  land: 0.003,
  town: 0.33,
  market: 0.66,
  castle: 0.02,
  upkeepPer10k: 0.22,
} as const;

// Savaş ilanı / saldırı, ticareti 5 dakika (1.360 tik) askıya alır.
export const TRADE_SUSPEND_TICKS = 1360;

export function isTradeBlocked(game: GameState, a: number, b: number): boolean {
  return (game.tradeBlock.get(relationKey(a, b)) ?? 0) > game.tick;
}

function suspendTrade(game: GameState, a: number, b: number): void {
  game.tradeBlock.set(relationKey(a, b), game.tick + TRADE_SUSPEND_TICKS);
}

export function getEconomyBreakdown(faction: Faction): Array<{ label: string; perSec: number }> {
  const perSec = 1 / STEP_SECONDS;
  return [
    { label: "Taban vergi", perSec: ECON.base * perSec },
    { label: `Topraklar (${faction.land} bölge)`, perSec: faction.land * ECON.land * perSec },
    { label: `Kasaba seviyesi ×${faction.buildingLevels.town}`, perSec: faction.buildingLevels.town * ECON.town * perSec },
    { label: `Pazar seviyesi ×${faction.buildingLevels.market}`, perSec: faction.buildingLevels.market * ECON.market * perSec },
    { label: `Kale seviyesi ×${faction.buildingLevels.castle}`, perSec: faction.buildingLevels.castle * ECON.castle * perSec },
    { label: "Ordu bakımı", perSec: -(getTotalTroops(faction) / 10000) * ECON.upkeepPer10k * perSec },
  ];
}

export function getGoldRatePerTick(faction: Faction): number {
  return getEconomyBreakdown(faction).reduce((sum, item) => sum + item.perSec, 0) * STEP_SECONDS;
}

export function getCapacityBreakdown(faction: Faction): Array<{ label: string; value: number }> {
  return [
    { label: "Taban barınma", value: 5200 },
    { label: `Kasaba seviyesi ×${faction.buildingLevels.town}`, value: faction.buildingLevels.town * 8500 },
    { label: `Kışla seviyesi ×${faction.buildingLevels.barracks}`, value: faction.buildingLevels.barracks * 4200 },
    { label: `Kale seviyesi ×${faction.buildingLevels.castle}`, value: faction.buildingLevels.castle * 1800 },
    { label: `Liman seviyesi ×${faction.buildingLevels.port}`, value: faction.buildingLevels.port * 900 },
  ];
}

export function getRecruitValues(faction: Faction): { cost: number; amount: number; ticks: number } {
  const levels = Math.max(1, faction.buildingLevels.barracks);
  return {
    cost: 700,
    amount: Math.round(1200 * (1 + 0.65 * (levels - 1))),
    ticks: Math.max(16, Math.round(50 / (1 + 0.45 * (levels - 1)))),
  };
}

export function recruitTroops(game: GameState, factionId: number, buildingIndex?: number): string {
  const faction = game.factions[factionId - 1];
  if (!faction || !faction.land) return "Geçersiz krallık.";
  if (game.tick < faction.exhaustionUntil && faction.reserveTroops < getCapacity(faction) * 0.12) {
    return "Ordun bozgundan toparlanıyor; şimdi eğitim verilemez.";
  }

  let barracksIndex = buildingIndex;
  if (barracksIndex === undefined) {
    let bestDistance = Infinity;
    for (const [index, building] of game.buildings) {
      if (building.owner !== factionId || building.type !== "barracks") continue;
      const d = distanceSquaredXY(
        index % game.map.width,
        Math.floor(index / game.map.width),
        faction.commander.x,
        faction.commander.y,
      );
      if (d < bestDistance) {
        bestDistance = d;
        barracksIndex = index;
      }
    }
  }

  if (barracksIndex === undefined) return "Piyade eğitmek için önce bir kasaba ve kışla kur.";
  const barracks = game.buildings.get(barracksIndex);
  if (!barracks || barracks.owner !== factionId || barracks.type !== "barracks") {
    return "Geçerli bir kışla seç.";
  }

  const queuedHere = game.trainingOrders.filter(
    (order) => order.owner === factionId && order.buildingIndex === barracksIndex,
  );
  if (queuedHere.length >= barracks.level * 2) return "Bu kışlanın eğitim sırası dolu. Başka kışla seç veya seviye yükselt.";

  const queuedGlobal = game.trainingOrders
    .filter((order) => order.owner === factionId)
    .reduce((sum, order) => sum + order.amount, 0);
  const total = getTotalTroops(faction) + queuedGlobal;
  const cap = getCapacity(faction);
  if (total >= cap - 100) return "Asker kapasitesi dolu. Yeni kasaba ve kışla inşa et.";

  const localQueued = queuedHere.reduce((sum, order) => sum + order.amount, 0);
  const localCap = barracks.level * 4800;
  if ((barracks.garrison || 0) + localQueued >= localCap - 100) {
    return "Bu kışlanın garnizonu dolu. Komutanını yaklaştırıp askerleri sahaya al veya kışlayı yükselt.";
  }

  const { cost, amount, ticks } = getRecruitValues(faction);
  if (faction.gold < cost) return `Eğitim için ${cost} altın gerekiyor.`;
  const trainedAmount = Math.min(amount, cap - total, localCap - (barracks.garrison || 0) - localQueued);
  if (trainedAmount < 100) return "Bu kışlada eğitilecek kapasite kalmadı.";

  faction.gold -= cost;
  game.trainingOrders.push({
    id: game.tick * 1000 + game.nextShipId++,
    owner: factionId,
    buildingIndex: barracksIndex,
    amount: Math.floor(trainedAmount),
    remainingTicks: ticks,
    totalTicks: ticks,
  });

  if (factionId === PLAYER_ID) {
    game.lastEvent = `Kışlada ${formatNumber(trainedAmount)} piyade eğitimi başladı (${Math.ceil(ticks * STEP_SECONDS)} sn).`;
  }
  return "";
}

function processTrainingOrders(game: GameState): void {
  const completed: TrainingOrder[] = [];
  for (const order of game.trainingOrders) {
    const building = game.buildings.get(order.buildingIndex);
    if (!building || building.owner !== order.owner || building.type !== "barracks") continue;
    order.remainingTicks--;
    if (order.remainingTicks <= 0) completed.push(order);
  }

  for (const order of completed) {
    const building = game.buildings.get(order.buildingIndex);
    const faction = game.factions[order.owner - 1];
    if (!building || !faction) continue;
    building.garrison = (building.garrison || 0) + order.amount;
    faction.reserveTroops += order.amount;
    game.trainingOrders = game.trainingOrders.filter((item) => item.id !== order.id);
    if (order.owner === PLAYER_ID) {
      game.lastEvent = `${formatNumber(order.amount)} piyade eğitimini tamamladı ve kışla garnizonuna katıldı.`;
    }
  }
}

function canTraverseLandCell(game: GameState, factionId: number, cell: number): boolean {
  if (!game.map.land[cell]) return false;
  const owner = game.owners[cell];
  if (owner === 0 || owner === factionId) return true;
  const status = getRelation(game, factionId, owner).status;
  // Savaşta olmadığın (barış/ateşkes) ülkelerin topraklarından ordu geçemez!
  return status === "war" || status === "alliance";
}

// Komutan bir kara hücresinden, boğaz/kanal suyundan da geçebilir.
function canCommanderEnter(game: GameState, factionId: number, cell: number): boolean {
  if (game.map.waterways[cell]) return true;
  return canTraverseLandCell(game, factionId, cell);
}

function canRefugeeEnter(game: GameState, _factionId: number, cell: number): boolean {
  // Kaçan/toplanan ordu barıştaki ülkelerin topraklarından geçebilir ama orayı alamaz.
  if (game.map.waterways[cell]) return true;
  return game.map.land[cell] === 1;
}

function lineIsWalkable(
  game: GameState,
  factionId: number,
  from: number,
  to: number,
  refugee = false,
): boolean {
  const w = game.map.width;
  const x0 = from % w;
  const y0 = Math.floor(from / w);
  const x1 = to % w;
  const y1 = Math.floor(to / w);
  const steps = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0));
  if (steps === 0) return canTraverseLandCell(game, factionId, to);
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const x = Math.round(x0 + (x1 - x0) * t);
    const y = Math.round(y0 + (y1 - y0) * t);
    if (x < 0 || y < 0 || x >= w || y >= game.map.height) return false;
    const cell = y * w + x;
    if (!(refugee ? canRefugeeEnter(game, factionId, cell) : canCommanderEnter(game, factionId, cell))) return false;
  }
  return refugee ? canRefugeeEnter(game, factionId, to) : canTraverseLandCell(game, factionId, to);
}

// BFS rotasını "ip çekme" (string pulling) ile sadeleştirir: gereksiz çapraz
// zikzakları siler, komutan düz gidebiliyorsa dümdüz gider.
function simplifyRoute(
  game: GameState,
  factionId: number,
  startCell: number,
  route: number[],
  refugee = false,
): number[] {
  if (route.length <= 2) return route;
  const points = [startCell, ...route];
  const out: number[] = [];
  let i = 0;
  while (i < points.length - 1) {
    let j = points.length - 1;
    while (j > i + 1 && !lineIsWalkable(game, factionId, points[i], points[j], refugee)) j--;
    out.push(points[j]);
    i = j;
  }
  return out;
}

function findLandRoute(
  game: GameState,
  factionId: number,
  startCell: number,
  targetCell: number,
  refugee = false,
): number[] | null {
  const enterable = (cell: number) =>
    refugee ? canRefugeeEnter(game, factionId, cell) : canCommanderEnter(game, factionId, cell);
  if (startCell === targetCell) return [targetCell];
  if (!(refugee ? canRefugeeEnter(game, factionId, targetCell) : canTraverseLandCell(game, factionId, targetCell))) return null;
  if (lineIsWalkable(game, factionId, startCell, targetCell, refugee)) {
    return simplifyRoute(game, factionId, startCell, [targetCell], refugee);
  }

  const w = game.map.width;
  const h = game.map.height;
  const size = w * h;
  const prev = new Int32Array(size);
  prev.fill(-2);
  const queue = new Int32Array(size);
  let head = 0;
  let tail = 0;
  prev[startCell] = -1;
  queue[tail++] = startCell;

  let found = false;
  while (head < tail) {
    const cur = queue[head++];
    if (cur === targetCell) {
      found = true;
      break;
    }
    for (const next of cellNeighbors8(cur, w, h)) {
      if (prev[next] !== -2) continue;
      if (enterable(next)) {
        prev[next] = cur;
        queue[tail++] = next;
      } else if (!game.map.land[next]) {
        // Bir hücrelik dar boğaz: karşı kıyıya doğrudan atla (Boğaz/Çanakkale).
        for (const across of cellNeighbors8(next, w, h)) {
          if (prev[across] === -2 && (refugee ? canRefugeeEnter(game, factionId, across) : canTraverseLandCell(game, factionId, across))) {
            prev[across] = cur;
            queue[tail++] = across;
          }
        }
      }
    }
  }

  if (!found) return null;
  const path: number[] = [];
  let cursor = targetCell;
  while (cursor >= 0 && cursor !== startCell) {
    path.push(cursor);
    cursor = prev[cursor];
  }
  path.reverse();
  return simplifyRoute(game, factionId, startCell, path, refugee);
}

export function commandMove(game: GameState, factionId: number, targetIndex: number): string {
  if (game.phase !== "playing") return "Önce başlangıç kaleni kur.";
  if (!game.map.land[targetIndex]) return "Kara bölgesi seçmelisin.";

  const faction = game.factions[factionId - 1];
  const cmd = faction.commander;
  if (cmd.stance === "embarked") return "Komutan deniz yolculuğunda; çıkarma tamamlanana kadar emir verilemez.";
  const tx = targetIndex % game.map.width;
  const ty = Math.floor(targetIndex / game.map.width);
  const targetOwner = game.owners[targetIndex];

  if (targetOwner > 0 && targetOwner !== factionId) {
    const rel = getRelation(game, factionId, targetOwner);
    if (rel.status === "alliance") return "Müttefik topraklarına saldıramazsın.";
    if (rel.status === "truce") return "Ateşkes sürerken bu krallığa saldıramazsın.";
    if (rel.status === "peace") {
      return `NEED_WAR:${targetOwner}`;
    }
  }

  if (cmd.stance === "retreat" && cmd.retreatTicks > 12) {
    return "Komutanın bozgundan toparlanıyor, biraz bekle.";
  }

  const startX = Math.max(0, Math.min(game.map.width - 1, Math.round(cmd.x)));
  const startY = Math.max(0, Math.min(game.map.height - 1, Math.round(cmd.y)));
  const startCell = startY * game.map.width + startX;
  const route = findLandRoute(game, factionId, startCell, targetIndex);
  if (!route) {
    return "Arada barışta olduğun devletler veya deniz var! Sınır komşun olmayan devlete karadan geçemezsin.";
  }

  // Kuşatmadan çıkış: yeni hedef verildiğinde orduyu çek, kilitleme.
  if (cmd.stance === "siege") {
    cmd.siegingCastle = null;
    cmd.stance = "march";
    cmd.army = Math.max(100, cmd.army * 0.96);
    if (factionId === PLAYER_ID) {
      game.lastEvent = "Kuşatma kaldırıldı; ordu geri çekiliyor.";
    }
  }

  // Allow disengaging from a battle/siege if ordered to retreat/redeploy far enough
  if (cmd.stance === "battle" && cmd.engagedWith !== null) {
    const distFromBattle = distanceSquaredXY(cmd.x, cmd.y, tx, ty);
    if (distFromBattle < 36) {
      return "Ordular meydan savaşında çarpışıyor!";
    }
    cmd.army = Math.max(100, cmd.army * 0.9);
    const enemy = game.factions[cmd.engagedWith - 1];
    if (enemy && enemy.commander.engagedWith === factionId) {
      enemy.commander.engagedWith = null;
      enemy.commander.stance = enemy.commander.targetX !== null ? "march" : "idle";
    }
    cmd.engagedWith = null;
  }

  cmd.targetX = tx;
  cmd.targetY = ty;
  cmd.route = route;
  cmd.stance = "march";
  cmd.retreatTicks = 0;

  if (factionId === PLAYER_ID) {
    if (targetOwner === PLAYER_ID) {
      game.lastEvent = "Komutanın kendi topraklarına intikal ediyor.";
    } else if (targetOwner > 0) {
      game.lastEvent = `${game.factions[targetOwner - 1].name} üzerine sefer emri verildi!`;
    } else {
      game.lastEvent = "Komutanın ve ordusu yeni topraklara yürüyor.";
    }
  }
  return "";
}

export function declareWar(game: GameState, attackerId: number, defenderId: number): string {
  if (attackerId === defenderId) return "Kendine savaş açamazsın.";
  const attacker = game.factions[attackerId - 1];
  const defender = game.factions[defenderId - 1];
  if (!attacker || !defender || !attacker.land || !defender.land) return "Geçersiz devlet.";

  const rel = getRelation(game, attackerId, defenderId);
  if (rel.status === "war") return `${defender.name} ile zaten savaştasın.`;
  if (rel.status === "truce" && game.tick < rel.truceUntil) {
    return "Ateşkes süresi dolmadan savaş ilan edemezsin.";
  }

  setRelation(game, attackerId, defenderId, "war");
  game.offers = game.offers.filter(
    (o) => !((o.fromId === defenderId && attackerId === PLAYER_ID) || (o.fromId === attackerId && defenderId === PLAYER_ID)),
  );

  const capital = nearestCastleCell(game, defenderId, attacker.commander.x, attacker.commander.y);
  if (capital !== null) {
    game.effects.push({
      index: capital,
      x: capital % game.map.width,
      y: Math.floor(capital / game.map.width),
      started: game.tick,
      type: "war",
    });
  }

  if (attackerId === PLAYER_ID || defenderId === PLAYER_ID) {
    const other = attackerId === PLAYER_ID ? defender : attacker;
    pushNotification(game, {
      kind: "war",
      title: attackerId === PLAYER_ID ? "Savaş ilan edildi" : "Sana savaş açıldı",
      message: `${other.name} ile savaş başladı. Yalnızca bu krallıkla ticaret kesildi.`,
      fromId: other.id,
      fromName: other.name,
      fromColor: other.color,
      actionable: false,
    }, 180);
    game.lastEvent =
      attackerId === PLAYER_ID
        ? `${other.name} krallığına savaş ilan ettin!`
        : `${other.name} sana savaş ilan etti!`;
  }
  return "";
}

export function proposePeace(game: GameState, proposerId: number, targetId: number): string {
  const proposer = game.factions[proposerId - 1];
  const target = game.factions[targetId - 1];
  if (!proposer || !target || !proposer.land || !target.land) return "Geçersiz krallık.";

  const rel = getRelation(game, proposerId, targetId);
  if (rel.status !== "war") return "Bu krallıkla savaşta değilsin.";

  if (proposerId === PLAYER_ID) {
    if (game.tick < target.peaceOfferFromPlayerCooldown) {
      return `${target.name} yakın zamanda barışı reddetti. Biraz bekle.`;
    }
    const warDuration = game.tick - rel.warStartTick;
    const powerRatio = getTotalTroops(proposer) / Math.max(400, getTotalTroops(target));
    const playerDominant = powerRatio > 1.25 || warDuration > 160;
    const beingBesieged = target.commander.stance === "retreat" || target.buildings.castle <= 1;

    if (playerDominant || beingBesieged || Math.random() < 0.35) {
      setRelation(game, proposerId, targetId, "truce", 200);
      clearCombatBetween(game, proposerId, targetId);
      game.lastEvent = `${target.name} barış teklifini kabul etti! (Ateşkes)`;
      return "";
    } else {
      target.peaceOfferFromPlayerCooldown = game.tick + 65;
      return `${target.name} barış teklifini reddetti.`;
    }
  } else {
    setRelation(game, proposerId, targetId, "truce", 200);
    clearCombatBetween(game, proposerId, targetId);
    return "";
  }
}

export function toggleAlliance(game: GameState, targetId: number): string {
  const target = game.factions[targetId - 1];
  if (!target || target.id === PLAYER_ID || !target.land) return "Geçerli bir krallık seç.";
  const rel = getRelation(game, PLAYER_ID, targetId);
  if (rel.status === "war") return "Savaştaki bir krallıkla ittifak kuramazsın. Önce barış yap.";

  if (rel.status === "alliance") {
    setRelation(game, PLAYER_ID, targetId, "truce", 120);
    game.lastEvent = `${target.name} ile ittifak sona erdi. Kısa bir ateşkes başladı.`;
    pushNotification(game, {
      kind: "alliance_broken",
      title: "İttifak sona erdi",
      message: `${target.name} ile ittifakı bozdun. Kısa süreli ateşkes başladı.`,
      fromId: target.id,
      fromName: target.name,
      fromColor: target.color,
      actionable: false,
    });
    return game.lastEvent;
  }

  // Check if player is currently at war with one of target's allies
  const playerPower = getTotalTroops(game.factions[0]);
  const targetPower = getTotalTroops(target);
  if (targetPower > playerPower * 3.5 && Math.random() < 0.3) {
    return `${target.name} şimdilik ittifaka yanaşmıyor.`;
  }

  setRelation(game, PLAYER_ID, targetId, "alliance");
  game.lastEvent = `${target.name} ile ittifak kuruldu!`;
  return game.lastEvent;
}

export function signTruce(game: GameState, targetId: number): string {
  const target = game.factions[targetId - 1];
  if (!target || targetId === PLAYER_ID || !target.land) return "Geçersiz krallık.";
  const rel = getRelation(game, PLAYER_ID, targetId);
  if (rel.status === "war") return "Savaştayken saldırmazlık paktı imzalanamaz.";
  if (rel.status === "alliance") return "Zaten müttefiksiniz.";
  if (rel.status === "truce") return "Saldırmazlık paktı zaten yürürlükte.";
  setRelation(game, PLAYER_ID, targetId, "truce", 220);
  game.lastEvent = `${target.name} ile saldırmazlık paktı imzalandı.`;
  return game.lastEvent;
}

export function respondToOffer(game: GameState, offerId: number, accept: boolean): void {
  const index = game.offers.findIndex((o) => o.id === offerId);
  if (index === -1) return;
  const offer = game.offers[index];
  game.offers.splice(index, 1);
  game.notifications = game.notifications.filter((item) => item.offerId !== offer.id);

  const sender = game.factions[offer.fromId - 1];
  if (!sender || !sender.land) return;

  if (!accept) {
    game.lastEvent = `${sender.name} krallığının ${offer.type === "peace" ? "barış" : "ittifak"} teklifi reddedildi.`;
    return;
  }

  if (offer.type === "peace") {
    setRelation(game, PLAYER_ID, offer.fromId, "truce", 200);
    clearCombatBetween(game, PLAYER_ID, offer.fromId);
    game.lastEvent = `${sender.name} ile barış antlaşması imzalandı!`;
  } else {
    setRelation(game, PLAYER_ID, offer.fromId, "alliance");
    game.lastEvent = `${sender.name} ile ittifak kuruldu!`;
  }
}

function clearCombatBetween(game: GameState, aId: number, bId: number): void {
  const a = game.factions[aId - 1];
  const b = game.factions[bId - 1];
  if (a.commander.engagedWith === bId) {
    a.commander.engagedWith = null;
    a.commander.stance = a.commander.targetX !== null ? "march" : "idle";
  }
  if (b.commander.engagedWith === aId) {
    b.commander.engagedWith = null;
    b.commander.stance = b.commander.targetX !== null ? "march" : "idle";
  }
  if (a.commander.siegingCastle !== null) {
    const c = game.buildings.get(a.commander.siegingCastle);
    if (!c || c.owner === bId) {
      a.commander.siegingCastle = null;
      a.commander.stance = a.commander.targetX !== null ? "march" : "idle";
    }
  }
  if (b.commander.siegingCastle !== null) {
    const c = game.buildings.get(b.commander.siegingCastle);
    if (!c || c.owner === aId) {
      b.commander.siegingCastle = null;
      b.commander.stance = b.commander.targetX !== null ? "march" : "idle";
    }
  }
}

export function isInSupplyRange(game: GameState, cell: number, factionId: number): boolean {
  const x = cell % game.map.width;
  const y = Math.floor(cell / game.map.width);
  for (const [index, building] of game.buildings) {
    if (building.owner !== factionId || building.type !== "castle" || building.wallHp <= 0) continue;
    const radius = castleSupplyRadius(building.level);
    if (distanceSquaredXY(index % game.map.width, Math.floor(index / game.map.width), x, y) <= radius * radius) {
      return true;
    }
  }
  return false;
}

function withdrawLocalGarrison(
  game: GameState,
  faction: Faction,
  requested: number,
  x: number,
  y: number,
): number {
  const sources = [...game.buildings.entries()]
    .filter(([index, building]) => {
      if (building.owner !== faction.id || (building.garrison || 0) <= 0) return false;
      if (!["barracks", "castle", "town"].includes(building.type)) return false;
      return distanceSquaredXY(index % game.map.width, Math.floor(index / game.map.width), x, y) <= 20 * 20;
    })
    .sort(([a], [b]) =>
      distanceSquared(a, Math.round(y) * game.map.width + Math.round(x), game.map.width) -
      distanceSquared(b, Math.round(y) * game.map.width + Math.round(x), game.map.width),
    );

  let transferred = 0;
  for (const [, building] of sources) {
    const take = Math.min(building.garrison || 0, requested - transferred);
    building.garrison = Math.max(0, (building.garrison || 0) - take);
    transferred += take;
    if (transferred >= requested) break;
  }
  faction.reserveTroops = Math.max(0, faction.reserveTroops - transferred);
  return transferred;
}

function depositLocalGarrison(game: GameState, faction: Faction, amount: number, x: number, y: number): number {
  let best: Building | null = null;
  let bestDistance = Infinity;
  for (const [index, building] of game.buildings) {
    if (building.owner !== faction.id || !["barracks", "castle", "town"].includes(building.type)) continue;
    const d = distanceSquaredXY(index % game.map.width, Math.floor(index / game.map.width), x, y);
    if (d <= 22 * 22 && d < bestDistance) {
      bestDistance = d;
      best = building;
    }
  }
  if (!best) return 0;
  best.garrison = (best.garrison || 0) + amount;
  faction.reserveTroops += amount;
  return amount;
}

function syncCommanderArmy(game: GameState, faction: Faction): void {
  const cmd = faction.commander;
  if (cmd.stance === "embarked" || cmd.stance === "battle" || cmd.stance === "siege") return;
  const total = getTotalTroops(faction);
  const desired = total * (faction.mobilizationRatio / 100);
  const cx = Math.max(0, Math.min(game.map.width - 1, Math.round(cmd.x)));
  const cy = Math.max(0, Math.min(game.map.height - 1, Math.round(cmd.y)));
  const onFriendly = game.owners[cy * game.map.width + cx] === faction.id;
  // Toparlanma sırasında ordu, kendi toprağına varmasa bile yakındaki garnizonundan
  // takviye çekebilir; böylece evine dönerken güç toplar.
  if (!onFriendly && cmd.regroupTicks === 0) return;

  if (cmd.army < desired && faction.reserveTroops > 0) {
    const exhausted = game.tick < faction.exhaustionUntil;
    const regrouping = cmd.regroupTicks > 0 || cmd.stance === "retreat";
    const requested = Math.min(
      faction.reserveTroops,
      Math.max(18, (desired - cmd.army) * (exhausted ? (regrouping ? 0.05 : 0.012) : 0.055)),
    );
    const transferred = withdrawLocalGarrison(game, faction, requested, cmd.x, cmd.y);
    cmd.army += transferred;
  } else if (cmd.army > desired + 250 && cmd.stance === "idle") {
    const returning = Math.min(cmd.army - desired, Math.max(35, (cmd.army - desired) * 0.04));
    const deposited = depositLocalGarrison(game, faction, returning, cmd.x, cmd.y);
    cmd.army -= deposited;
  }
}

function hasFriendlyNear(game: GameState, cell: number, factionId: number, radius: number): boolean {
  const cx = cell % game.map.width;
  const cy = Math.floor(cell / game.map.width);
  for (let dy = -radius; dy <= radius; dy++) {
    for (let dx = -radius; dx <= radius; dx++) {
      const x = cx + dx;
      const y = cy + dy;
      if (x < 0 || x >= game.map.width || y < 0 || y >= game.map.height) continue;
      if (game.owners[y * game.map.width + x] === factionId) return true;
    }
  }
  return false;
}

function captureAroundCommander(game: GameState, faction: Faction): void {
  const cmd = faction.commander;
  if (["retreat", "battle", "siege", "embarked"].includes(cmd.stance)) return;
  if (cmd.army < 180) return;

  const cx = Math.round(cmd.x);
  const cy = Math.round(cmd.y);
  const moving = cmd.targetX !== null || cmd.targetY !== null;
  const neutralRadius = moving ? 5 : 8;
  const enemyRadius = 4;
  const searchRadius = Math.max(neutralRadius, enemyRadius);
  const enemies = new Set(activeWarEnemies(game, faction.id));
  const candidates: Array<{ cell: number; owner: number; score: number }> = [];

  for (let dy = -searchRadius; dy <= searchRadius; dy++) {
    for (let dx = -searchRadius; dx <= searchRadius; dx++) {
      const dist = dx * dx + dy * dy;
      const x = cx + dx;
      const y = cy + dy;
      if (x < 0 || x >= game.map.width || y < 0 || y >= game.map.height) continue;
      const cell = y * game.map.width + x;
      if (!game.map.land[cell]) continue;
      const owner = game.owners[cell];
      if (owner === faction.id) continue;
      const isNeutral = owner === 0;
      if (!isNeutral && !enemies.has(owner)) continue;
      const limit = (isNeutral ? neutralRadius : enemyRadius) ** 2;
      if (dist > limit + 0.25) continue;
      candidates.push({ cell, owner, score: dist });
    }
  }
  candidates.sort((a, b) => a.score - b.score);

  let neutralBudget = moving ? 8 : 16;
  // Savaştaki devletin kale koruması dışındaki toprakları kademeli alınır;
  // aynı tıkta çok sayıda çarpışma yaşanıp ordu gereksiz yere erimez.
  let enemyBudget = 4;
  const commanderCell = cy * game.map.width + cx;
  let warned = false;

  for (const candidate of candidates) {
    if (neutralBudget <= 0 && enemyBudget <= 0) break;
    const { cell, owner } = candidate;
    const beachhead =
      (cmd.beachheadTicks || 0) > 0 &&
      distanceSquared(cell, commanderCell, game.map.width) <= 2 * 2;

    if (owner === 0) {
      if (neutralBudget <= 0) continue;
      // Çıkarma yalnızca tek bir köprübaşı hücresi verir. Boş toprakta ilerlemek
      // için mutlaka bir kalenin ikmal menziline girmek gerekir.
      if (!isInSupplyRange(game, cell, faction.id)) {
        if (!warned && faction.id === PLAYER_ID && game.tick % 40 === 0) {
          game.lastEvent = "İkmal menzilinin dışındasın. İlerlemek için sınıra yeni bir kale kur.";
          warned = true;
        }
        continue;
      }
      if (hasFriendlyNear(game, cell, faction.id, 1)) {
        claimCell(game, cell, faction.id);
        neutralBudget--;
      }
      continue;
    }

    if (enemyBudget <= 0) continue;
    // Toparlanma dönemindeki ordu saldırmaz; önce kendi kalesine dönüp mevcudunu toplar.
    if (cmd.regroupTicks > 0) continue;
    // Sadece aktif olarak savaşta olduğumuz devletin ve kendi sınırımıza bitişik toprağı alınabilir!
    if (getRelation(game, faction.id, owner).status !== "war") continue;
    if (!beachhead && !hasFriendlyNear(game, cell, faction.id, 1)) continue;
    // Kaleye yaklaşınca yalnızca kuşatma ile alınabilir.
    if (isProtectedByEnemyCastle(game, cell, owner)) continue;

    const enemy = game.factions[owner - 1];
    const enemyDistSq = distanceSquaredXY(
      enemy.commander.x,
      enemy.commander.y,
      cell % game.map.width,
      Math.floor(cell / game.map.width),
    );
    if (enemy.commander.stance === "retreat" && enemyDistSq <= 16 * 16) continue;
    const enemyDefendingHere =
      enemy.commander.army >= 300 &&
      enemy.commander.stance !== "retreat" &&
      enemy.commander.stance !== "embarked" &&
      enemyDistSq <= 10 * 10;
    if (enemyDefendingHere) continue;

    const terrain = game.map.terrain[cell];
    const skirmishCost = terrain === 4 ? 34 : terrain === 3 ? 23 : terrain === 2 ? 18 : 14;
    if (cmd.army > skirmishCost + 180) {
      cmd.army -= skirmishCost;
      claimCell(game, cell, faction.id);
      enemyBudget--;
    }
  }
}

function annexCollapsedRealms(game: GameState): void {
  // Tüm kaleler düşmüşse kalan topraklar savaşan devlete kademeli geçer.
  if (game.tick % 6 !== 0) return;
  let budget = 90;
  for (const defender of game.factions) {
    if (defender.land <= 0 || budget <= 0) continue;
    const liveCastle = [...game.buildings.values()].some(
      (building) => building.owner === defender.id && building.type === "castle" && building.wallHp > 0,
    );
    if (liveCastle) continue;
    const enemies = activeWarEnemies(game, defender.id);
    if (!enemies.length) continue;
    const fallback = enemies
      .slice()
      .sort(
        (a, b) =>
          distanceSquaredXY(
            game.factions[a - 1].commander.x,
            game.factions[a - 1].commander.y,
            defender.commander.x,
            defender.commander.y,
          ) -
          distanceSquaredXY(
            game.factions[b - 1].commander.x,
            game.factions[b - 1].commander.y,
            defender.commander.x,
            defender.commander.y,
          ),
      )[0];

    for (const cell of [...defender.tiles]) {
      if (budget <= 0) break;
      if (game.owners[cell] !== defender.id) continue;
      let attacker = 0;
      for (const n of cellNeighbors(cell, game.map.width, game.map.height)) {
        const owner = game.owners[n];
        if (enemies.includes(owner)) {
          attacker = owner;
          break;
        }
      }
      if (!attacker) attacker = fallback;
      claimCell(game, cell, attacker);
      budget--;
    }
    if (defender.land <= 0) {
      defender.commander.army = 0;
      defender.reserveTroops = 0;
    }
  }
}

function stepCommanderMovement(game: GameState, faction: Faction): void {
  const cmd = faction.commander;

  if (cmd.stance === "retreat") {
    cmd.retreatTicks--;
    const rally = nearestRallyCell(game, faction.id, cmd.x, cmd.y) ??
      nearestCastleCell(game, faction.id, cmd.x, cmd.y);
    if (rally !== null) {
      const rx = rally % game.map.width;
      const ry = Math.floor(rally / game.map.width);
      if (cmd.targetX !== rx || cmd.targetY !== ry) cmd.route = [];
      cmd.targetX = rx;
      cmd.targetY = ry;
    }
    if (cmd.retreatTicks <= 0) {
      cmd.stance = "idle";
      cmd.targetX = null;
      cmd.targetY = null;
      cmd.route = [];
      return;
    }
  }

  if (cmd.regroupTicks > 0) {
    cmd.regroupTicks--;
    if (cmd.stance !== "battle" && cmd.stance !== "siege" && cmd.stance !== "embarked") {
      let rally = nearestRallyCell(game, faction.id, cmd.x, cmd.y) ?? nearestCastleCell(game, faction.id, cmd.x, cmd.y);
      if (rally === null && faction.tiles.size > 0) {
        let bestDist = Infinity;
        for (const tile of faction.tiles) {
          const d = distanceSquaredXY(tile % game.map.width, Math.floor(tile / game.map.width), cmd.x, cmd.y);
          if (d < bestDist) { bestDist = d; rally = tile; }
        }
      }
      if (rally !== null) {
        const rx = rally % game.map.width;
        const ry = Math.floor(rally / game.map.width);
        const far = Math.hypot(cmd.x - rx, cmd.y - ry) > 2.5;
        if (far) {
          if (cmd.targetX !== rx || cmd.targetY !== ry) cmd.route = [];
          cmd.targetX = rx;
          cmd.targetY = ry;
          cmd.stance = "march";
          cmd.retreatTicks = Math.max(cmd.retreatTicks, 1);
        } else if (cmd.stance === "march") {
          cmd.stance = "idle";
          cmd.targetX = null;
          cmd.targetY = null;
          cmd.route = [];
        }
      }
    }
  }

  if (cmd.stance === "battle" || cmd.stance === "siege" || cmd.stance === "embarked") return;
  if (cmd.targetX === null || cmd.targetY === null) return;

  const totalDx = cmd.targetX - cmd.x;
  const totalDy = cmd.targetY - cmd.y;
  const totalDist = Math.hypot(totalDx, totalDy);

  if (totalDist < 0.85) {
    const finalCell = Math.round(cmd.targetY) * game.map.width + Math.round(cmd.targetX);
    if (canTraverseLandCell(game, faction.id, finalCell)) {
      cmd.x = cmd.targetX;
      cmd.y = cmd.targetY;
    }
    cmd.targetX = null;
    cmd.targetY = null;
    cmd.route = [];
    if (cmd.stance !== "retreat") cmd.stance = "idle";
    return;
  }

  const curCell =
    Math.max(0, Math.min(game.map.height - 1, Math.round(cmd.y))) * game.map.width +
    Math.max(0, Math.min(game.map.width - 1, Math.round(cmd.x)));
  const targetCell = Math.round(cmd.targetY) * game.map.width + Math.round(cmd.targetX);

  const refugee = cmd.regroupTicks > 0 || cmd.stance === "retreat";
  // Eğer rota yoksa veya rotadaki sıradaki hücre geçişe uygun değilse rotayı güncelle
  if (!cmd.route || cmd.route.length === 0 || !(refugee ? canRefugeeEnter(game, faction.id, cmd.route[0]) : canCommanderEnter(game, faction.id, cmd.route[0]))) {
    let freshRoute = findLandRoute(game, faction.id, curCell, targetCell, refugee);
    if (!freshRoute && refugee) {
      // Sığınacak yapı yoksa en yakın kendi toprağına yönel.
      let best: number | null = null;
      let bestDist = Infinity;
      for (const tile of faction.tiles) {
        const d = distanceSquared(tile, targetCell, game.map.width);
        if (d < bestDist) { bestDist = d; best = tile; }
      }
      if (best !== null) freshRoute = findLandRoute(game, faction.id, curCell, best, true);
    }
    if (!freshRoute || freshRoute.length === 0) {
      cmd.targetX = null;
      cmd.targetY = null;
      cmd.route = [];
      if (cmd.stance !== "retreat") cmd.stance = "idle";
      return;
    }
    cmd.route = freshRoute;
  }

  // Ulaşılan ara noktaları temizle
  while (cmd.route.length > 1) {
    const wp = cmd.route[0];
    const wx = wp % game.map.width;
    const wy = Math.floor(wp / game.map.width);
    if (Math.hypot(wx - cmd.x, wy - cmd.y) < 0.9) {
      cmd.route.shift();
    } else {
      break;
    }
  }

  const nextWaypoint = cmd.route[0];
  if (nextWaypoint === undefined || !(refugee ? canRefugeeEnter(game, faction.id, nextWaypoint) : canCommanderEnter(game, faction.id, nextWaypoint))) {
    cmd.targetX = null;
    cmd.targetY = null;
    cmd.route = [];
    if (cmd.stance !== "retreat") cmd.stance = "idle";
    return;
  }

  const wx = nextWaypoint % game.map.width;
  const wy = Math.floor(nextWaypoint / game.map.width);
  const dx = wx - cmd.x;
  const dy = wy - cmd.y;
  const dist = Math.max(0.01, Math.hypot(dx, dy));

  const onHome = game.owners[curCell] === faction.id;
  const terrain = game.map.terrain[curCell];
  let speed =
    terrain === 4 ? 0.44 : terrain === 3 ? 0.64 : terrain === 2 ? 0.78 : 0.92;
  if (onHome) speed *= 1.2;
  if (cmd.stance === "retreat") speed *= 1.55;

  const step = Math.min(dist, speed);
  cmd.x += (dx / dist) * step;
  cmd.y += (dy / dist) * step;
}

export const MAX_ENCLOSED_POCKET_TILES = MAX_ENCLOSED_POCKET;

function fillEnclosedPockets(game: GameState): void {
  // Yalnızca küçük, tek devletle tamamen çevrili boşluklar dolar.
  // Büyük bölgeler / kıyıya açık boşluklar sömürgeleştirmeye bırakılır.
  if (game.tick % 16 !== 0) return;
  const w = game.map.width;
  const h = game.map.height;
  const total = game.map.land.length;
  const visited = new Uint8Array(total);
  const start = (game.tick * 7919) % Math.max(1, total);
  let budget = 180;

  for (let step = 0; step < total && budget > 0; step++) {
    const seed = (start + step) % total;
    if (!game.map.land[seed] || game.owners[seed] !== 0 || visited[seed]) continue;

    const queue: number[] = [seed];
    const pocket: number[] = [];
    visited[seed] = 1;
    let boundaryOwner = 0;
    let enclosed = true;
    let tooBig = false;

    for (let head = 0; head < queue.length; head++) {
      const cell = queue[head];
      pocket.push(cell);
      if (pocket.length > MAX_ENCLOSED_POCKET) {
        tooBig = true;
        pocket.length = MAX_ENCLOSED_POCKET + 1;
      }
      const x = cell % w;
      const y = Math.floor(cell / w);
      if (x === 0 || y === 0 || x === w - 1 || y === h - 1) enclosed = false;

      for (const n of cellNeighbors(cell, w, h)) {
        if (!game.map.land[n]) {
          enclosed = false;
          continue;
        }
        const owner = game.owners[n];
        if (owner === 0) {
          if (!visited[n]) {
            visited[n] = 1;
            queue.push(n);
          }
        } else {
          if (boundaryOwner === 0) boundaryOwner = owner;
          else if (boundaryOwner !== owner) enclosed = false;
        }
      }
      if (queue.length > 40000) {
        tooBig = true;
        break;
      }
    }

    if (enclosed && !tooBig && boundaryOwner > 0 && pocket.length > 0 && pocket.length <= MAX_ENCLOSED_POCKET) {
      for (const cell of pocket) {
        claimCell(game, cell, boundaryOwner);
        budget--;
        if (budget <= 0) break;
      }
    }
  }
}

export function setAutoExpand(game: GameState, enabled: boolean): void {
  game.autoExpand = enabled;
}

export function setAutoSiege(game: GameState, enabled: boolean): void {
  game.factions[0].commander.autoSiege = enabled;
}

export function retreatFromSiege(game: GameState, factionId = PLAYER_ID): string {
  const faction = game.factions[factionId - 1];
  const cmd = faction?.commander;
  if (!cmd || cmd.stance !== "siege") return "Aktif bir kuşatma yok.";
  cmd.siegingCastle = null;
  cmd.stance = "retreat";
  cmd.retreatTicks = 26;
  const castle = nearestCastleCell(game, factionId, cmd.x, cmd.y);
  if (castle !== null) {
    cmd.targetX = castle % game.map.width;
    cmd.targetY = Math.floor(castle / game.map.width);
  }
  if (factionId === PLAYER_ID) game.lastEvent = "Kuşatma kaldırıldı; ordu kaleye çekiliyor.";
  return "";
}

function autoColonise(game: GameState): void {
  // Açık/kapalı ayarı: savaşmayan krallıklar boş toprakları kendiliğinden sömürgeleştirir.
  if (!game.autoExpand || game.tick % 4 !== 0) return;
  for (const faction of game.factions) {
    if (!faction.land) continue;
    const cmd = faction.commander;
    if (cmd.stance !== "idle" && cmd.stance !== "march") continue;
    if (cmd.targetX !== null && cmd.targetY !== null) continue;
    if (cmd.army < 220) continue;
    if (faction.id === PLAYER_ID && game.tick % 30 !== 0) continue;
    if (cmd.regroupTicks > 0) continue;

    const cx = Math.round(cmd.x);
    const cy = Math.round(cmd.y);
    let best: number | null = null;
    let bestScore = Infinity;
    for (let dy = -46; dy <= 46; dy += 2) {
      for (let dx = -46; dx <= 46; dx += 2) {
        const x = cx + dx;
        const y = cy + dy;
        if (x < 0 || x >= game.map.width || y < 0 || y >= game.map.height) continue;
        const cell = y * game.map.width + x;
        if (!game.map.land[cell] || game.owners[cell] !== 0) continue;
        const score = dx * dx + dy * dy;
        if (score < bestScore) {
          bestScore = score;
          best = cell;
        }
      }
    }
    if (best !== null && isInSupplyRange(game, best, faction.id)) {
      commandMove(game, faction.id, best);
    }
  }
}

function evaluateEngagementsAndSieges(game: GameState): void {
  // 1. Validate existing engagements
  for (const f of game.factions) {
    const cmd = f.commander;
    if (cmd.engagedWith !== null) {
      const enemy = game.factions[cmd.engagedWith - 1];
      if (
        !enemy ||
        !enemy.land ||
        getRelation(game, f.id, enemy.id).status !== "war" ||
        enemy.commander.stance === "retreat"
      ) {
        cmd.engagedWith = null;
        if (cmd.stance === "battle") cmd.stance = cmd.targetX !== null ? "march" : "idle";
      }
    }
    if (cmd.siegingCastle !== null) {
      const castle = game.buildings.get(cmd.siegingCastle);
      if (
        !castle ||
        castle.type !== "castle" ||
        getRelation(game, f.id, castle.owner).status !== "war"
      ) {
        cmd.siegingCastle = null;
        if (cmd.stance === "siege") cmd.stance = cmd.targetX !== null ? "march" : "idle";
      }
    }
  }

  // 2. Check Field Battles FIRST between warring Commanders
  for (let i = 0; i < game.factions.length; i++) {
    const a = game.factions[i];
    if (!a.land || a.commander.army < 220 || ["retreat", "embarked"].includes(a.commander.stance)) continue;
    if (a.commander.engagedWith !== null) continue;

    for (let j = i + 1; j < game.factions.length; j++) {
      const b = game.factions[j];
      if (!b.land || b.commander.army < 220 || ["retreat", "embarked"].includes(b.commander.stance)) continue;
      if (b.commander.engagedWith !== null) continue;
      if (getRelation(game, a.id, b.id).status !== "war") continue;

      const distSq = distanceSquaredXY(a.commander.x, a.commander.y, b.commander.x, b.commander.y);
      // If two enemy armies meet in the field (including if one was attempting a siege and defender arrived to relieve!)
      if (distSq <= 8.5 * 8.5) {
        a.commander.siegingCastle = null;
        b.commander.siegingCastle = null;
        a.commander.engagedWith = b.id;
        b.commander.engagedWith = a.id;
        a.commander.stance = "battle";
        b.commander.stance = "battle";

        if (a.id === PLAYER_ID || b.id === PLAYER_ID) {
          const foe = a.id === PLAYER_ID ? b : a;
          game.lastEvent = `${foe.name} ordusuyla meydan muharebesi başladı!`;
        }
        break;
      }
    }
  }

  // 3. Check Castle Sieges (ONLY if not locked in Field Battle, AND enemy army isn't blocking right there)
  for (const attacker of game.factions) {
    const cmd = attacker.commander;
    if (!attacker.land || cmd.army < 200) continue;
    if (cmd.stance === "battle" || cmd.stance === "retreat" || cmd.stance === "embarked" || cmd.siegingCastle !== null) continue;

    let targetCastleIndex: number | null = null;
    let bestDist = Infinity;

    for (const [bIndex, building] of game.buildings) {
      if (building.type !== "castle") continue;
      if (getRelation(game, attacker.id, building.owner).status !== "war") continue;

      const bx = bIndex % game.map.width;
      const by = Math.floor(bIndex / game.map.width);
      const distSq = distanceSquaredXY(cmd.x, cmd.y, bx, by);
      const siegeReach = castleGuardRadius(building.level) * 0.72;
      // Komutan yalnızca hedefi bu kale olduğunda kuşatmaya girer.
      // Kale yanından geçerken otomatik saldırı tetiklenmez.
      const aimedAtCastle =
        cmd.targetX !== null && cmd.targetY !== null &&
        distanceSquaredXY(cmd.targetX, cmd.targetY, bx, by) <= 2.25;
      // Toggle kapalıyken bile kaleye doğrudan tıklamak kuşatma başlatır;
      // sadece yanından geçerken otomatik tetiklenmez.
      if (cmd.stance === "march" && !aimedAtCastle) continue;
      if (!cmd.autoSiege && !aimedAtCastle) continue;
      if (distSq <= siegeReach * siegeReach && distSq < bestDist) {
        // Check if defending Commander is nearby & ready to force a Field Battle BEFORE castle can be besieged
        const defender = game.factions[building.owner - 1];
        const defenderDistToCastleSq = distanceSquaredXY(defender.commander.x, defender.commander.y, bx, by);
        const defenderBlocks =
          defender.commander.army >= 260 &&
          defender.commander.stance !== "retreat" &&
          defender.commander.stance !== "embarked" &&
          defender.commander.engagedWith === null &&
          defenderDistToCastleSq <= 14 * 14;

        if (!defenderBlocks) {
          bestDist = distSq;
          targetCastleIndex = bIndex;
        }
      }
    }

    if (targetCastleIndex !== null) {
      cmd.siegingCastle = targetCastleIndex;
      cmd.stance = "siege";
      // Snap commander just outside the castle walls
      const cx = targetCastleIndex % game.map.width;
      const cy = Math.floor(targetCastleIndex / game.map.width);
      const dx = cmd.x - cx;
      const dy = cmd.y - cy;
      const d = Math.max(0.5, Math.hypot(dx, dy));
      cmd.x = cx + (dx / d) * 2.2;
      cmd.y = cy + (dy / d) * 2.2;

      const castle = game.buildings.get(targetCastleIndex)!;
      const owner = game.factions[castle.owner - 1];
      const enemyAway = distanceSquaredXY(owner.commander.x, owner.commander.y, cx, cy) > 22 * 22;
      if (attacker.id === PLAYER_ID) {
        game.lastEvent = enemyAway
          ? `Arkadanlama! ${owner.name} ordusu uzaktayken Sv.${castle.level} kaleye kuşatma başlatıldı!`
          : `${owner.name} Sv.${castle.level} kalesi kuşatılıyor!`;
      } else if (owner.id === PLAYER_ID) {
        game.lastEvent = `${attacker.name}, Sv.${castle.level} kaleni kuşatıyor!`;
      }
    }
  }
}

function resolveFieldBattles(game: GameState): void {
  const processed = new Set<string>();
  game.lastBattleDice = null;
  for (const a of game.factions) {
    if (!a.land || a.commander.stance !== "battle" || a.commander.engagedWith === null) continue;
    const b = game.factions[a.commander.engagedWith - 1];
    if (!b || !b.land) continue;
    const key = relationKey(a.id, b.id);
    if (processed.has(key)) continue;
    processed.add(key);

    const midX = Math.round((a.commander.x + b.commander.x) / 2);
    const midY = Math.round((a.commander.y + b.commander.y) / 2);
    const cell =
      Math.max(0, Math.min(game.map.height - 1, midY)) * game.map.width +
      Math.max(0, Math.min(game.map.width - 1, midX));
    const terrain = game.map.terrain[cell];
    const terrainDefense = terrain === 4 ? 1.42 : terrain === 3 ? 1.18 : terrain === 2 ? 1.05 : 1.0;

    const aHome = game.owners[cell] === a.id ? terrainDefense : 1.0;
    const bHome = game.owners[cell] === b.id ? terrainDefense : 1.0;
    const armyA = Math.max(1, a.commander.army);
    const armyB = Math.max(1, b.commander.army);
    const closeness = Math.min(armyA, armyB) / Math.max(armyA, armyB);

    // Her çarpışma tikinde iki taraf için 2'şer zar (2d6).
    const aDice: [number, number] = [rollD6(), rollD6()];
    const bDice: [number, number] = [rollD6(), rollD6()];
    const totalA = aDice[0] + aDice[1];
    const totalB = bDice[0] + bDice[1];
    const swing = (totalA - totalB) / 12;
    const diceWeight = 0.12 + 0.55 * Math.max(0, closeness - 0.5);
    if (a.id === PLAYER_ID || b.id === PLAYER_ID) {
      game.lastBattleDice = { aId: a.id, bId: b.id, aDice, bDice, totalA, totalB, swing };
    }

    const powerA = Math.max(
      1,
      Math.sqrt(Math.max(100, armyA)) * (1 + a.buildingLevels.barracks * 0.04) * aHome *
        Math.max(0.65, 1 + swing * diceWeight),
    );
    const powerB = Math.max(
      1,
      Math.sqrt(Math.max(100, armyB)) * (1 + b.buildingLevels.barracks * 0.04) * bHome *
        Math.max(0.65, 1 - swing * diceWeight),
    );

    const lossA = Math.max(48, (powerB / Math.max(1, powerA)) * 165 + armyB * 0.011);
    const lossB = Math.max(48, (powerA / Math.max(1, powerB)) * 165 + armyA * 0.011);

    a.commander.army = Math.max(0, a.commander.army - lossA);
    b.commander.army = Math.max(0, b.commander.army - lossB);

    const rel = getRelation(game, a.id, b.id);
    if (a.id < b.id) {
      rel.warLossesA += lossA;
      rel.warLossesB += lossB;
    } else {
      rel.warLossesA += lossB;
      rel.warLossesB += lossA;
    }

    if (game.tick % 4 === 0) {
      game.effects.push({ index: cell, x: midX, y: midY, started: game.tick, type: "battle" });
    }

    const aDiceBreak =
      closeness > 0.78 &&
      totalB - totalA >= 7 &&
      a.commander.army < b.commander.army * 1.12 &&
      Math.random() < 0.07;
    const bDiceBreak =
      closeness > 0.78 &&
      totalA - totalB >= 7 &&
      b.commander.army < a.commander.army * 1.12 &&
      Math.random() < 0.07;

    const aDefeated =
      a.commander.army <= 220 ||
      (a.commander.army < b.commander.army * 0.24 && a.commander.army < 1300) ||
      aDiceBreak;
    const bDefeated =
      b.commander.army <= 220 ||
      (b.commander.army < a.commander.army * 0.24 && b.commander.army < 1300) ||
      bDiceBreak;

    if (aDefeated || bDefeated) {
      const winner = aDefeated ? b : a;
      const loser = aDefeated ? a : b;

      winner.commander.engagedWith = null;
      winner.commander.targetX = null;
      winner.commander.targetY = null;
      winner.commander.stance = "idle";

      loser.commander.engagedWith = null;
      loser.commander.stance = "retreat";
      loser.commander.retreatTicks = 150;
      loser.commander.regroupTicks = 520;
      // Bozguna uğrayan ordu kendi kışlasına/kalesine çekilip ihtiyattan asker toplar.
      let rally = nearestRallyCell(game, loser.id, loser.commander.x, loser.commander.y) ??
        nearestCastleCell(game, loser.id, loser.commander.x, loser.commander.y);
      if (rally === null && loser.tiles.size > 0) {
        let bestDist = Infinity;
        for (const tile of loser.tiles) {
          const d = distanceSquaredXY(
            tile % game.map.width,
            Math.floor(tile / game.map.width),
            loser.commander.x,
            loser.commander.y,
          );
          if (d < bestDist) { bestDist = d; rally = tile; }
        }
      }
      if (rally !== null) {
        loser.commander.targetX = rally % game.map.width;
        loser.commander.targetY = Math.floor(rally / game.map.width);
        const startX = Math.max(0, Math.min(game.map.width - 1, Math.round(loser.commander.x)));
        const startY = Math.max(0, Math.min(game.map.height - 1, Math.round(loser.commander.y)));
        loser.commander.route =
          findLandRoute(game, loser.id, startY * game.map.width + startX, rally, true) ?? [];
      }
      // Kuşatma silahları orduyla taşınır: bozgunda yarısı kaybolur, kazanan birazını ele geçirir.
      const lostWeapons = Math.floor(loser.commander.siegeWeapons * 0.5);
      loser.commander.siegeWeapons -= lostWeapons;
      winner.commander.siegeWeapons += Math.min(2, lostWeapons);
      loser.reserveTroops = Math.floor(loser.reserveTroops * 0.42);
      loser.commander.army = Math.max(80, Math.floor(loser.commander.army * 0.45));
      loser.exhaustionUntil = game.tick + 520;
      game.trainingOrders = game.trainingOrders.filter((order) => order.owner !== loser.id);
      const ownsStructure = [...game.buildings.values()].some((building) => building.owner === loser.id);
      if (!ownsStructure && loser.land <= 40) {
        // Sığınacak kalesi/kışlası kalmayan devlet teslim olur; hazinesi galibe geçer.
        winner.gold += loser.gold;
        loser.gold = 0;
        for (const cell of [...loser.tiles]) claimCell(game, cell, winner.id);
        loser.commander.army = 0;
        loser.reserveTroops = 0;
        loser.commander.stance = "idle";
        if (winner.id === PLAYER_ID) {
          game.lastEvent = `${loser.name} teslim oldu! Hazinesi senin.`;
          pushNotification(game, {
            kind: "info",
            title: "Krallık teslim oldu",
            message: `${loser.name} savaşta yıkıldı; altınları hazinene eklendi.`,
            fromId: loser.id,
            fromName: loser.name,
            fromColor: loser.color,
            actionable: false,
          }, 220);
        }
        continue;
      }
      if (loser.id === PLAYER_ID || winner.id === PLAYER_ID) {
        pushNotification(game, {
          kind: "info",
          title: loser.id === PLAYER_ID ? "Ordun toparlanıyor" : "Düşman bozguna uğradı",
          message:
            loser.id === PLAYER_ID
              ? "Ordun kışlana çekiliyor; ihtiyattan asker toplayacak. Kaleni koru."
              : `${loser.name} ordusu kışlasına çekildi. Kale dışındaki topraklarını ilhak edebilirsin.`,
          fromId: loser.id === PLAYER_ID ? winner.id : loser.id,
          fromName: loser.id === PLAYER_ID ? winner.name : loser.name,
          fromColor: loser.id === PLAYER_ID ? winner.color : loser.color,
          actionable: false,
        }, 180);
      }

      if (winner.id === PLAYER_ID) {
        game.lastEvent = `Meydan muharebesi kazanıldı! ${loser.name} ordusu bozguna uğradı!`;
      } else if (loser.id === PLAYER_ID) {
        game.lastEvent = `${winner.name} meydan muharebesini kazandı! Ordun kaleye çekiliyor.`;
      }
    }
  }
}

const SUPPLY_DECAY_PERIOD = 770; // 1 gerçek dakika (770 × 0,078 sn)

export function isCastleEncircled(game: GameState, castleIndex: number, defenderId: number): boolean {
  const W = game.map.width;
  const H = game.map.height;
  const cx = castleIndex % W;
  const cy = Math.floor(castleIndex / W);
  const radius = 24;
  const hostileTiles = [];
  for (let dy = -radius; dy <= radius; dy += 3) {
    for (let dx = -radius; dx <= radius; dx += 3) {
      if (dx * dx + dy * dy > radius * radius) continue;
      const x = cx + dx;
      const y = cy + dy;
      if (x < 0 || x >= W || y < 0 || y >= H) continue;
      const cell = y * W + x;
      if (!game.map.land[cell]) continue;
      hostileTiles.push(game.owners[cell]);
    }
  }
  if (!hostileTiles.length) return false;
  const hostile = hostileTiles.filter((owner) => owner !== defenderId && owner !== 0).length;
  return hostile / hostileTiles.length >= 0.55 && activeWarEnemies(game, defenderId).length > 0;
}

function applyCastleAttrition(game: GameState): void {
  if (game.tick % SUPPLY_DECAY_PERIOD !== 0 || game.tick === 0) return;
  for (const [index, building] of game.buildings) {
    if (building.type !== "castle") continue;
    const owner = building.owner;
    const ownCastles = [...game.buildings.values()].filter(
      (other) => other.owner === owner && other.type === "castle" && other.wallHp > 0,
    ).length;
    if (ownCastles !== 1) continue;
    if (!isCastleEncircled(game, index, owner)) continue;

    if (building.level > 1) {
      building.level--;
      building.maxWallHp = castleMaxWall(building.level);
      const faction = game.factions[owner - 1];
      if (faction) faction.buildingLevels.castle = Math.max(0, faction.buildingLevels.castle - 1);
    }
    building.wallHp = Math.max(60, Math.round(building.wallHp * 0.72));
    game.revision++;
    if (owner === PLAYER_ID || activeWarEnemies(game, PLAYER_ID).includes(owner)) {
      game.lastEvent = `İkmalsiz kalan son kale bir seviye düştü (Sv.${building.level}).`;
    }
  }
}

function resolveCastleSieges(game: GameState): void {
  for (const attacker of game.factions) {
    const cmd = attacker.commander;
    if (!attacker.land || cmd.stance !== "siege" || cmd.siegingCastle === null) continue;

    const castleIndex = cmd.siegingCastle;
    const castle = game.buildings.get(castleIndex);
    if (!castle || castle.type !== "castle") {
      cmd.siegingCastle = null;
      cmd.stance = cmd.targetX !== null ? "march" : "idle";
      continue;
    }

    const defender = game.factions[castle.owner - 1];
    // Kuşatma her oyun saniyesinde bir çözülür; render/tick başına yüzlerce asker düşmez.
    if ((game.tick + attacker.id * 7) % 13 !== 0) continue;
    const wallRatio = Math.max(0, castle.wallHp / Math.max(1, castle.maxWallHp));
    // Kuşatma kaybı kuvvetin küçük bir yüzdesidir; tek can kalmış sur bile orduyu silmez.
    const attrition = 3 + Math.min(24, cmd.army * 0.0006) * (0.28 + wallRatio * 0.3);
    cmd.army = Math.max(0, cmd.army - attrition);

    const siegeBase = 24 + Math.sqrt(Math.max(100, cmd.army)) * 0.68;
    const siegeBonus = 1 + Math.min(1.05, attacker.commander.siegeWeapons * 0.16);
    castle.wallHp = Math.max(0, castle.wallHp - siegeBase * siegeBonus);

    const rel = getRelation(game, attacker.id, defender.id);
    if (attacker.id < defender.id) rel.warLossesA += attrition;
    else rel.warLossesB += attrition;

    if (cmd.army < 170) {
      // Besieging force broke on the walls!
      cmd.siegingCastle = null;
      cmd.stance = "retreat";
      cmd.retreatTicks = 24;
      if (attacker.id === PLAYER_ID) {
        game.lastEvent = `Sv.${castle.level} kale surları önünde ordun tükendi! Kuşatma başarısız.`;
      } else if (defender.id === PLAYER_ID) {
        game.lastEvent = `Sv.${castle.level} kalen ${attacker.name} kuşatmasını püskürttü!`;
      }
      continue;
    }

    if (castle.wallHp <= 0) {
      // Castle walls breached -> entire fortified province surrenders to conqueror!
      const cx = castleIndex % game.map.width;
      const cy = Math.floor(castleIndex / game.map.width);
      const domainR = castleDomainRadius(castle.level);
      const prevOwnerId = castle.owner;

      for (let dy = -domainR; dy <= domainR; dy++) {
        for (let dx = -domainR; dx <= domainR; dx++) {
          if (dx * dx + dy * dy > domainR * domainR + 0.5) continue;
          const x = cx + dx;
          const y = cy + dy;
          if (x < 0 || x >= game.map.width || y < 0 || y >= game.map.height) continue;
          const cell = y * game.map.width + x;
          if (game.owners[cell] === prevOwnerId) {
            claimCell(game, cell, attacker.id);
          }
        }
      }

      // Reset captured castle walls to 35%
      const capturedCastle = game.buildings.get(castleIndex);
      if (capturedCastle) {
        capturedCastle.wallHp = Math.floor(capturedCastle.maxWallHp * 0.35);
      }

      cmd.siegingCastle = null;
      cmd.stance = cmd.targetX !== null ? "march" : "idle";

      game.effects.push({ index: castleIndex, x: cx, y: cy, started: game.tick, type: "siege_fall" });

      if (attacker.id === PLAYER_ID) {
        game.lastEvent = `${defender.name} kalesi düştü! Bölge tamamen senin kontrolünde!`;
      } else if (prevOwnerId === PLAYER_ID) {
        game.lastEvent = `${attacker.name} Sv.${castle.level} kaleni ele geçirdi!`;
      }

      // Son kalesi düşen devletin hazinesi galip devlete geçer.
      if (defender.buildings.castle === 0) {
        const spoils = Math.floor(defender.gold);
        if (spoils > 0) {
          attacker.gold += spoils;
          defender.gold = 0;
          if (attacker.id === PLAYER_ID) {
            game.lastEvent = `${defender.name} kalesi düştü! Hazinesinden ${formatNumber(spoils)} altın ele geçirdin.`;
            pushNotification(game, {
              kind: "info",
              title: "Hazine ele geçirildi",
              message: `${defender.name} krallığının ${formatNumber(spoils)} altını hazinene eklendi.`,
              fromId: defender.id,
              fromName: defender.name,
              fromColor: defender.color,
              actionable: false,
            }, 220);
          }
        }
      }
      // If defender lost its last castle and has very little left, remaining tiles surrender
      if (defender.buildings.castle === 0 && defender.land > 0 && defender.land < 35) {
        for (const leftover of [...defender.tiles]) {
          claimCell(game, leftover, attacker.id);
        }
        defender.commander.army = 0;
        defender.reserveTroops = 0;
      }
    }
  }
}

function findNeutralTarget(game: GameState, faction: Faction): number | null {
  if (!faction.tiles.size) return null;
  const tileArr = [...faction.tiles];
  for (let attempt = 0; attempt < 45; attempt++) {
    const src = tileArr[Math.floor(Math.random() * tileArr.length)];
    for (const n of cellNeighbors8(src, game.map.width, game.map.height)) {
      if (game.map.land[n] && game.owners[n] === 0) {
        // Aim a few tiles deeper into the neutral area so the commander marches cleanly
        const sx = src % game.map.width;
        const sy = Math.floor(src / game.map.width);
        const nx = n % game.map.width;
        const ny = Math.floor(n / game.map.width);
        const tx = Math.max(0, Math.min(game.map.width - 1, nx + (nx - sx) * 4));
        const ty = Math.max(0, Math.min(game.map.height - 1, ny + (ny - sy) * 4));
        const deep = ty * game.map.width + tx;
        return game.map.land[deep] && game.owners[deep] === 0 ? deep : n;
      }
    }
  }
  return null;
}

function findNeighborFactions(game: GameState, faction: Faction): number[] {
  const neighbors = new Set<number>();
  const tileArr = [...faction.tiles];
  const sampleStep = Math.max(1, Math.floor(tileArr.length / 60));
  for (let i = 0; i < tileArr.length; i += sampleStep) {
    const cell = tileArr[i];
    for (const n of cellNeighbors(cell, game.map.width, game.map.height)) {
      const owner = game.owners[n];
      if (owner > 0 && owner !== faction.id) neighbors.add(owner);
    }
  }
  return [...neighbors];
}

function tickAI(game: GameState): void {
  const diffAggro = game.difficulty === "hard" ? 1.25 : game.difficulty === "easy" ? 0.65 : 1.0;

  // 1. AI Economy: aynı noktaya yığmak yerine vilayetlere ve sınırlara yatırım yapar.
  for (const bot of game.factions.slice(1)) {
    if (!bot.land) continue;
    if ((game.tick + bot.id * 5) % 18 !== 0) continue;

    const desiredCastles = Math.max(2, Math.min(12, 2 + Math.floor(bot.land / 135)));
    const fortTarget = Math.min(3, desiredCastles);
    const nextCastleCost = getBuildingCost("castle", bot.buildings.castle);
    // İlk 3 kale kurulana kadar bot altını kale için biriktirir;
    // eğitim/yükseltme/liman harcamaları kaleyi ertelemez.
    if (bot.buildings.castle < fortTarget && bot.gold < nextCastleCost + 250) continue;

    const total = getTotalTroops(bot);
    const cap = getCapacity(bot);
    const { cost: rCost } = getRecruitValues(bot);
    if (bot.gold >= rCost + 150 && total < cap * 0.97) {
      const barracks = [...game.buildings.entries()].filter(
        ([, building]) => building.owner === bot.id && building.type === "barracks",
      );
      if (barracks.length) {
        const [index] = barracks[(game.tick / 32 + bot.id) % barracks.length | 0];
        recruitTroops(game, bot.id, index);
      }
    }

    const desiredTowns = Math.max(1, Math.min(5, 1 + Math.floor(bot.land / 460)));
    const desiredBarracks = Math.max(1, Math.min(5, Math.floor(bot.buildingLevels.town * 0.8) + 1));
    const desiredMarkets = Math.max(1, Math.min(4, Math.floor(bot.buildingLevels.town * 0.65) + 1));
    const desiredPorts = Math.min(8, Math.floor(desiredCastles / 1.5) + 1);

    // Botlar kalelerini erken yükseltir: "kale basmayan yapay zeka" sorununun çözümü.
    const desiredCastleLevel = Math.min(MAX_STRUCTURE_LEVEL, 2 + Math.floor(bot.land / 900));
    const ownCastles = [...game.buildings.entries()]
      .filter(([, building]) => building.owner === bot.id && building.type === "castle")
      .sort((a, b) => a[1].level - b[1].level);
    const weakestCastle = ownCastles[0];
    // Önce görünür yeni kaleler kurulur; seviye yükseltme ikinci kale sonrası başlar.
    if (bot.buildings.castle >= 2 && weakestCastle && weakestCastle[1].level < desiredCastleLevel) {
      const castleCost = upgradeCost(weakestCastle[1]);
      if (castleCost !== null && bot.gold >= castleCost + 250) {
        upgradeStructureForFaction(game, weakestCastle[0], bot.id);
      }
    }

    // İleri kale için boş sınır hücrelerini de aday havuzuna ekle.
    const frontierNeutral = new Set<number>();
    for (const tile of bot.tiles) {
      for (const n of cellNeighbors8(tile, game.map.width, game.map.height)) {
        if (game.map.land[n] && game.owners[n] === 0) frontierNeutral.add(n);
      }
    }

    const options = ([
      { type: "town", need: desiredTowns - bot.buildings.town },
      { type: "castle", need: desiredCastles - bot.buildings.castle },
      { type: "barracks", need: desiredBarracks - bot.buildings.barracks },
      { type: "market", need: desiredMarkets - bot.buildings.market },
      { type: "port", need: desiredPorts - bot.buildings.port },
    ] satisfies Array<{ type: BuildingType; need: number }>).sort(
      (a, b) =>
        b.need + (b.type === "castle" ? 7 : 0) - (a.need + (a.type === "castle" ? 7 : 0)),
    );

    let built = false;
    for (const option of options) {
      const cost = getBuildingCost(option.type, bot.buildings[option.type]);
      if (option.need <= 0 || bot.gold < cost) continue;
      const tileArr =
        option.type === "castle"
          ? [...bot.tiles, ...frontierNeutral]
          : [...bot.tiles];
      const step = Math.max(1, Math.floor(tileArr.length / 360));
      let bestCell: number | null = null;
      let bestScore = -Infinity;

      for (let i = 0; i < tileArr.length; i += step) {
        const candidate = tileArr[i];
        if (game.buildings.has(candidate)) continue;
        if (getBuildingPlacementError(game, candidate, option.type, bot.id)) continue;
        const border = cellNeighbors(candidate, game.map.width, game.map.height).filter(
          (n) => game.map.land[n] && game.owners[n] !== bot.id,
        ).length;
        let nearestCastle = 60;
        for (const [castleIndex, building] of game.buildings) {
          if (building.owner === bot.id && building.type === "castle") {
            nearestCastle = Math.min(nearestCastle, Math.sqrt(distanceSquared(castleIndex, candidate, game.map.width)));
          }
        }
        let score = Math.random() * 2;
        if (option.type === "castle") {
          score += border * 12 + Math.min(50, nearestCastle) * 0.22;
          if (!isInSupplyRange(game, candidate, bot.id)) score += 120;
          if (game.owners[candidate] === 0) score += 35;
        } else if (option.type === "port") {
          score += border * 2 + nearestCastle * 0.08;
        } else {
          score += 22 - Math.abs(15 - nearestCastle) + border * (option.type === "barracks" ? 2 : -1.5);
        }
        if (score > bestScore) {
          bestScore = score;
          bestCell = candidate;
        }
      }

      if (bestCell !== null && placeBuildingForFaction(game, bot, bestCell, option.type)) {
        built = true;
        break;
      }
    }

    // Kalan altını kale/liman/kışla seviyelerine yatırır.
    if (!built && bot.gold >= 1400 && bot.buildings.castle >= 2) {
      const priority = (t: BuildingType): number =>
        t === "castle" ? 4 : t === "port" ? 3 : t === "barracks" ? 2 : 1;
      const upgradeCandidates = [...game.buildings.entries()]
        .filter(([, building]) => building.owner === bot.id && upgradeCost(building) !== null)
        .sort(
          (a, b) => priority(b[1].type) - priority(a[1].type) || a[1].level - b[1].level,
        );
      for (const [index, building] of upgradeCandidates) {
        const uCost = upgradeCost(building);
        if (uCost !== null && bot.gold >= uCost + 350) {
          upgradeStructureForFaction(game, index, bot.id);
          break;
        }
      }
    }
  }

  // 2. AI Diplomacy (Targeted wars & natural peace treaties, NEVER chaotic total war!)
  if (game.tick > 110) {
    for (const bot of game.factions.slice(1)) {
      if (!bot.land || (game.tick + bot.id * 5) % 24 !== 0) continue;

      const wars = activeWarEnemies(game, bot.id);

      // Evaluate peace treaties / offers if war dragged on or losing badly
      if (wars.length > 0) {
        for (const enemyId of wars) {
          const rel = getRelation(game, bot.id, enemyId);
          const warAge = game.tick - rel.warStartTick;
          const enemy = game.factions[enemyId - 1];
          const weakNow = bot.commander.army < 650 && bot.reserveTroops < 1400;
          const stalemate = warAge > 210 && Math.random() < 0.25;
          const losing = bot.buildings.castle <= 1 && getTotalTroops(bot) < getTotalTroops(enemy) * 0.55;

          if ((weakNow || stalemate || losing) && warAge > 65) {
            if (enemyId === PLAYER_ID) {
              const alreadyOffered = game.offers.some((o) => o.fromId === bot.id && o.type === "peace");
              if (!alreadyOffered && game.tick >= bot.peaceOfferFromPlayerCooldown) {
                pushDiplomaticOffer(game, bot.id, "peace", 90);
                bot.peaceOfferFromPlayerCooldown = game.tick + 120;
                game.lastEvent = `${bot.name} barış teklif ediyor!`;
              }
            } else if (Math.random() < 0.55) {
              proposePeace(game, bot.id, enemyId);
              break;
            }
          }
        }
        continue;
      }

      // Müttefikler bazen ittifakı bozar; duyurusu sağ alt bildirimde görünür.
      const playerRelation = getRelation(game, bot.id, PLAYER_ID);
      if (
        playerRelation.status === "alliance" &&
        game.tick - playerRelation.sinceTick > 260 &&
        (game.tick + bot.id * 11) % 96 === 0 &&
        Math.random() < 0.12
      ) {
        setRelation(game, bot.id, PLAYER_ID, "truce", 120);
        pushNotification(game, {
          kind: "alliance_broken",
          title: `${bot.name} ittifakı bozdu`,
          message: `${bot.name} ittifaktan çekildi. Kısa süreli ateşkes yürürlükte.`,
          fromId: bot.id,
          fromName: bot.name,
          fromColor: bot.color,
          actionable: false,
        });
      }

      // Ekranı doldurmamak için aynı anda en fazla 1 bekleyen diplomatik teklif gösterilir.
      if (
        !wars.length &&
        game.offers.length === 0 &&
        (playerRelation.status === "peace" || playerRelation.status === "truce") &&
        (game.tick + bot.id * 17) % 240 === 0 &&
        Math.random() < 0.09
      ) {
        pushDiplomaticOffer(game, bot.id, "alliance", 150);
      }

      // Not currently in any war -> consider declaring ONE focused war if ready & cooldown passed
      if (game.tick < bot.warCooldownUntil) continue;
      const total = getTotalTroops(bot);
      if (total < 6200) continue;

      const neighbors = findNeighborFactions(game, bot);
      if (!neighbors.length) continue;

      // Pick a peaceful neighbor without truce/alliance
      const candidates = neighbors.filter((nid) => {
        const rel = getRelation(game, bot.id, nid);
        if (rel.status !== "peace") return false;
        const target = game.factions[nid - 1];
        // Don't start suicidal war against someone 3x bigger unless Hard mode desperation
        return total * diffAggro >= getTotalTroops(target) * 0.65;
      });

      if (candidates.length > 0 && Math.random() < 0.22 * diffAggro) {
        const targetId = candidates[Math.floor(Math.random() * candidates.length)];
        declareWar(game, bot.id, targetId);
        bot.warCooldownUntil = game.tick + 170;
      } else {
        bot.warCooldownUntil = game.tick + 30;
      }
    }
  }

  // 3. AI Commander Movement (Defend besieged/threatened castles, intercept invaders, or push!)
  for (const bot of game.factions.slice(1)) {
    if (!bot.land || (game.tick + bot.id) % 5 !== 0) continue;
    const cmd = bot.commander;
    if (cmd.regroupTicks > 0) continue;
    if (cmd.stance === "battle" || cmd.stance === "retreat" || cmd.stance === "embarked") continue;
    if (cmd.army < 1200) continue;

    const wars = activeWarEnemies(game, bot.id);
    if (wars.length > 0) {
      // Check if any own castle is under siege or threatened
      let urgentTarget: number | null = null;
      let urgentDist = Infinity;

      for (const enemyId of wars) {
        const enemy = game.factions[enemyId - 1];
        if (!enemy.land) continue;
        if (enemy.commander.siegingCastle !== null) {
          const castle = game.buildings.get(enemy.commander.siegingCastle);
          if (castle && castle.owner === bot.id) {
            urgentTarget = enemy.commander.siegingCastle;
            break;
          }
        }
        // Check if enemy commander is close to our territory/castle
        const nearCastle = nearestCastleCell(game, bot.id, enemy.commander.x, enemy.commander.y);
        if (nearCastle !== null) {
          const d = distanceSquaredXY(
            enemy.commander.x,
            enemy.commander.y,
            nearCastle % game.map.width,
            Math.floor(nearCastle / game.map.width),
          );
          if (d < 22 * 22 && d < urgentDist) {
            urgentDist = d;
            urgentTarget = Math.round(enemy.commander.y) * game.map.width + Math.round(enemy.commander.x);
          }
        }
      }

      if (urgentTarget !== null) {
        if (cmd.siegingCastle === null) {
          commandMove(game, bot.id, urgentTarget);
        }
        continue;
      }

      // Otherwise if we aren't already sieging or marching on an enemy castle, march toward an enemy castle!
      if (cmd.siegingCastle === null && cmd.targetX === null) {
        const enemyId = wars[Math.floor(Math.random() * wars.length)];
        const targetCastle = nearestCastleCell(game, enemyId, cmd.x, cmd.y);
        if (targetCastle !== null) {
          commandMove(game, bot.id, targetCastle);
        } else {
          const enemy = game.factions[enemyId - 1];
          const firstTile = enemy.tiles.values().next().value;
          if (firstTile !== undefined) commandMove(game, bot.id, firstTile);
        }
      }
      continue;
    }

    // Peaceful expansion into unclaimed land — bots aggressively colonise open space
    if (cmd.targetX === null && cmd.army > 450) {
      const neutral = findNeutralTarget(game, bot);
      if (neutral !== null) {
        commandMove(game, bot.id, neutral);
      }
    }
  }
}

function seaCellsNearPort(game: GameState, portIndex: number): number[] {
  return cellNeighbors8(portIndex, game.map.width, game.map.height).filter((cell) => !game.map.land[cell]);
}

export function getSeaRoute(game: GameState, fromPort: number, toPort: number): number[] | null {
  const cacheKey = `${fromPort}:${toPort}`;
  if (game.seaRouteCache.has(cacheKey)) return game.seaRouteCache.get(cacheKey) || null;

  const starts = seaCellsNearPort(game, fromPort);
  const targets = new Set(seaCellsNearPort(game, toPort));
  if (!starts.length || !targets.size) {
    game.seaRouteCache.set(cacheKey, null);
    return null;
  }

  const size = game.map.width * game.map.height;
  const previous = new Int32Array(size);
  previous.fill(-2);
  const queue = new Int32Array(size);
  let head = 0;
  let tail = 0;
  for (const start of starts) {
    previous[start] = -1;
    queue[tail++] = start;
  }

  let found = -1;
  while (head < tail) {
    const current = queue[head++];
    if (targets.has(current)) {
      found = current;
      break;
    }
    for (const next of cellNeighbors8(current, game.map.width, game.map.height)) {
      if ((game.map.land[next] && !game.map.waterways[next]) || previous[next] !== -2) continue;
      previous[next] = current;
      queue[tail++] = next;
    }
  }

  if (found === -1) {
    game.seaRouteCache.set(cacheKey, null);
    return null;
  }

  const reversed: number[] = [];
  let cursor = found;
  while (cursor >= 0) {
    reversed.push(cursor);
    cursor = previous[cursor];
  }
  reversed.reverse();
  // Noktaları seyreltmeden sakla: gemiler kıyının/karanın üzerinden geçemez.
  game.seaRouteCache.set(cacheKey, reversed);
  return reversed;
}

export function getPathPosition(path: number[], progress: number, mapWidth: number): { x: number; y: number; cell: number } {
  if (!path.length) return { x: 0, y: 0, cell: 0 };
  const clamped = Math.max(0, Math.min(path.length - 1, progress));
  const low = Math.floor(clamped);
  const high = Math.min(path.length - 1, low + 1);
  const mix = clamped - low;
  const a = path[low];
  const b = path[high];
  const ax = a % mapWidth;
  const ay = Math.floor(a / mapWidth);
  const bx = b % mapWidth;
  const by = Math.floor(b / mapWidth);
  return {
    x: ax + (bx - ax) * mix,
    y: ay + (by - ay) * mix,
    cell: mix < 0.5 ? a : b,
  };
}

export function lerpAngle(current: number, target: number, factor: number): number {
  const tau = Math.PI * 2;
  let diff = (((target - current + Math.PI) % tau) + tau) % tau - Math.PI;
  if (diff <= -Math.PI) diff += tau;
  return current + diff * factor;
}

export function getShipPose(
  game: GameState,
  path: number[],
  progress: number,
  direction: 1 | -1,
): { x: number; y: number; heading: number; cell: number } {
  const W = game.map.width;
  const H = game.map.height;
  if (!path.length) return { x: 0, y: 0, heading: 0, cell: 0 };
  const clamped = Math.max(0, Math.min(path.length - 1, progress));

  // Geniş pencere (stride=4) üzerinden Catmull-Rom: ızgara köşelerini tamamen eritip
  // açık denizde gerçek gemi rotası gibi geniş ve yumuşak kavisler oluşturur.
  const stride = Math.min(4, Math.max(1, Math.floor(path.length / 5)));
  const seg = clamped / stride;
  const segIdx = Math.floor(seg);
  const t = seg - segIdx;
  const baseIdx = segIdx * stride;

  const point = (index: number): [number, number] => {
    const cell = path[Math.max(0, Math.min(path.length - 1, index))];
    let cx = cell % W;
    let cy = Math.floor(cell / W);
    // Kıyı piksellerinden 0.45 birim açık denize doğru iterek karaya sürtünmeyi önle
    let pushX = 0;
    let pushY = 0;
    for (let dy = -1; dy <= 1; dy++) {
      for (let dx = -1; dx <= 1; dx++) {
        if (dx === 0 && dy === 0) continue;
        const nx = cx + dx;
        const ny = cy + dy;
        if (nx >= 0 && nx < W && ny >= 0 && ny < H && game.map.land[ny * W + nx]) {
          pushX -= dx * 0.18;
          pushY -= dy * 0.18;
        }
      }
    }
    return [cx + pushX, cy + pushY];
  };

  const [x0, y0] = point(baseIdx - stride);
  const [x1, y1] = point(baseIdx);
  const [x2, y2] = point(baseIdx + stride);
  const [x3, y3] = point(baseIdx + stride * 2);

  const smoothX =
    0.5 *
    (2 * x1 +
      (-x0 + x2) * t +
      (2 * x0 - 5 * x1 + 4 * x2 - x3) * t * t +
      (-x0 + 3 * x1 - 3 * x2 + x3) * t * t * t);
  const smoothY =
    0.5 *
    (2 * y1 +
      (-y0 + y2) * t +
      (2 * y0 - 5 * y1 + 4 * y2 - y3) * t * t +
      (-y0 + 3 * y1 - 3 * y2 + y3) * t * t * t);
  const dx =
    0.5 *
    (-x0 + x2 + 2 * (2 * x0 - 5 * x1 + 4 * x2 - x3) * t + 3 * (-x0 + 3 * x1 - 3 * x2 + x3) * t * t);
  const dy =
    0.5 *
    (-y0 + y2 + 2 * (2 * y0 - 5 * y1 + 4 * y2 - y3) * t + 3 * (-y0 + 3 * y1 - 3 * y2 + y3) * t * t);

  const px = Math.max(0, Math.min(W - 1, smoothX));
  const py = Math.max(0, Math.min(H - 1, smoothY));
  const roundedX = Math.round(px);
  const roundedY = Math.round(py);
  const cell = roundedY * W + roundedX;
  const fallback = getPathPosition(path, clamped, W);
  if (game.map.land[cell]) {
    const heading = Math.atan2((fallback.y - y1) * direction, (fallback.x - x1) * direction);
    return { x: fallback.x, y: fallback.y, heading, cell: fallback.cell };
  }
  const heading = Math.atan2(dy * direction, dx * direction || 0.0001);
  return { x: px, y: py, heading, cell };
}

export function calculateTradeIncome(
  distanceCells: number,
  markets: number,
  _allied: boolean,
  portsOwned = 1,
): number {
  // OpenFront: gelir liman mesafesine göre sigmoid (bükülme noktası 300 tile)
  // + doğrusal mesafe terimi; liman sayısı hiperbolik bonus verir.
  const tiles = distanceCells * 2.2;
  const sigmoid = 1 / (1 + Math.exp(-0.0169 * (tiles - 320)));
  const openFrontValue = 115000 * sigmoid + 27 * tiles;
  const portBonus = 1 + (2 * Math.max(0, portsOwned - 1)) / (portsOwned + 4);
  const marketMultiplier = 1 + Math.min(0.5, markets * 0.1);
  return Math.round(openFrontValue * 0.00028 * portBonus * marketMultiplier);
}

export function tradeDistance(portA: number, portB: number, width: number): number {
  const ax = portA % width;
  const ay = Math.floor(portA / width);
  const bx = portB % width;
  const by = Math.floor(portB / width);
  return Math.abs(ax - bx) + Math.abs(ay - by); // Manhattan mesafe
}

function findTradeDestination(game: GameState, fromPort: number, owner: number): {
  toPort: number;
  path: number[];
  distance: number;
  allied: boolean;
} | null {
  const candidates: Array<{ toPort: number; distance: number; allied: boolean; level: number }> = [];

  // Portu olan herkesle ticaret: barış/ateşkes/ittifak şartı yok.
  // Yalnızca savaş halindeki çift ve o çifte ait geçici ambargo kesilir.
  for (const [index, building] of game.buildings) {
    if (index === fromPort || building.type !== "port" || building.owner === owner) continue;
    if (isTradeBlocked(game, owner, building.owner)) continue;
    if (getRelation(game, owner, building.owner).status === "war") continue;
    const distance = tradeDistance(fromPort, index, game.map.width);
    if (distance < 12) continue;
    candidates.push({
      toPort: index,
      distance,
      allied: getRelation(game, owner, building.owner).status === "alliance",
      level: building.level,
    });
  }
  candidates.sort((a, b) => b.distance * (1 + 0.2 * (b.level - 1)) - a.distance * (1 + 0.2 * (a.level - 1)));
  if (!candidates.length) return null;

  // Aynı limanın gemileri uzun süre aynı rotada konvoy gibi gider.
  const rotate = (Math.floor(game.tick / 180) + fromPort) % Math.min(3, candidates.length);
  const ordered = [...candidates.slice(rotate), ...candidates.slice(0, rotate)];
  for (const candidate of ordered.slice(0, 6)) {
    const path = getSeaRoute(game, fromPort, candidate.toPort);
    if (path && path.length > 6) return { ...candidate, path, distance: candidate.distance };
  }
  return null;
}

function spawnTradeShips(game: GameState): void {
  // Liman başına az sayıda gemi, aralıklı ve yumuşak konvoy.
  if (game.tick % 22 !== 0 || game.tradeShips.length >= 70) return;
  for (const [portIndex, port] of game.buildings) {
    if (port.type !== "port" || port.owner <= 0) continue;
    const faction = game.factions[port.owner - 1];
    if (!faction) continue;
    const maxPerPort = 3 + port.level;
    const ownedShips = game.tradeShips.filter(
      (ship) => ship.owner === port.owner && ship.fromPort === portIndex,
    ).length;
    if (ownedShips >= maxPerPort || Math.random() > 0.7) continue;
    const route = findTradeDestination(game, portIndex, port.owner);
    if (!route) continue;
    const convoySize = Math.min(1 + Math.ceil(port.level / 3), maxPerPort - ownedShips, 2);
    const baseCargo = calculateTradeIncome(
      route.distance,
      faction.buildingLevels.market,
      route.allied,
      faction.buildingLevels.port,
    );
    const cargo = Math.max(2, Math.round(baseCargo / Math.max(2, convoySize * 0.75)));

    for (let i = 0; i < convoySize; i++) {
      const startProgress = Math.min(route.path.length - 1, i * 6.5);
      const pose = getShipPose(game, route.path, startProgress, 1);
      game.tradeShips.push({
        id: game.nextShipId++,
        owner: port.owner,
        fromPort: portIndex,
        toPort: route.toPort,
        path: route.path,
        pathProgress: startProgress,
        direction: 1,
        distance: route.distance,
        cargoValue: cargo,
        hp: 100,
        status: "outbound",
        x: pose.x,
        y: pose.y,
        heading: pose.heading,
        speed: 0.8 + Math.random() * 0.22,
        laneOffset: ((i % 5) - 2) * 0.55 + (Math.random() - 0.5) * 0.28,
      });
    }
  }
}

function tickNavalWarfare(game: GameState): void {
  for (const ship of game.tradeShips) {
    if (ship.hp <= 0) continue;
    const destination = game.buildings.get(ship.toPort);
    const origin = game.buildings.get(ship.fromPort);
    if (!destination || !origin) {
      ship.hp = 0;
      continue;
    }

    // Savaş yalnızca karşı limana giden ticareti keser; üçüncü limanlara gidenler sürer.
    if (getRelation(game, ship.owner, destination.owner).status === "war" && ship.status === "outbound") {
      ship.status = "returning";
      ship.direction = -1;
      ship.cargoValue = 0;
    }

    const weather =
      1 + Math.sin(game.tick * 0.017 + ship.id * 2.13) * 0.12 +
      Math.sin(game.tick * 0.006 + ship.id * 0.71) * 0.08;
    ship.pathProgress = Math.max(
      0,
      Math.min(ship.path.length - 1, ship.pathProgress + ship.direction * ship.speed * weather),
    );
    const pose = getShipPose(game, ship.path, ship.pathProgress, ship.direction);
    ship.x = pose.x;
    ship.y = pose.y;
    ship.heading = lerpAngle(
      ship.heading,
      pose.heading + Math.sin(game.tick * 0.018 + ship.id * 1.9) * 0.045,
      0.065,
    );

    if (ship.status === "outbound" && ship.pathProgress >= ship.path.length - 1) {
      if (getRelation(game, ship.owner, destination.owner).status === "war") {
        ship.status = "returning";
        ship.direction = -1;
        ship.cargoValue = 0;
      } else {
        for (const [ownerId, portCell] of [
          [origin.owner, ship.fromPort],
          [destination.owner, ship.toPort],
        ] as Array<[number, number]>) {
          const owner = game.factions[ownerId - 1];
          if (!owner) continue;
          owner.gold += ship.cargoValue;
          owner.tradeLedger.push({ tick: game.tick, amount: ship.cargoValue });
          if (ship.id % 2 === 0 && (ownerId === PLAYER_ID || ship.owner === PLAYER_ID)) {
            pushGoldEffect(game, portCell, ship.cargoValue, ownerId === PLAYER_ID);
          }
        }
        ship.status = "returning";
        ship.direction = -1;
        ship.cargoValue = 0;
      }
    } else if (ship.status === "returning" && ship.pathProgress <= 0) {
      ship.hp = 0;
    }
  }
  game.tradeShips = game.tradeShips.filter((ship) => ship.hp > 0);
}

function caravanTraversable(game: GameState, owner: number, cell: number): boolean {
  if (!game.map.land[cell]) return false;
  const tileOwner = game.owners[cell];
  if (tileOwner === 0 || tileOwner === owner) return true;
  return getRelation(game, owner, tileOwner).status !== "war";
}

function findCaravanRoute(game: GameState, owner: number, from: number, to: number): number[] | null {
  const w = game.map.width;
  const h = game.map.height;
  const fx = from % w;
  const fy = Math.floor(from / w);
  const tx = to % w;
  const ty = Math.floor(to / w);
  const minX = Math.max(0, Math.min(fx, tx) - 8);
  const maxX = Math.min(w - 1, Math.max(fx, tx) + 8);
  const minY = Math.max(0, Math.min(fy, ty) - 8);
  const maxY = Math.min(h - 1, Math.max(fy, ty) + 8);
  const bw = maxX - minX + 1;
  const bh = maxY - minY + 1;
  const prev = new Int32Array(bw * bh);
  prev.fill(-2);
  const queue = new Int32Array(bw * bh);
  const idx = (x: number, y: number) => (y - minY) * bw + (x - minX);
  let head = 0;
  let tail = 0;
  prev[idx(fx, fy)] = -1;
  queue[tail++] = from;
  let found = false;
  while (head < tail && tail < prev.length) {
    const cur = queue[head++];
    if (cur === to) { found = true; break; }
    const cx = cur % w;
    const cy = Math.floor(cur / w);
    for (const next of cellNeighbors8(cur, w, h)) {
      if (next % w < minX || next % w > maxX) continue;
      const ny = Math.floor(next / w);
      if (ny < minY || ny > maxY) continue;
      const bi = idx(next % w, ny);
      if (prev[bi] !== -2 || !caravanTraversable(game, owner, next)) continue;
      prev[bi] = cur;
      queue[tail++] = next;
    }
    void cx; void cy;
  }
  if (!found) return null;
  const path: number[] = [];
  let cursor = to;
  while (cursor >= 0 && cursor !== from) {
    path.push(cursor);
    const px = cursor % w;
    const py = Math.floor(cursor / w);
    cursor = prev[idx(px, py)];
  }
  path.reverse();
  return path;
}

function getLandPose(game: GameState, path: number[], progress: number, direction: 1 | -1) {
  const W = game.map.width;
  const H = game.map.height;
  if (!path.length) return { x: 0, y: 0, heading: 0 };
  const clamped = Math.max(0, Math.min(path.length - 1, progress));
  const i = Math.floor(clamped);
  const t = clamped - i;
  const pt = (k: number): [number, number] => {
    const cell = path[Math.max(0, Math.min(path.length - 1, k))];
    return [cell % W, Math.floor(cell / W)];
  };
  const [x0, y0] = pt(i - 1);
  const [x1, y1] = pt(i);
  const [x2, y2] = pt(i + 1);
  const [x3, y3] = pt(i + 2);
  const sx = 0.5 * (2 * x1 + (-x0 + x2) * t + (2 * x0 - 5 * x1 + 4 * x2 - x3) * t * t + (-x0 + 3 * x1 - 3 * x2 + x3) * t * t * t);
  const sy = 0.5 * (2 * y1 + (-y0 + y2) * t + (2 * y0 - 5 * y1 + 4 * y2 - y3) * t * t + (-y0 + 3 * y1 - 3 * y2 + y3) * t * t * t);
  const heading = Math.atan2((y2 - y0) * direction, (x2 - x0) * direction || 0.0001);
  return { x: Math.max(0, Math.min(W - 1, sx)), y: Math.max(0, Math.min(H - 1, sy)), heading };
}

const CARAVAN_TARGET_TYPES: BuildingType[] = ["town", "castle", "barracks", "port", "market"];

function spawnCaravans(game: GameState): void {
  if (game.tick % 16 !== 0 || game.caravans.length >= 110) return;
  const W = game.map.width;
  for (const [marketCell, market] of game.buildings) {
    if (market.type !== "market" || market.owner <= 0) continue;
    const owner = market.owner;
    const faction = game.factions[owner - 1];
    if (!faction) continue;
    const active = game.caravans.filter((c) => c.owner === owner && c.fromMarket === marketCell && !c.done).length;
    if (active >= 1 + Math.ceil(market.level / 2)) continue;
    if (Math.random() > 0.62) continue;

    const range = 23 + market.level * 7;
    const candidates: Array<{ cell: number; distance: number; foreign: boolean }> = [];
    for (const [cell, destination] of game.buildings) {
      if (cell === marketCell || !CARAVAN_TARGET_TYPES.includes(destination.type) || destination.owner <= 0) continue;
      const distance = Math.hypot((cell % W) - (marketCell % W), Math.floor(cell / W) - Math.floor(marketCell / W));
      if (distance < 3 || distance > range) continue;
      const foreign = destination.owner !== owner;
      if (foreign) {
        const rel = getRelation(game, owner, destination.owner).status;
        if (rel === "war" || isTradeBlocked(game, owner, destination.owner)) continue;
      }
      candidates.push({ cell, distance, foreign });
    }
    if (!candidates.length) continue;
    // Yakın ve uzak duraklar arasında çeşitlilik; sınır komşusu duraklar teşvik edilir.
    candidates.sort(
      (a, b) => b.distance + (b.foreign ? 22 : 0) - (a.distance + (a.foreign ? 22 : 0)),
    );
    // Her turda komşu ülkeye giden bir kervanı öne al; kendi duraklar da seçilebilir.
    if (candidates.some((c) => c.foreign) && Math.random() < 0.55) {
      candidates.sort((a, b) => Number(b.foreign) - Number(a.foreign) || b.distance - a.distance);
    }
    const picks = candidates.slice(0, 6);
    for (const pick of picks) {
      const roadKey = `${marketCell}:${pick.cell}`;
      let path = game.roads.get(roadKey) ?? null;
      if (!path) {
        path = findCaravanRoute(game, owner, marketCell, pick.cell);
        if (path && path.length >= 2 && game.roads.size < 900) game.roads.set(roadKey, path);
      }
      if (!path || path.length < 2) continue;
      const cargo = Math.round(4 + pick.distance * 0.3 + market.level * 2.2);
      const pose = getLandPose(game, path, 0, 1);
      game.caravans.push({
        id: game.nextShipId++,
        owner,
        fromMarket: marketCell,
        toCell: pick.cell,
        path,
        pathProgress: 0,
        direction: 1,
        x: pose.x,
        y: pose.y,
        heading: pose.heading,
        cargoValue: cargo,
        speed: 0.36 + market.level * 0.02,
        status: "outbound",
        done: false,
      });
      break;
    }
  }
}

function tickCaravans(game: GameState): void {
  for (const caravan of game.caravans) {
    if (caravan.done) continue;
    const destinationOwner = game.owners[caravan.toCell];
    if (
      caravan.status === "outbound" &&
      destinationOwner > 0 &&
      destinationOwner !== caravan.owner &&
      getRelation(game, caravan.owner, destinationOwner).status === "war"
    ) {
      caravan.status = "returning";
      caravan.direction = -1;
      caravan.cargoValue = 0;
    }

    caravan.pathProgress = Math.max(
      0,
      Math.min(caravan.path.length - 1, caravan.pathProgress + caravan.direction * caravan.speed),
    );
    const pose = getLandPose(game, caravan.path, caravan.pathProgress, caravan.direction);
    caravan.x = pose.x;
    caravan.y = pose.y;
    caravan.heading = pose.heading;

    if (caravan.status === "outbound" && caravan.pathProgress >= caravan.path.length - 1) {
      const source = game.buildings.get(caravan.fromMarket);
      const destination = game.buildings.get(caravan.toCell);
      if (source && destination && caravan.cargoValue > 0) {
        for (const [beneficiary, cell] of [
          [source.owner, caravan.fromMarket],
          [destination.owner, caravan.toCell],
        ] as Array<[number, number]>) {
          const owner = game.factions[beneficiary - 1];
          if (!owner) continue;
          owner.gold += caravan.cargoValue;
          owner.tradeLedger.push({ tick: game.tick, amount: caravan.cargoValue });
          if (beneficiary === PLAYER_ID || caravan.owner === PLAYER_ID) {
            pushGoldEffect(game, cell, caravan.cargoValue, beneficiary === PLAYER_ID);
          }
        }
        if (caravan.owner === PLAYER_ID) {
          game.lastEvent = `Kervan ${formatNumber(caravan.cargoValue)} altınla pazara ulaştı.`;
        }
      }
      caravan.status = "returning";
      caravan.direction = -1;
      caravan.cargoValue = 0;
    } else if (caravan.status === "returning" && caravan.pathProgress <= 0) {
      caravan.done = true;
    }
  }
  game.caravans = game.caravans.filter((caravan) => !caravan.done);
}

export function tickGame(game: GameState): void {
  if (game.phase !== "playing") return;
  game.tick++;

  // Expire finished truces back to peace and expired offers
  for (const rel of game.relations.values()) {
    if (rel.status === "truce" && game.tick >= rel.truceUntil) {
      rel.status = "peace";
      rel.truceUntil = 0;
    }
  }
  game.offers = game.offers.filter((offer) => offer.expiresAtTick > game.tick);
  game.notifications = game.notifications.filter(
    (notification) =>
      notification.expiresAtTick > game.tick &&
      (!notification.offerId || game.offers.some((offer) => offer.id === notification.offerId)),
  );

  // Vergi, pazar geliri, ordu bakımı ve yerel kışla eğitimi
  for (const faction of game.factions) {
    faction.tradeLedger = faction.tradeLedger.filter((entry) => game.tick - entry.tick <= 120);
    if (!faction.land) continue;
    const aiStipend =
      faction.id !== PLAYER_ID ? 0.75 + Math.min(0.55, faction.land * 0.0004) : 0;
    faction.gold = Math.max(0, faction.gold + getGoldRatePerTick(faction) + aiStipend);
    if ((faction.commander.beachheadTicks || 0) > 0) faction.commander.beachheadTicks--;
    syncCommanderArmy(game, faction);
  }
  processTrainingOrders(game);

  for (const [bIndex, building] of game.buildings) {
    if (building.type === "castle" && building.wallHp < building.maxWallHp) {
      const underSiege = game.factions.some((f) => f.commander.siegingCastle === bIndex);
      if (!underSiege) {
        building.wallHp = Math.min(building.maxWallHp, building.wallHp + 1);
      }
    }
  }

  applyCastleAttrition(game);

  // Commander movement & conquest
  for (const faction of game.factions) {
    if (!faction.land) continue;
    stepCommanderMovement(game, faction);
    captureAroundCommander(game, faction);
  }

  // Two-stage combat: Field Battles first, then Castle Sieges (or Flanking!)
  evaluateEngagementsAndSieges(game);
  resolveFieldBattles(game);
  resolveCastleSieges(game);

  annexCollapsedRealms(game);
  fillEnclosedPockets(game);
  autoColonise(game);

  // AI decisions and naval economy
  tickAI(game);
  spawnTradeShips(game);
  tickNavalWarfare(game);
  spawnCaravans(game);
  tickCaravans(game);

  // Tek tıkla kurulan çıkarma: komutan zamanla limana intikal eder, filo otomatik kalkar.
  game.pendingLandings = game.pendingLandings.filter((pending) => {
    const faction = game.factions[pending.owner - 1];
    if (!faction || faction.land <= 0) return false;
    const port = game.buildings.get(pending.from);
    const targetOwner = game.owners[pending.target];
    if (!port || port.owner !== pending.owner || port.type !== "port") {
      faction.gold += 350;
      return false;
    }
    if (targetOwner > 0 && getRelation(game, pending.owner, targetOwner).status !== "war") {
      faction.gold += 350;
      pushNotification(game, {
        kind: "info",
        title: "Çıkarma iptal edildi",
        message: "Hedef krallıkla barış sağlandı; filo limanda kaldı.",
        actionable: false,
      }, 180);
      return false;
    }

    const cmd = faction.commander;
    const px = pending.from % game.map.width;
    const py = Math.floor(pending.from / game.map.width);
    if (pending.rallyTicks > 0) {
      pending.rallyTicks--;
      const ratio = 1 - pending.rallyTicks / Math.max(1, pending.totalRallyTicks);
      cmd.x = pending.startX + (px - pending.startX) * ratio;
      cmd.y = pending.startY + (py - pending.startY) * ratio;
      cmd.stance = "embarked";
      cmd.targetX = px;
      cmd.targetY = py;
      cmd.engagedWith = null;
      cmd.siegingCastle = null;
      return true;
    }

    cmd.x = px;
    cmd.y = py;
    if (cmd.army < 900) {
      faction.gold += 350;
      pushNotification(game, {
        kind: "info",
        title: "Çıkarma iptal edildi",
        message: "Komutanın ordusu limana varana kadar çok zayıfladı.",
        actionable: false,
      }, 180);
      return false;
    }
    if (!startLandingFromPending(game, pending)) faction.gold += 350;
    return false;
  });

  // Yumuşak deniz rotasını izleyen amfibik seferler.
  game.landings = game.landings.filter((landing) => {
    const faction = game.factions[landing.owner - 1];
    if (!faction || faction.land <= 0 || !landing.path.length) return false;
    const cmd = faction.commander;
    landing.pathProgress = Math.min(landing.path.length - 1, landing.pathProgress + 1.75);
    const pose = getShipPose(game, landing.path, landing.pathProgress, 1);
    landing.x = pose.x;
    landing.y = pose.y;
    landing.heading = lerpAngle(landing.heading, pose.heading, 0.2);
    cmd.x = landing.x;
    cmd.y = landing.y;
    cmd.stance = "embarked";
    if (landing.pathProgress < landing.path.length - 1) return true;

    const targetOwner = game.owners[landing.target];
    const relation = targetOwner > 0 ? getRelation(game, faction.id, targetOwner).status : "peace";
    const canLand = targetOwner === 0 || targetOwner === faction.id || relation === "war";
    if (!canLand) {
      cmd.x = landing.from % game.map.width;
      cmd.y = Math.floor(landing.from / game.map.width);
      cmd.army = landing.army;
      cmd.stance = "idle";
      pushNotification(game, {
        kind: "info",
        title: "Çıkarma geri döndü",
        message: "Barış sağlandığı için ordu limana indi.",
        actionable: false,
      }, 180);
      return false;
    }

    const cx = landing.target % game.map.width;
    const cy = Math.floor(landing.target / game.map.width);
    cmd.x = cx;
    cmd.y = cy;
    cmd.army = landing.army;
    cmd.stance = "idle";
    cmd.targetX = null;
    cmd.targetY = null;
    cmd.engagedWith = null;
    cmd.siegingCastle = null;
    cmd.beachheadTicks = 70;

    if (landing.finalTarget !== landing.target && game.owners[landing.finalTarget] !== faction.id) {
      commandMove(game, faction.id, landing.finalTarget);
    }

    const protectedTile = targetOwner > 0 ? isProtectedByEnemyCastle(game, landing.target, targetOwner) : null;
    if (!protectedTile && targetOwner !== faction.id) {
      if (targetOwner > 0) cmd.army = Math.max(100, cmd.army - 140);
      claimCell(game, landing.target, faction.id);
    }
    game.effects.push({ index: landing.target, x: cx, y: cy, started: game.tick, type: "landing" });
    if (faction.id === PLAYER_ID) {
      game.lastEvent = "Çıkarma tamamlandı. Köprübaşını korumak için hızla bir kale kur!";
    }
    return false;
  });

  game.effects = game.effects.filter((effect) => game.tick - effect.started < (effect.type === "gold" ? 44 : 22));

  // Victory / Defeat checks
  const player = game.factions[0];
  if (player.land === 0) {
    game.phase = "lost";
    game.lastEvent = "Krallığın düştü.";
  } else if (
    player.land / game.map.landCount >= 0.68 ||
    game.factions.slice(1).every((faction) => faction.land === 0)
  ) {
    game.phase = "won";
    game.lastEvent = "Kıtaya hükmettin! Mutlak zafer!";
  }
}

export function canBuildPort(game: GameState, index: number): boolean {
  return cellNeighbors8(index, game.map.width, game.map.height).some(
    (cell) => !game.map.land[cell] && game.map.tradeableWater[cell] === 1,
  );
}

export function buildingSpacing(type: BuildingType, forwardFort = false): number {
  if (type === "castle") return forwardFort ? FORWARD_FORT_SPACING : CASTLE_BUILD_SPACING;
  if (type === "barracks") return 5;
  if (type === "port") return 5;
  return 5;
}

function pushGoldEffect(game: GameState, portIndex: number, amount: number, mine: boolean): void {
  game.effects.push({
    index: portIndex,
    x: portIndex % game.map.width,
    y: Math.floor(portIndex / game.map.width),
    started: game.tick,
    type: "gold",
    amount,
    mine,
  });
}

export function getBuildingPlacementError(
  game: GameState,
  index: number,
  type: BuildingType,
  factionId = PLAYER_ID,
): string {
  if (!game.map.land[index]) return "Yapılar yalnızca karaya kurulur.";
  const ownsTile = game.owners[index] === factionId;
  const existing = game.buildings.get(index);
  if (existing) {
    if (existing.owner !== factionId) return "Bu yapı başka bir krallığın kontrolünde.";
    if (existing.type !== type) return `Burada ${BUILDINGS[existing.type].name} var; yükseltmek için aynı türü seç.`;
    if (existing.level >= MAX_STRUCTURE_LEVEL) return "Bu yapı en yüksek seviyede.";
    return "";
  }
  const forwardFort =
    type === "castle" && !ownsTile && game.owners[index] === 0 && hasFriendlyNear(game, index, factionId, 6);
  if (!ownsTile && !forwardFort) {
    return type === "castle"
      ? "Kale; kendi toprağına ya da sınırına 6 birim yakındaki ileri noktaya kurulabilir."
      : "Yalnızca kendi topraklarına kurabilirsin.";
  }
  if (type === "castle" && activeWarEnemies(game, factionId).length > 0) {
    return "Savaş sırasında yeni kale kurulamaz. Mevcut kaleleri koru veya barış yap.";
  }
  if (game.buildings.has(index)) return "Burada zaten bir yapı var.";
  if (type === "port" && !canBuildPort(game, index)) return "Liman için kıyıya bitişik bir bölge seç.";
  if (type !== "castle" && !isInSupplyRange(game, index, factionId)) {
    return "Kale ikmal menzilinin dışı. Önce sınıra yeni bir kale kur.";
  }

  const spacing = buildingSpacing(type, forwardFort);
  let nearest = Infinity;
  for (const [otherIndex, building] of game.buildings) {
    if (building.owner !== factionId || building.type !== type) continue;
    nearest = Math.min(nearest, Math.sqrt(distanceSquared(otherIndex, index, game.map.width)));
  }
  // Bölge başına yapı sayısı sınırsız; yalnızca yapıların üst üste binmemesi için
  // küçük bir minimum aralık korunur.
  if (nearest < spacing) {
    return type === "castle"
      ? `En yakın kaleye ${Math.round(nearest)}/${spacing} birim: daha uzağa kur.`
      : `Aynı yapıya ${Math.round(nearest)}/${spacing} birim: biraz uzaklaş.`;
  }

  if (type === "barracks") {
    const townNearby = [...game.buildings.entries()].some(
      ([otherIndex, building]) =>
        building.owner === factionId &&
        building.type === "town" &&
        distanceSquared(otherIndex, index, game.map.width) <= 24 * 24,
    );
    if (!townNearby) return "Kışla için 24 birim içinde bir kasaba gerekli.";
  }
  return "";
}

function placeBuildingForFaction(
  game: GameState,
  faction: Faction,
  index: number,
  type: BuildingType,
): boolean {
  if (game.buildings.has(index)) return false;
  if (getBuildingPlacementError(game, index, type, faction.id)) return false;
  const price = getBuildingCost(type, faction.buildings[type]);
  if (faction.gold < price) return false;
  faction.gold -= price;
  faction.buildings[type]++;
  faction.buildingLevels[type]++;
  if (type === "castle" && game.owners[index] === 0) {
    // İleri kale, kendi toprağındaki bir kale gibi görünür bir hâkimiyet alanı kurar.
    claimCell(game, index, faction.id);
    claimCircle(game, index, 2, faction.id);
  }
  const maxWall = type === "castle" ? castleMaxWall(1) : 0;
  game.buildings.set(index, {
    type,
    owner: faction.id,
    level: 1,
    wallHp: maxWall,
    maxWallHp: maxWall,
    garrison: 0,
  });
  game.revision++;
  return true;
}

export function upgradeStructureForFaction(
  game: GameState,
  index: number,
  factionId: number,
): string {
  const building = game.buildings.get(index);
  const faction = game.factions[factionId - 1];
  if (!building || !faction || building.owner !== factionId) return "Yalnızca kendi yapını yükseltebilirsin.";
  const cost = upgradeCost(building);
  if (cost === null) return "Bu yapı en yüksek seviyede.";
  if (faction.gold < cost) return `Yükseltme için ${formatNumber(cost)} altın gerekiyor.`;

  faction.gold -= cost;
  building.level++;
  faction.buildingLevels[building.type]++;
  if (building.type === "castle") {
    const oldMax = building.maxWallHp;
    building.maxWallHp = castleMaxWall(building.level);
    building.wallHp += building.maxWallHp - oldMax;
  }
  if (building.type === "barracks") {
    building.garrison = Math.min(building.garrison || 0, building.level * 4800);
  }
  game.revision++;
  if (factionId === PLAYER_ID) {
    game.lastEvent = `${BUILDINGS[building.type].name} Sv.${building.level} oldu! Aynı yere tekrar basarak yükseltebilirsin.`;
  }
  return "";
}

export function buildStructure(game: GameState, index: number, type: BuildingType): string {
  const existing = game.buildings.get(index);
  if (existing) {
    if (existing.owner !== PLAYER_ID) return "Yalnızca kendi yapını yükseltebilirsin.";
    if (existing.type !== type) return `Burada ${BUILDINGS[existing.type].name} var; ${BUILDINGS[type].name} kurulamaz.`;
    const upgradeError = upgradeStructureForFaction(game, index, PLAYER_ID);
    return upgradeError;
  }
  const placementError = getBuildingPlacementError(game, index, type, PLAYER_ID);
  if (placementError) return placementError;
  const faction = game.factions[0];
  const price = getBuildingCost(type, faction.buildings[type]);
  if (faction.gold < price) return `Bu yapı için ${formatNumber(price)} altın gerekiyor.`;
  if (!placeBuildingForFaction(game, faction, index, type)) return "Bu yapı için yeterli altının yok.";
  game.lastEvent = `${BUILDINGS[type].name} inşa edildi.`;
  return "";
}

export function upgradeBuilding(game: GameState, index: number): string {
  return upgradeStructureForFaction(game, index, PLAYER_ID);
}

export function repairCastle(game: GameState, index: number): string {
  const building = game.buildings.get(index);
  if (!building || building.owner !== PLAYER_ID || building.type !== "castle") return "Geçerli bir kale seç.";
  if (building.wallHp >= building.maxWallHp) return "Kale surları zaten sağlam.";
  const cost = repairCastleCost(building);
  if (game.factions[0].gold < cost) return `Onarım için ${formatNumber(cost)} altın gerekiyor.`;
  game.factions[0].gold -= cost;
  building.wallHp = building.maxWallHp;
  game.lastEvent = "Kale surları tamamen onarıldı!";
  return "";
}

export function buySiegeWeapon(game: GameState, factionId = PLAYER_ID): string {
  const faction = game.factions[factionId - 1];
  if (!faction || !faction.land) return "Geçersiz krallık.";
  const cmd = faction.commander;
  const cost = 850 + cmd.siegeWeapons * 150;
  if (cmd.siegeWeapons >= 6) return "Ordun en fazla 6 kuşatma silahı taşıyabilir.";
  if (faction.gold < cost) return `Mancınık için ${formatNumber(cost)} altın gerekiyor.`;
  faction.gold -= cost;
  cmd.siegeWeapons++;
  if (factionId === PLAYER_ID) {
    game.lastEvent = `Orduya bir mancınık eklendi (${cmd.siegeWeapons}/6). Komutanla birlikte taşınır.`;
  }
  return "";
}

export function bombardTarget(game: GameState, target: number): string {
  const faction = game.factions[0];
  if (!game.map.land[target]) return "Bombardıman için bir kara hedefi seç.";
  const targetOwner = game.owners[target];
  if (targetOwner === PLAYER_ID) return "Kendi toprağını bombalayamazsın.";
  if (targetOwner > 0 && getRelation(game, PLAYER_ID, targetOwner).status !== "war") {
    return "Bombardıman için önce savaş ilan etmelisin.";
  }
  if (faction.commander.siegeWeapons < 1) {
    return "Kuşatma silahın yok. Orduya mancınık ekle ve komutanı hedefe yaklaştır.";
  }
  if (faction.gold < 500) return "Bombardıman için 500 altın gerekiyor.";
  const cmd = faction.commander;
  if (distanceSquaredXY(cmd.x, cmd.y, target % game.map.width, Math.floor(target / game.map.width)) > 20 * 20) {
    return "Kuşatma silahı orduda taşınır; komutanı hedefe 20 birim yaklaştır.";
  }

  faction.gold -= 500;
  cmd.siegeWeapons--;
  const cx = target % game.map.width;
  const cy = Math.floor(target / game.map.width);

  let hitCastle = false;
  for (const [bIndex, building] of game.buildings) {
    if (building.type === "castle" && building.owner !== PLAYER_ID) {
      if (distanceSquared(bIndex, target, game.map.width) <= 16) {
        const dmg = 260 + faction.commander.siegeWeapons * 45;
        building.wallHp = Math.max(60, building.wallHp - dmg);
        hitCastle = true;
      }
    }
  }

  // Also disrupt nearby enemy commander army
  if (targetOwner > 0) {
    const enemy = game.factions[targetOwner - 1];
    if (distanceSquaredXY(enemy.commander.x, enemy.commander.y, cx, cy) <= 64) {
      enemy.commander.army = Math.max(200, enemy.commander.army * 0.9);
    }
  }

  game.effects.push({ index: target, x: cx, y: cy, started: game.tick, type: "bombard" });
  game.lastEvent = hitCastle
    ? "Mancınık ve toplar kale surlarında gedikler açtı!"
    : "Kuşatma ateşi hedef bölgeyi sarstı.";
  return "";
}

function startLandingFromPending(game: GameState, pending: PendingLanding): boolean {
  const faction = game.factions[pending.owner - 1];
  if (!faction || faction.land <= 0) return false;
  const port = game.buildings.get(pending.from);
  if (!port || port.owner !== pending.owner || port.type !== "port") return false;
  const targetOwner = game.owners[pending.target];
  if (targetOwner > 0 && getRelation(game, pending.owner, targetOwner).status !== "war") return false;
  const cmd = faction.commander;
  if (cmd.army < 900) return false;

  const army = Math.floor(cmd.army);
  const pose = getShipPose(game, pending.path, 0, 1);
  pending.army = army;
  cmd.army = army;
  cmd.x = pose.x;
  cmd.y = pose.y;
  cmd.stance = "embarked";
  cmd.targetX = null;
  cmd.targetY = null;
  cmd.engagedWith = null;
  cmd.siegingCastle = null;
  cmd.beachheadTicks = 0;
  game.landings.push({
    from: pending.from,
    target: pending.target,
    owner: pending.owner,
    army,
    finalTarget: pending.finalTarget,
    path: pending.path,
    pathProgress: 0,
    x: pose.x,
    y: pose.y,
    heading: pose.heading,
  });
  game.lastEvent = `Komutan ve ${formatNumber(army)} asker deniz rotasına çıktı.`;
  return true;
}

export function sendBoat(game: GameState, target: number): string {
  const faction = game.factions[0];
  const cmd = faction.commander;
  if (!game.map.land[target] || game.owners[target] === PLAYER_ID) {
    return "Çıkarma için başka bir kara bölgesi seç.";
  }

  const owner = game.owners[target];
  if (owner > 0 && getRelation(game, PLAYER_ID, owner).status !== "war") {
    return "Savaşta olmadığın krallığın kıyısına çıkarma yapamazsın.";
  }

  // İstenen bölge denize bitişik değilse en yakın sahile iniş yapılır,
  // ordu karaya çıktıktan sonra seçilen hedefe yürür.
  let shore = target;
  if (!canBuildPort(game, target)) {
    let bestShore = -1;
    let bestDistance = Infinity;
    const tx = target % game.map.width;
    const ty = Math.floor(target / game.map.width);
    for (let radius = 1; radius <= 14 && bestShore < 0; radius++) {
      for (let dy = -radius; dy <= radius; dy++) {
        for (let dx = -radius; dx <= radius; dx++) {
          if (Math.abs(dx) !== radius && Math.abs(dy) !== radius) continue;
          const x = tx + dx;
          const y = ty + dy;
          if (x < 0 || x >= game.map.width || y < 0 || y >= game.map.height) continue;
          const cell = y * game.map.width + x;
          if (!game.map.land[cell] || !canBuildPort(game, cell)) continue;
          const distance = dx * dx + dy * dy;
          if (distance < bestDistance) {
            bestDistance = distance;
            bestShore = cell;
          }
        }
      }
    }
    if (bestShore < 0) return "Bu bölgeye ulaşan bir sahil bulunamadı.";
    shore = bestShore;
  }
  if (["battle", "siege", "retreat", "embarked"].includes(cmd.stance)) {
    return "Komutan şu anda donanmaya binemez.";
  }
  if (
    game.landings.some((landing) => landing.owner === PLAYER_ID) ||
    game.pendingLandings.some((landing) => landing.owner === PLAYER_ID)
  ) {
    return "Zaten hazırlanan veya devam eden bir çıkarma seferin var.";
  }
  if (cmd.army < 1000) return "Çıkarma için komutanın yanında en az 1.000 asker olmalı.";
  if (faction.gold < 700) return "Donanma taşımacılığı için 700 altın gerekiyor.";

  const commanderCell = Math.round(cmd.y) * game.map.width + Math.round(cmd.x);
  const ports = [...game.buildings.entries()]
    .filter(([, building]) => building.owner === PLAYER_ID && building.type === "port")
    .sort(
      ([a], [b]) =>
        distanceSquared(a, commanderCell, game.map.width) - distanceSquared(b, commanderCell, game.map.width),
    );
  if (!ports.length) return "Önce kıyıya bir liman kurmalısın.";
  const [portIndex] = ports[0];
  const path = getSeaRoute(game, portIndex, shore);
  if (!path || path.length < 3) return "Bu iki kıyı arasında açık deniz rotası yok.";

  faction.gold -= 700;
  const rallyTicks = Math.max(
    24,
    Math.min(
      90,
      Math.ceil(
        Math.sqrt(
          distanceSquaredXY(
            cmd.x,
            cmd.y,
            portIndex % game.map.width,
            Math.floor(portIndex / game.map.width),
          ),
        ) * 1.2,
      ),
    ),
  );
  const pending: PendingLanding = {
    id: game.nextShipId++,
    from: portIndex,
    target: shore,
    finalTarget: target,
    owner: PLAYER_ID,
    army: Math.floor(cmd.army),
    path,
    rallyTicks,
    totalRallyTicks: rallyTicks,
    startX: cmd.x,
    startY: cmd.y,
  };
  const portDistance = Math.sqrt(
    distanceSquaredXY(cmd.x, cmd.y, portIndex % game.map.width, Math.floor(portIndex / game.map.width)),
  );
  if (portDistance > 6) {
    const moveError = commandMove(game, PLAYER_ID, portIndex);
    if (moveError) {
      faction.gold += 700;
      return moveError;
    }
    // Yumuşak intikal: komutan birkaç saniye limana yaklaşır, sonra filo otomatik kalkar.
    cmd.stance = "embarked";
    cmd.targetX = portIndex % game.map.width;
    cmd.targetY = Math.floor(portIndex / game.map.width);
    game.pendingLandings.push(pending);
    game.lastEvent = "Komutan limana yürüyor. Varınca filo otomatik yola çıkacak.";
    pushNotification(game, {
      kind: "info",
      title: "Çıkarma hazırlanıyor",
      message: "Komutan limana varınca ordu tek tıkla denize açılacak.",
      actionable: false,
    }, 220);
    return "";
  }
  if (!startLandingFromPending(game, pending)) faction.gold += 700;
  return "";
}

export function getActiveBattles(game: GameState): ActiveBattleView[] {
  const seen = new Set<string>();
  const battles: ActiveBattleView[] = [];
  for (const a of game.factions) {
    if (!a.land || a.commander.stance !== "battle" || a.commander.engagedWith === null) continue;
    const b = game.factions[a.commander.engagedWith - 1];
    if (!b || !b.land) continue;
    const key = relationKey(a.id, b.id);
    if (seen.has(key)) continue;
    seen.add(key);
    battles.push({
      attackerId: a.id,
      defenderId: b.id,
      attackerName: a.name,
      defenderName: b.name,
      attackerArmy: Math.floor(a.commander.army),
      defenderArmy: Math.floor(b.commander.army),
      x: (a.commander.x + b.commander.x) / 2,
      y: (a.commander.y + b.commander.y) / 2,
    });
  }
  return battles;
}

export function getActiveSieges(game: GameState): ActiveSiegeView[] {
  const sieges: ActiveSiegeView[] = [];
  for (const attacker of game.factions) {
    if (!attacker.land || attacker.commander.stance !== "siege" || attacker.commander.siegingCastle === null) continue;
    const castle = game.buildings.get(attacker.commander.siegingCastle);
    if (!castle || castle.type !== "castle") continue;
    const defender = game.factions[castle.owner - 1];
    sieges.push({
      castleIndex: attacker.commander.siegingCastle,
      attackerId: attacker.id,
      defenderId: defender.id,
      attackerName: attacker.name,
      defenderName: defender.name,
      level: castle.level,
      wallHp: Math.floor(castle.wallHp),
      maxWallHp: castle.maxWallHp,
      attackerArmy: Math.floor(attacker.commander.army),
    });
  }
  return sieges;
}

export function getSnapshot(game: GameState): GameSnapshot {
  const player = game.factions[0];
  const { cost: recruitCost, amount: recruitAmount, ticks: recruitTicks } = getRecruitValues(player);
  const troopPerSec = getTroopRatePerTick(player) / STEP_SECONDS;
  const goldPerSec = getGoldRatePerTick(player) / STEP_SECONDS;
  const playerTraining = game.trainingOrders.filter((order) => order.owner === PLAYER_ID);
  const tradeIncomePerMin = Math.round(
    player.tradeLedger.reduce((sum, entry) => sum + entry.amount, 0) * (60 / (120 * STEP_SECONDS)),
  );
  const tradeRoutes = new Set(
    game.tradeShips.filter((ship) => ship.owner === PLAYER_ID).map((ship) => `${ship.fromPort}:${ship.toPort}`),
  ).size;
  const engagedEnemy =
    player.commander.engagedWith !== null ? game.factions[player.commander.engagedWith - 1]?.name || null : null;

  let siegingInfo: GameSnapshot["siegingInfo"] = null;
  if (player.commander.siegingCastle !== null) {
    const castle = game.buildings.get(player.commander.siegingCastle);
    if (castle && castle.type === "castle") {
      const defender = game.factions[castle.owner - 1];
      siegingInfo = {
        wallHp: Math.floor(castle.wallHp),
        maxWallHp: castle.maxWallHp,
        level: castle.level,
        ownerName: defender?.name || "",
        ownerColor: defender?.color || "#e27a62",
        attackerArmy: Math.floor(player.commander.army),
        defenderArmy: Math.floor(defender ? getTotalTroops(defender) : 0),
      };
    }
  }

  return {
    phase: game.phase,
    tick: game.tick,
    totalTroops: Math.floor(getTotalTroops(player)),
    reserveTroops: Math.floor(player.reserveTroops),
    fieldArmy: Math.floor(player.commander.army),
    capacity: getCapacity(player),
    troopRatePerSec: Math.round(troopPerSec),
    gold: Math.floor(player.gold),
    goldRatePerSec: Math.round(goldPerSec * 10) / 10,
    land: player.land,
    percent: (player.land / game.map.landCount) * 100,
    attackRatio: game.attackRatio,
    commanderStance: player.commander.stance,
    engagedEnemyName: engagedEnemy,
    siegingInfo,
    lastEvent: game.lastEvent,
    recruitCost,
    recruitAmount,
    recruitTicks,
    trainingOrders: playerTraining.map((order) => ({
      buildingIndex: order.buildingIndex,
      amount: order.amount,
      remainingTicks: order.remainingTicks,
      totalTicks: order.totalTicks,
    })),
    queuedTroops: playerTraining.reduce((sum, order) => sum + order.amount, 0),
    tradeShips: game.tradeShips.filter((ship) => ship.owner === PLAYER_ID).length,
    caravans: game.caravans.filter((caravan) => caravan.owner === PLAYER_ID).length,
    tradeRoutes,
    tradeIncomePerMin,
    autoExpand: game.autoExpand,
    notifications: [...game.notifications].slice(0, 6),
    exhaustionRemaining: Math.max(0, Math.ceil((player.exhaustionUntil - game.tick) * STEP_SECONDS)),
    siegeWeapons: player.commander.siegeWeapons,
    regroupRemaining: Math.max(0, Math.ceil(player.commander.regroupTicks * STEP_SECONDS)),
    buildingLevels: { ...player.buildingLevels },
    battleDice: game.lastBattleDice,
    economy: getEconomyBreakdown(player),
    capacityBreakdown: getCapacityBreakdown(player),
    factions: game.factions
      .filter((faction) => faction.land > 0)
      .sort((a, b) => b.land - a.land)
      .map((faction) => {
        const rel = getRelation(game, PLAYER_ID, faction.id);
        return {
          id: faction.id,
          name: faction.name,
          color: faction.color,
          botKind: faction.botKind,
          land: faction.land,
          percent: (faction.land / game.map.landCount) * 100,
          totalTroops: Math.floor(getTotalTroops(faction)),
          fieldArmy: Math.floor(faction.commander.army),
          castles: faction.buildings.castle,
          relation: rel.status,
          truceRemaining: rel.status === "truce" ? Math.max(0, Math.ceil((rel.truceUntil - game.tick) * STEP_SECONDS)) : 0,
        };
      }),
    buildings: { ...player.buildings },
    offers: [...game.offers],
    activeWarsCount: activeWarEnemies(game, PLAYER_ID).length,
  };
}

export function formatNumber(value: number): string {
  if (value >= 1_000_000) return `${(value / 1_000_000).toFixed(1)}M`;
  if (value >= 10_000) return `${(value / 1000).toFixed(1)}K`;
  return Math.floor(value).toLocaleString("tr-TR");
}

export function createPreviewGame(map: TerrainMap): GameState {
  const game = createGame(map, "Sen", "#25a9d3", "normal");
  game.preview = true;
  game.phase = "playing";
  for (let i = 0; i < 16; i++) {
    game.factions.push(makeFaction(i + 2, MEDIEVAL_NAMES[i], FACTION_COLORS[i]));
  }

  const seeds: Array<{ x: number; y: number; radius: number; id: number }> = [];
  let attempts = 0;
  while (seeds.length < 17 && attempts++ < 5000) {
    const index = Math.floor(Math.random() * map.land.length);
    if (!map.land[index]) continue;
    const x = index % map.width;
    const y = Math.floor(index / map.width);
    if (seeds.some((seed) => (seed.x - x) ** 2 + (seed.y - y) ** 2 < 450)) continue;
    seeds.push({ x, y, radius: 18 + Math.random() * 18, id: seeds.length + 1 });
  }

  for (let index = 0; index < map.land.length; index++) {
    if (!map.land[index]) continue;
    const x = index % map.width;
    const y = Math.floor(index / map.width);
    let nearest = 0;
    let score = Infinity;
    for (const seed of seeds) {
      const distance = Math.sqrt((x - seed.x) ** 2 + (y - seed.y) ** 2);
      const edge = distance + Math.sin(x * 0.25 + y * 0.14 + seed.id) * 2.1;
      if (edge < seed.radius && edge < score) {
        score = edge;
        nearest = seed.id;
      }
    }
    if (nearest) claimCell(game, index, nearest);
  }
  return game;
}
