import { useEffect, useRef } from "react";
import {
  castleGuardRadius,
  castleSupplyRadius,
  formatNumber,
  getActiveBattles,
  getActiveSieges,
  getRelation,
  getShipPose,
  PLAYER_ID,
  STEP_SECONDS,
  type Faction,
  type GameState,
} from "./engine";

interface GameCanvasProps {
  game: GameState;
  preview?: boolean;
  disabled?: boolean;
  showNames?: boolean;
  showGrid?: boolean;
  terrainOnly?: boolean;
  focusSignal?: number;
  zoomCommand?: { key: number; factor: number };
  onCellClick?: (index: number, x: number, y: number) => void;
  onContext?: (index: number, x: number, y: number) => void;
  onHover?: (index: number | null) => void;
  placement?: PlacementInfo | null;
}

interface Camera {
  zoom: number;
  panX: number;
  panY: number;
}

interface PlacementInfo {
  type: string;
  spacing: number | ((index: number) => number);
  label: string;
  check: (index: number) => string;
}

interface Label {
  x: number;
  y: number;
  faction: Faction;
}

function rgb(hex: string): [number, number, number] {
  const value = hex.replace("#", "");
  return [
    parseInt(value.slice(0, 2), 16),
    parseInt(value.slice(2, 4), 16),
    parseInt(value.slice(4, 6), 16),
  ];
}

function renderTerritories(
  game: GameState,
  canvas: HTMLCanvasElement,
  buffer: { image: ImageData | null },
): void {
  const width = game.map.width;
  const height = game.map.height;
  const cw = width * 2;
  const ch = height * 2;
  if (canvas.width !== cw || canvas.height !== ch) {
    canvas.width = cw;
    canvas.height = ch;
    buffer.image = null;
  }
  const context = canvas.getContext("2d")!;
  if (!buffer.image) buffer.image = context.createImageData(cw, ch);
  const image = buffer.image;
  const data = image.data;
  data.fill(0);

  const colors = game.factions.map((faction) => rgb(faction.color));
  const warFactions = new Set(
    game.factions
      .filter((faction) => faction.id !== PLAYER_ID && getRelation(game, PLAYER_ID, faction.id).status === "war")
      .map((faction) => faction.id),
  );

  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const index = y * width + x;
      const owner = game.owners[index];
      if (!owner) continue;
      const color = colors[owner - 1];
      if (!color) continue;

      const leftOwner = x === 0 ? 0 : game.owners[index - 1];
      const rightOwner = x === width - 1 ? 0 : game.owners[index + 1];
      const topOwner = y === 0 ? 0 : game.owners[index - width];
      const bottomOwner = y === height - 1 ? 0 : game.owners[index + width];

      const left = leftOwner !== owner;
      const right = rightOwner !== owner;
      const top = topOwner !== owner;
      const bottom = bottomOwner !== owner;

      for (let dy = 0; dy < 2; dy++) {
        for (let dx = 0; dx < 2; dx++) {
          const offset = ((y * 2 + dy) * cw + x * 2 + dx) * 4;
          const border = (dx === 0 && left) || (dx === 1 && right) || (dy === 0 && top) || (dy === 1 && bottom);
          // Savaş halindeki krallıkların sınırları kalın ve kırmızı çizilir.
          const warBorder = border && warFactions.has(owner);
          const shade = border ? 0.52 : 1;
          if (warBorder) {
            data[offset] = 235;
            data[offset + 1] = 62;
            data[offset + 2] = 46;
            data[offset + 3] = 255;
          } else {
            data[offset] = color[0] * shade;
            data[offset + 1] = color[1] * shade;
            data[offset + 2] = color[2] * shade;
            data[offset + 3] = border ? 236 : 184;
          }
        }
      }
    }
  }
  context.putImageData(image, 0, 0);
}

function getLabels(game: GameState): Label[] {
  return game.factions
    .filter((faction) => faction.land > 10)
    .map((faction) => {
      let x = 0;
      let y = 0;
      let count = 0;
      for (const index of faction.tiles) {
        x += index % game.map.width;
        y += Math.floor(index / game.map.width);
        count++;
      }
      return { x: x / Math.max(1, count), y: y / Math.max(1, count), faction };
    });
}

function drawDie(
  context: CanvasRenderingContext2D,
  x: number,
  y: number,
  value: number,
  accent: string,
): void {
  const size = 15;
  context.save();
  context.translate(x, y);
  context.fillStyle = "#f6f1df";
  context.strokeStyle = accent;
  context.lineWidth = 1.4;
  context.beginPath();
  context.roundRect(-size / 2, -size / 2, size, size, 3);
  context.fill();
  context.stroke();

  const p = 4.1;
  const dots: Array<[number, number]> = [];
  if (value === 1 || value === 3 || value === 5) dots.push([0, 0]);
  if (value === 2 || value === 3 || value === 4 || value === 5 || value === 6) {
    dots.push([-p, -p], [p, p]);
  }
  if (value === 4 || value === 5 || value === 6) dots.push([p, -p], [-p, p]);
  if (value === 6) dots.push([-p, 0], [p, 0]);
  context.fillStyle = "#20364a";
  for (const [dx, dy] of dots) {
    context.beginPath();
    context.arc(dx, dy, 1.45, 0, Math.PI * 2);
    context.fill();
  }
  context.restore();
}

function drawCastleIcon(
  context: CanvasRenderingContext2D,
  x: number,
  y: number,
  size: number,
  level: number,
  fillColor: string,
  borderColor: string,
): void {
  const half = size / 2;
  const toothW = size * 0.25;
  const toothH = size * 0.34;
  context.save();
  context.translate(x, y);

  context.fillStyle = "rgba(8, 17, 27, 0.72)";
  context.beginPath();
  context.roundRect(-half - 2, -half - 2, size + 4, size + 4, 3);
  context.fill();

  context.fillStyle = fillColor;
  context.strokeStyle = borderColor;
  context.lineWidth = 1.4;
  context.beginPath();
  context.rect(-half, -half * 0.55, size, size * 0.98);
  context.fill();
  context.stroke();

  context.fillStyle = borderColor;
  context.fillRect(-half, -half * 0.55 - toothH, toothW, toothH);
  context.fillRect(-toothW / 2, -half * 0.55 - toothH, toothW, toothH);
  context.fillRect(half - toothW, -half * 0.55 - toothH, toothW, toothH);

  context.fillStyle = "#101e2e";
  context.beginPath();
  context.arc(0, half * 0.43, size * 0.16, Math.PI, 0);
  context.lineTo(size * 0.16, half * 0.43);
  context.lineTo(-size * 0.16, half * 0.43);
  context.fill();

  for (let i = 0; i < level; i++) {
    const px = (i - (level - 1) / 2) * 4.5;
    context.fillStyle = "#f2cf78";
    context.beginPath();
    context.arc(px, -half * 0.55 - toothH - 3.2, 1.6, 0, Math.PI * 2);
    context.fill();
  }
  context.restore();
}

function drawPortPixel(
  context: CanvasRenderingContext2D,
  x: number,
  y: number,
  ownerColor: string,
  mine: boolean,
  level: number,
): void {
  context.save();
  context.translate(Math.round(x), Math.round(y));
  context.imageSmoothingEnabled = false;
  context.fillStyle = ownerColor;
  context.strokeStyle = mine ? "#f4f8fa" : "#1a3044";
  context.lineWidth = 1.2;
  context.beginPath();
  context.moveTo(-5, -5);
  context.lineTo(5, -5);
  context.lineTo(7, 1);
  context.lineTo(0, 7);
  context.lineTo(-7, 1);
  context.closePath();
  context.fill();
  context.stroke();

  // Minik piksel çapa.
  context.strokeStyle = "#102338";
  context.fillStyle = "#102338";
  context.lineWidth = 1.3;
  context.beginPath();
  context.arc(0, -2.5, 1.2, 0, Math.PI * 2);
  context.stroke();
  context.beginPath();
  context.moveTo(0, -1.2);
  context.lineTo(0, 4);
  context.moveTo(-3, 1.4);
  context.lineTo(3, 1.4);
  context.moveTo(-4, 2.6);
  context.lineTo(-2.5, 4.4);
  context.moveTo(4, 2.6);
  context.lineTo(2.5, 4.4);
  context.stroke();

  context.font = "800 8px 'DM Sans', Arial";
  context.textAlign = "center";
  context.textBaseline = "middle";
  context.fillStyle = "#ffffff";
  context.fillText(String(level), 0, -9);
  context.restore();
}

function drawTradeShipPixel(
  context: CanvasRenderingContext2D,
  x: number,
  y: number,
  heading: number,
  color: string,
  mine: boolean,
): void {
  context.save();
  // Alt-piksel (sub-pixel) konumlandırma: kare kare atlamayı kaldırır, su üzerinde kayar
  context.translate(x, y);
  context.rotate(heading);

  // Yumuşak V şeklinde dümen suyu izi
  context.strokeStyle = "rgba(225, 245, 255, 0.34)";
  context.lineWidth = 1;
  context.beginPath();
  context.moveTo(-3.5, -0.6);
  context.lineTo(-8.5, -2.6);
  context.moveTo(-3.5, 0.6);
  context.lineTo(-8.5, 2.6);
  context.stroke();

  // Tekne gövdesi
  context.fillStyle = color;
  context.strokeStyle = mine ? "#ffffff" : "#102437";
  context.lineWidth = 1.1;
  context.beginPath();
  context.moveTo(5.2, 0);
  context.quadraticCurveTo(1.5, -3.3, -4.2, -2.4);
  context.lineTo(-3.4, 0);
  context.lineTo(-4.2, 2.4);
  context.quadraticCurveTo(1.5, 3.3, 5.2, 0);
  context.closePath();
  context.fill();
  context.stroke();

  // Beyaz şişkin yelken
  context.fillStyle = "#f7fafc";
  context.beginPath();
  context.moveTo(1.4, -2.6);
  context.quadraticCurveTo(2.8, 0, 1.4, 2.6);
  context.lineTo(-0.8, 1.8);
  context.lineTo(-0.8, -1.8);
  context.closePath();
  context.fill();
  context.restore();
}

function drawCaravanPixel(
  context: CanvasRenderingContext2D,
  x: number,
  y: number,
  heading: number,
  color: string,
  mine: boolean,
): void {
  context.save();
  context.translate(x, y);
  context.rotate(heading);

  // Toz izi
  context.fillStyle = "rgba(196, 174, 128, 0.26)";
  context.fillRect(-8, 1.4, 4, 1.4);
  context.fillRect(-6, -2.6, 3, 1.2);

  // Deve silueti
  context.fillStyle = mine ? "#f0e2bc" : "#d9c9a4";
  context.strokeStyle = "#253323";
  context.lineWidth = 0.9;
  context.beginPath();
  context.moveTo(-4.2, -1.6);
  context.quadraticCurveTo(-3.4, -3.6, -1.8, -3.2);
  context.quadraticCurveTo(-0.6, -3.0, -0.4, -1.4);
  context.lineTo(1.6, -1.4);
  context.quadraticCurveTo(2.6, -1.6, 2.8, -2.4);
  context.lineTo(3.4, -2.4);
  context.lineTo(3.0, -0.8);
  context.lineTo(2.2, -0.8);
  context.lineTo(-1.0, 0.2);
  context.lineTo(-3.4, 0.4);
  context.closePath();
  context.fill();
  context.stroke();

  // Bacaklar
  context.lineWidth = 0.8;
  context.beginPath();
  context.moveTo(-2.8, 0.4); context.lineTo(-3.2, 2.2);
  context.moveTo(-1.2, 0.4); context.lineTo(-1.6, 2.2);
  context.moveTo(1.2, 0.4); context.lineTo(1.6, 2.2);
  context.stroke();

  // Kargo sandığı ve tekerlekli araba
  context.fillStyle = color;
  context.fillRect(-6.6, -1.1, 4.2, 3.4);
  context.strokeStyle = "#253323";
  context.strokeRect(-6.6, -1.1, 4.2, 3.4);
  context.fillStyle = "#f7f3e6";
  context.fillRect(-5.8, -0.4, 2.6, 1.1);
  context.strokeStyle = "#2b2a22";
  context.beginPath();
  context.arc(-5.4, 2.6, 1.1, 0, Math.PI * 2);
  context.arc(-3.6, 2.6, 1.1, 0, Math.PI * 2);
  context.stroke();
  context.restore();
}

function drawBuildingBadge(
  context: CanvasRenderingContext2D,
  type: "barracks" | "town" | "market" | "port" | "siegeworks",
  x: number,
  y: number,
  radius: number,
  ownerColor: string,
  mine: boolean,
  level: number,
): void {
  const accent = {
    barracks: "#f2a487",
    town: "#9fe6a3",
    market: "#f4d27c",
    port: "#7fdff2",
    siegeworks: "#e6aef0",
  }[type];
  const u = radius / 10;

  context.save();
  context.translate(x, y);
  context.beginPath();
  context.arc(0, 0, radius, 0, Math.PI * 2);
  context.fillStyle = "rgba(14, 27, 40, 0.95)";
  context.fill();
  context.lineWidth = mine ? 2.4 : 2;
  context.strokeStyle = ownerColor;
  context.stroke();

  context.strokeStyle = accent;
  context.fillStyle = accent;
  context.lineWidth = Math.max(1.3, radius * 0.14);
  context.lineCap = "round";
  context.lineJoin = "round";
  context.beginPath();
  if (type === "barracks") {
    context.moveTo(-4.2 * u, -5 * u);
    context.lineTo(4.2 * u, -5 * u);
    context.lineTo(4.2 * u, 1 * u);
    context.quadraticCurveTo(4.2 * u, 5 * u, 0, 7 * u);
    context.quadraticCurveTo(-4.2 * u, 5 * u, -4.2 * u, 1 * u);
    context.closePath();
    context.moveTo(0, -5 * u);
    context.lineTo(0, 7 * u);
  } else if (type === "town") {
    context.moveTo(-5.4 * u, 0.8 * u);
    context.lineTo(0, -5.2 * u);
    context.lineTo(5.4 * u, 0.8 * u);
    context.moveTo(-3.6 * u, -0.6 * u);
    context.lineTo(-3.6 * u, 5.8 * u);
    context.lineTo(3.6 * u, 5.8 * u);
    context.lineTo(3.6 * u, -0.6 * u);
  } else if (type === "market") {
    context.moveTo(-5.6 * u, -0.8 * u);
    context.lineTo(-4.2 * u, -5 * u);
    context.lineTo(4.2 * u, -5 * u);
    context.lineTo(5.6 * u, -0.8 * u);
    context.closePath();
    context.moveTo(-4 * u, -0.8 * u);
    context.lineTo(-4 * u, 5.6 * u);
    context.moveTo(4 * u, -0.8 * u);
    context.lineTo(4 * u, 5.6 * u);
    context.moveTo(-4 * u, 5.6 * u);
    context.lineTo(4 * u, 5.6 * u);
  } else if (type === "port") {
    context.arc(0, -4.4 * u, 1.6 * u, 0, Math.PI * 2);
    context.moveTo(0, -2.8 * u);
    context.lineTo(0, 5.8 * u);
    context.moveTo(-3.2 * u, -0.4 * u);
    context.lineTo(3.2 * u, -0.4 * u);
    context.moveTo(-5 * u, 2 * u);
    context.arc(0, 1.2 * u, 5 * u, Math.PI * 0.12, Math.PI * 0.88);
  } else {
    context.moveTo(-5.4 * u, 5.4 * u);
    context.lineTo(5.4 * u, 5.4 * u);
    context.moveTo(-3.2 * u, 5.4 * u);
    context.lineTo(0, -1 * u);
    context.lineTo(3.2 * u, 5.4 * u);
    context.moveTo(0, -1 * u);
    context.lineTo(-4.2 * u, -5 * u);
  }
  context.stroke();
  if (type === "siegeworks") {
    context.beginPath();
    context.arc(-4.8 * u, -5.6 * u, 1.5 * u, 0, Math.PI * 2);
    context.fill();
  }

  for (let i = 1; i < level; i++) {
    context.beginPath();
    context.arc((i - (level - 1) / 2) * 4.2, radius + 4, 1.6, 0, Math.PI * 2);
    context.fillStyle = "#f2cf78";
    context.fill();
  }
  context.restore();
}

function drawCommanderToken(
  context: CanvasRenderingContext2D,
  x: number,
  y: number,
  faction: Faction,
  isPlayer: boolean,
  relationStatus: string,
  zoom: number,
): void {
  const radius = Math.min(13, Math.max(8, 8.5 + zoom * 0.65));

  context.save();
  context.translate(x, y);

  // Outer aura for Player or War Enemy
  if (isPlayer) {
    context.beginPath();
    context.arc(0, 0, radius + 4, 0, Math.PI * 2);
    context.fillStyle = "rgba(88, 215, 234, 0.26)";
    context.fill();
  } else if (relationStatus === "war") {
    context.beginPath();
    context.arc(0, 0, radius + 3.5, 0, Math.PI * 2);
    context.fillStyle = "rgba(229, 92, 85, 0.26)";
    context.fill();
  }

  // Banner shield circle
  context.beginPath();
  context.arc(0, 0, radius, 0, Math.PI * 2);
  context.fillStyle = faction.color;
  context.fill();
  context.lineWidth = isPlayer ? 2.4 : 1.8;
  context.strokeStyle = isPlayer ? "#f8e39a" : relationStatus === "war" ? "#ff7b72" : "#f0f5f8";
  context.stroke();

  // Inner sword/crown mark
  context.fillStyle = "#ffffff";
  context.strokeStyle = "#102030";
  context.lineWidth = 1;
  context.beginPath();
  if (isPlayer) {
    // Crown silhouette
    context.moveTo(-4.5, 2.5);
    context.lineTo(-5.2, -3);
    context.lineTo(-2, 0);
    context.lineTo(0, -4.5);
    context.lineTo(2, 0);
    context.lineTo(5.2, -3);
    context.lineTo(4.5, 2.5);
    context.closePath();
    context.fill();
  } else {
    // Crossed blade / helmet crest
    context.moveTo(0, -4.5);
    context.lineTo(3.5, 2.5);
    context.lineTo(0, 1.2);
    context.lineTo(-3.5, 2.5);
    context.closePath();
    context.fill();
  }

  // Army count badge directly below Commander
  const label = formatNumber(Math.floor(faction.commander.army));
  context.font = "700 10px 'DM Sans', Arial, sans-serif";
  const textW = context.measureText(label).width;
  const pillW = textW + 10;
  const pillH = 14;
  const pillY = radius + 4;

  context.fillStyle = isPlayer
    ? "rgba(15, 34, 51, 0.94)"
    : relationStatus === "war"
      ? "rgba(63, 20, 24, 0.92)"
      : "rgba(18, 30, 44, 0.88)";
  context.strokeStyle = isPlayer ? "#77dce8" : relationStatus === "war" ? "#e57373" : "rgba(255,255,255,0.45)";
  context.lineWidth = 1;
  context.beginPath();
  context.roundRect(-pillW / 2, pillY, pillW, pillH, 3);
  context.fill();
  context.stroke();

  context.fillStyle = "#f4f8fa";
  context.textAlign = "center";
  context.textBaseline = "middle";
  context.fillText(label, 0, pillY + pillH / 2 + 0.4);

  context.restore();
}

export default function GameCanvas({
  game,
  preview = false,
  disabled = false,
  showNames = true,
  showGrid = false,
  terrainOnly = false,
  focusSignal = 0,
  zoomCommand,
  onCellClick,
  onContext,
  onHover,
  placement,
}: GameCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const cameraRef = useRef<Camera>({ zoom: 1, panX: 0, panY: 0 });
  const hoverRef = useRef<number | null>(null);
  const callbacksRef = useRef({ onCellClick, onContext, onHover, placement, disabled, showNames, showGrid, terrainOnly });
  callbacksRef.current = { onCellClick, onContext, onHover, placement, disabled, showNames, showGrid, terrainOnly };

  useEffect(() => {
    if (!zoomCommand?.key || preview) return;
    const camera = cameraRef.current;
    const previous = camera.zoom;
    camera.zoom = Math.max(1, Math.min(6, camera.zoom * zoomCommand.factor));
    const ratio = camera.zoom / previous;
    camera.panX *= ratio;
    camera.panY *= ratio;
  }, [zoomCommand?.key, preview]);

  useEffect(() => {
    if (!focusSignal || preview) return;
    const player = game.factions[0];
    if (!player.land) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const scale = Math.max(rect.width / game.map.width, rect.height / game.map.height) * cameraRef.current.zoom;
    cameraRef.current.panX = -(player.commander.x - game.map.width / 2) * scale;
    cameraRef.current.panY = -(player.commander.y - game.map.height / 2) * scale;
  }, [focusSignal, game, preview]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const context = canvas.getContext("2d", { alpha: false });
    if (!context) return;

    cameraRef.current = { zoom: 1, panX: 0, panY: 0 };
    const territoryLayer = document.createElement("canvas");
    const territoryBuffer: { image: ImageData | null } = { image: null };
    let cachedRevision = -1;
    let lastSimTick = game.tick;
    let lastTickTime = performance.now();
    let labels: Label[] = [];
    let frame = 0;
    let width = 0;
    let height = 0;
    let dpr = 1;
    let press: { x: number; y: number; moved: boolean; button: number; longPressed: boolean } | null = null;
    let longPressTimer: number | undefined;

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      width = rect.width;
      height = rect.height;
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.round(width * dpr);
      canvas.height = Math.round(height * dpr);
    };

    const layout = () => {
      const scale = Math.max(width / game.map.width, height / game.map.height) * cameraRef.current.zoom;
      return {
        scale,
        x: (width - game.map.width * scale) / 2 + cameraRef.current.panX,
        y: (height - game.map.height * scale) / 2 + cameraRef.current.panY,
      };
    };

    const screenPoint = (index: number, view: ReturnType<typeof layout>) => ({
      x: view.x + ((index % game.map.width) + 0.5) * view.scale,
      y: view.y + (Math.floor(index / game.map.width) + 0.5) * view.scale,
    });

    const screenXY = (gx: number, gy: number, view: ReturnType<typeof layout>) => ({
      x: view.x + (gx + 0.5) * view.scale,
      y: view.y + (gy + 0.5) * view.scale,
    });

    const cellAt = (clientX: number, clientY: number): number | null => {
      const rect = canvas.getBoundingClientRect();
      const view = layout();
      const x = Math.floor((clientX - rect.left - view.x) / view.scale);
      const y = Math.floor((clientY - rect.top - view.y) / view.scale);
      if (x < 0 || x >= game.map.width || y < 0 || y >= game.map.height) return null;
      return y * game.map.width + x;
    };

    const zoomBy = (factor: number, clientX = width / 2, clientY = height / 2) => {
      const camera = cameraRef.current;
      const previous = layout();
      const mapX = (clientX - previous.x) / previous.scale;
      const mapY = (clientY - previous.y) / previous.scale;
      camera.zoom = Math.max(1, Math.min(6, camera.zoom * factor));
      const scale = Math.max(width / game.map.width, height / game.map.height) * camera.zoom;
      camera.panX = clientX - (width - game.map.width * scale) / 2 - mapX * scale;
      camera.panY = clientY - (height - game.map.height * scale) / 2 - mapY * scale;
    };

    const draw = (now: number) => {
      if (game.tick !== lastSimTick) {
        lastSimTick = game.tick;
        lastTickTime = now;
      }
      const subTick = Math.max(0, Math.min(1, (now - lastTickTime) / (STEP_SECONDS * 1000)));

      if (game.revision !== cachedRevision) {
        renderTerritories(game, territoryLayer, territoryBuffer);
        labels = getLabels(game);
        cachedRevision = game.revision;
      }

      context.setTransform(dpr, 0, 0, dpr, 0, 0);
      context.fillStyle = "#306c95";
      context.fillRect(0, 0, width, height);

      const view = layout();
      const mapWidth = game.map.width * view.scale;
      const mapHeight = game.map.height * view.scale;

      context.imageSmoothingEnabled = false;
      context.drawImage(game.map.texture, view.x, view.y, mapWidth, mapHeight);
      if (!callbacksRef.current.terrainOnly) {
        context.drawImage(territoryLayer, view.x, view.y, mapWidth, mapHeight);
      }
      context.imageSmoothingEnabled = true;

      if (callbacksRef.current.showGrid && !preview) {
        context.strokeStyle = "rgba(255,255,255,.12)";
        context.lineWidth = 1;
        context.beginPath();
        for (let x = 0; x <= game.map.width; x += 24) {
          const px = view.x + x * view.scale;
          context.moveTo(px, view.y);
          context.lineTo(px, view.y + mapHeight);
        }
        for (let y = 0; y <= game.map.height; y += 24) {
          const py = view.y + y * view.scale;
          context.moveTo(view.x, py);
          context.lineTo(view.x + mapWidth, py);
        }
        context.stroke();
      }

      if (!preview) {
        // Kervan yolları: pazarların kalıcı ticaret güzergâhları
        const playerMarkets = new Set(
          [...game.buildings.entries()]
            .filter(([, building]) => building.type === "market" && building.owner === PLAYER_ID)
            .map(([index]) => index),
        );
        if (playerMarkets.size) {
          context.save();
          for (const [key, path] of game.roads) {
            const from = Number(key.split(":")[0]);
            if (!playerMarkets.has(from) || path.length < 2) continue;
            context.beginPath();
            const step = Math.max(1, Math.floor(path.length / 28));
            for (let i = 0; i < path.length; i += step) {
              const cell = path[i];
              const point = screenPoint(cell, view);
              if (i === 0) context.moveTo(point.x, point.y);
              else context.lineTo(point.x, point.y);
            }
            const last = screenPoint(path[path.length - 1], view);
            context.lineTo(last.x, last.y);
            context.strokeStyle = "rgba(214, 186, 129, 0.34)";
            context.lineWidth = Math.max(1, Math.min(2.4, 0.8 + cameraRef.current.zoom * 0.22));
            context.stroke();
            context.strokeStyle = "rgba(255, 241, 205, 0.2)";
            context.lineWidth = 0.8;
            context.setLineDash([3, 5]);
            context.stroke();
            context.setLineDash([]);
          }
          context.restore();
        }

        const sieges = getActiveSieges(game);
        const siegeByCastle = new Map(sieges.map((s) => [s.castleIndex, s]));

        // 1. Draw subtle castle defense zones for player & selected/sieged castles
        for (const [index, building] of game.buildings) {
          if (building.type !== "castle") continue;
          const point = screenPoint(index, view);
          if (point.x < -90 || point.x > width + 90 || point.y < -90 || point.y > height + 90) continue;

          const activeSiege = siegeByCastle.get(index);
          const guardPx = castleGuardRadius(building.level) * view.scale;

          if (activeSiege) {
            // Pulsing siege perimeter
            context.save();
            context.beginPath();
            context.arc(point.x, point.y, guardPx * 0.72, 0, Math.PI * 2);
            context.fillStyle = "rgba(229, 77, 66, 0.14)";
            context.fill();
            context.strokeStyle = `rgba(244, 150, 92, ${0.62 + Math.sin(now * 0.008) * 0.28})`;
            context.lineWidth = 2;
            context.setLineDash([6, 4]);
            context.lineDashOffset = -now * 0.018;
            context.stroke();
            context.restore();
          } else if (building.owner === PLAYER_ID || game.selected === index) {
            context.beginPath();
            context.arc(point.x, point.y, guardPx, 0, Math.PI * 2);
            context.strokeStyle =
              building.owner === PLAYER_ID ? "rgba(116, 223, 236, 0.22)" : "rgba(255, 255, 255, 0.2)";
            context.lineWidth = 1;
            context.setLineDash([4, 4]);
            context.stroke();
            context.setLineDash([]);

            if (game.selected === index) {
              const supplyPx = castleSupplyRadius(building.level) * view.scale;
              context.beginPath();
              context.arc(point.x, point.y, supplyPx, 0, Math.PI * 2);
              context.strokeStyle = "rgba(242, 207, 120, 0.48)";
              context.lineWidth = 1.3;
              context.setLineDash([8, 6]);
              context.stroke();
              context.setLineDash([]);
              context.fillStyle = "rgba(249, 226, 164, 0.88)";
              context.font = "700 9px 'DM Sans', Arial";
              context.textAlign = "center";
              context.fillText("İKMAL MENZİLİ", point.x, point.y - supplyPx - 5);
            }
          }
        }

        // 2. Draw all medieval structures
        for (const [index, building] of game.buildings) {
          const point = screenPoint(index, view);
          if (point.x < -30 || point.x > width + 30 || point.y < -30 || point.y > height + 30) continue;

          if (building.type === "castle") {
            const ownerColor = game.factions[building.owner - 1]?.color || "#ffffff";
            const size = (10 + building.level * 1.5) * Math.min(1.9, 0.85 + cameraRef.current.zoom * 0.28);
            drawCastleIcon(
              context,
              point.x,
              point.y,
              size,
              building.level,
              building.owner === PLAYER_ID ? "#245471" : ownerColor,
              building.owner === PLAYER_ID ? "#f4d786" : "#eef4f7",
            );

            // Wall Durability Bar under damaged or besieged castles
            const activeSiege = siegeByCastle.get(index);
            if (activeSiege || building.wallHp < building.maxWallHp) {
              const barW = 28;
              const barH = 4;
              const bx = point.x - barW / 2;
              const by = point.y + size / 2 + 4;
              const ratio = Math.max(0, Math.min(1, building.wallHp / Math.max(1, building.maxWallHp)));

              context.fillStyle = "rgba(10, 18, 28, 0.9)";
              context.fillRect(bx - 1, by - 1, barW + 2, barH + 2);
              context.fillStyle = activeSiege ? "#ef6b5b" : "#e3ba64";
              context.fillRect(bx, by, barW * ratio, barH);

              if (activeSiege) {
                context.font = "700 9px 'DM Sans', Arial, sans-serif";
                context.textAlign = "center";
                context.fillStyle = "#ffd18c";
                context.fillText("KUŞATMA", point.x, by + 13);
              }
            }
          } else if (building.type === "port") {
            drawPortPixel(
              context,
              point.x,
              point.y,
              game.factions[building.owner - 1]?.color ?? "#7fdff2",
              building.owner === PLAYER_ID,
              building.level,
            );
          } else {
            const badgeRadius = Math.min(10, Math.max(7, 6 + cameraRef.current.zoom * 1));
            drawBuildingBadge(
              context,
              building.type,
              point.x,
              point.y,
              badgeRadius,
              game.factions[building.owner - 1]?.color ?? "#ffffff",
              building.owner === PLAYER_ID,
              building.level,
            );
          }
        }

        // Yapı yerleştirme önizlemesi: geçerli/geçersiz alan ve nedeni
        const placementInfo = callbacksRef.current.placement;
        if (placementInfo) {
          if (placementInfo.type === "castle") {
            for (const [index, building] of game.buildings) {
              if (building.type !== "castle" || building.owner !== PLAYER_ID) continue;
              const p = screenPoint(index, view);
              const supplyPx = castleSupplyRadius(building.level) * view.scale;
              context.beginPath();
              context.arc(p.x, p.y, supplyPx, 0, Math.PI * 2);
              context.fillStyle = "rgba(242, 207, 120, 0.06)";
              context.fill();
              context.strokeStyle = "rgba(242, 207, 120, 0.5)";
              context.lineWidth = 1.3;
              context.setLineDash([8, 6]);
              context.stroke();
              context.setLineDash([]);
            }
          }
          const hovered = hoverRef.current;
          if (hovered !== null && game.map.land[hovered]) {
            const error = placementInfo.check(hovered);
            const ok = !error;
            const p = screenPoint(hovered, view);
            context.beginPath();
            const hoverSpacing =
              typeof placementInfo.spacing === "function"
                ? placementInfo.spacing(hovered)
                : placementInfo.spacing;
            context.arc(p.x, p.y, hoverSpacing * view.scale, 0, Math.PI * 2);
            context.fillStyle = ok ? "rgba(110, 225, 150, 0.10)" : "rgba(238, 98, 86, 0.10)";
            context.fill();
            context.strokeStyle = ok ? "rgba(120, 232, 160, 0.85)" : "rgba(244, 110, 98, 0.85)";
            context.lineWidth = 1.5;
            context.setLineDash([6, 5]);
            context.stroke();
            context.setLineDash([]);
            context.beginPath();
            context.arc(p.x, p.y, 6, 0, Math.PI * 2);
            context.fillStyle = ok ? "#78e8a0" : "#f46e62";
            context.fill();
            context.strokeStyle = "#ffffff";
            context.lineWidth = 1.6;
            context.stroke();

            const label = ok ? `${placementInfo.label}: buraya kurulabilir` : error;
            context.font = "700 11px 'DM Sans', Arial, sans-serif";
            const textWidth = context.measureText(label).width;
            const pillW = textWidth + 16;
            const pillX = Math.max(pillW / 2 + 6, Math.min(width - pillW / 2 - 6, p.x));
            const pillY = Math.max(78, p.y - 30);
            context.fillStyle = ok ? "rgba(16, 52, 33, 0.96)" : "rgba(64, 22, 24, 0.96)";
            context.strokeStyle = ok ? "#78e8a0" : "#f46e62";
            context.lineWidth = 1.2;
            context.beginPath();
            context.roundRect(pillX - pillW / 2, pillY - 10, pillW, 20, 4);
            context.fill();
            context.stroke();
            context.fillStyle = "#ffffff";
            context.textAlign = "center";
            context.textBaseline = "middle";
            context.fillText(label, pillX, pillY);
          }
        }

        // 3. Kingdom Names
        if (callbacksRef.current.showNames && !callbacksRef.current.terrainOnly) {
          context.textAlign = "center";
          context.textBaseline = "middle";
          for (const label of labels) {
            const point = {
              x: view.x + (label.x + 0.5) * view.scale,
              y: view.y + (label.y + 0.5) * view.scale,
            };
            if (point.x < -110 || point.x > width + 110 || point.y < -30 || point.y > height + 30) continue;
            const size = Math.min(18, Math.max(10, 9.5 + Math.sqrt(label.faction.land) * 0.22));
            const labelOffsetY = label.faction.land < 65 ? -21 : -10;
            context.font = `700 ${size}px 'DM Sans', Arial, sans-serif`;
            context.shadowColor = "rgba(10, 22, 34, 0.92)";
            context.shadowBlur = 5;
            context.lineWidth = 3;
            context.strokeStyle = "rgba(12, 24, 36, 0.75)";
            context.strokeText(label.faction.name, point.x, point.y + labelOffsetY);
            context.fillStyle = "rgba(248, 251, 253, 0.95)";
            context.fillText(label.faction.name, point.x, point.y + labelOffsetY);
            context.shadowBlur = 0;
          }
        }

        // 4. Commander March Paths (Player & War Enemies)
        for (const faction of game.factions) {
          if (!faction.land) continue;
          const cmd = faction.commander;
          if (cmd.targetX === null || cmd.targetY === null) continue;
          const isPlayer = faction.id === PLAYER_ID;
          const rel = isPlayer ? "self" : getRelation(game, PLAYER_ID, faction.id).status;
          if (!isPlayer && rel !== "war" && rel !== "alliance") continue;

          const from = screenXY(cmd.x, cmd.y, view);
          const to = screenXY(cmd.targetX, cmd.targetY, view);
          context.beginPath();
          context.moveTo(from.x, from.y);
          if (cmd.route && cmd.route.length > 1) {
            const step = Math.max(1, Math.floor(cmd.route.length / 40));
            for (let r = 0; r < cmd.route.length; r += step) {
              const pt = screenPoint(cmd.route[r], view);
              context.lineTo(pt.x, pt.y);
            }
          }
          context.lineTo(to.x, to.y);
          context.strokeStyle = isPlayer
            ? "rgba(124, 229, 242, 0.9)"
            : rel === "war"
              ? "rgba(238, 108, 98, 0.72)"
              : "rgba(155, 227, 175, 0.65)";
          context.lineWidth = isPlayer ? 2.1 : 1.4;
          context.setLineDash([7, 5]);
          context.lineDashOffset = -now * 0.025;
          context.stroke();
          context.setLineDash([]);

          if (isPlayer) {
            context.beginPath();
            context.arc(to.x, to.y, 4.5, 0, Math.PI * 2);
            context.fillStyle = "#7ce5f2";
            context.fill();
            context.strokeStyle = "#102838";
            context.lineWidth = 1.5;
            context.stroke();
          }
        }

        // 5. Kavisli deniz rotaları, 60fps akıcı ticaret gemileri ve çıkarmalar
        const strokeRoute = (path: number[], color: string, lineWidth: number, dash: number[]) => {
          if (path.length < 2) return;
          context.beginPath();
          const samples = Math.min(90, Math.max(16, Math.floor(path.length / 2)));
          for (let s = 0; s <= samples; s++) {
            const prog = (s / samples) * (path.length - 1);
            const pose = getShipPose(game, path, prog, 1);
            const point = screenXY(pose.x, pose.y, view);
            if (s === 0) context.moveTo(point.x, point.y);
            else context.lineTo(point.x, point.y);
          }
          context.strokeStyle = color;
          context.lineWidth = lineWidth;
          context.setLineDash(dash);
          context.stroke();
          context.setLineDash([]);
        };

        const drawnRoutes = new Set<string>();
        for (const trade of game.tradeShips) {
          const routeKey = `${trade.fromPort}:${trade.toPort}`;
          if (trade.owner === PLAYER_ID && !drawnRoutes.has(routeKey)) {
            strokeRoute(trade.path, "rgba(241, 204, 112, 0.2)", 1, [4, 7]);
            drawnRoutes.add(routeKey);
          }
          const liveProgress = Math.max(
            0,
            Math.min(trade.path.length - 1, trade.pathProgress + trade.direction * trade.speed * subTick),
          );
          const pose = getShipPose(game, trade.path, liveProgress, trade.direction);
          const waveSway = trade.laneOffset + Math.sin(now * 0.0024 + trade.id * 1.9) * 0.22;
          const offsetX = -Math.sin(pose.heading) * waveSway;
          const offsetY = Math.cos(pose.heading) * waveSway;
          const point = screenXY(pose.x + offsetX, pose.y + offsetY, view);
          if (point.x < -20 || point.x > width + 20 || point.y < -20 || point.y > height + 20) continue;
          const color = game.factions[trade.owner - 1]?.color || "#e8c979";
          const smoothHeading = pose.heading + Math.cos(now * 0.0024 + trade.id * 1.9) * 0.06;
          drawTradeShipPixel(
            context,
            point.x,
            point.y,
            smoothHeading,
            color,
            trade.owner === PLAYER_ID,
          );
        }

        const drawnCaravanRoutes = new Set<string>();
        for (const caravan of game.caravans) {
          const routeKey = `${caravan.fromMarket}:${caravan.toCell}`;
          if (caravan.owner === PLAYER_ID && !drawnCaravanRoutes.has(routeKey)) {
            strokeRoute(caravan.path, "rgba(226, 196, 122, 0.16)", 1, [2, 6]);
            drawnCaravanRoutes.add(routeKey);
          }
          const ahead = caravan.direction * caravan.speed * subTick;
          const point = screenXY(
            caravan.x + Math.cos(caravan.heading) * ahead,
            caravan.y + Math.sin(caravan.heading) * ahead,
            view,
          );
          if (point.x < -20 || point.x > width + 20 || point.y < -20 || point.y > height + 20) continue;
          const color = game.factions[caravan.owner - 1]?.color || "#e8c979";
          drawCaravanPixel(context, point.x, point.y, caravan.heading, color, caravan.owner === PLAYER_ID);
        }

        for (const landing of game.landings) {
          strokeRoute(landing.path, "rgba(244, 221, 158, 0.66)", 1.6, [7, 5]);
          const liveProg = Math.min(landing.path.length - 1, landing.pathProgress + 1.75 * subTick);
          const pose = getShipPose(game, landing.path, liveProg, 1);
          const point = screenXY(pose.x, pose.y, view);
          drawTradeShipPixel(context, point.x, point.y, pose.heading, "#f4dd9e", true);
        }

        // 6. Commanders (Visible mobile armies on the map!)
        if (game.phase !== "spawn") {
          for (const faction of game.factions) {
            if (!faction.land || faction.commander.army < 50 || faction.commander.stance === "embarked") continue;
            const p = screenXY(faction.commander.x, faction.commander.y, view);
            if (p.x < -50 || p.x > width + 50 || p.y < -50 || p.y > height + 50) continue;
            const isPlayer = faction.id === PLAYER_ID;
            const rel = isPlayer ? "self" : getRelation(game, PLAYER_ID, faction.id).status;
            drawCommanderToken(context, p.x, p.y, faction, isPlayer, rel, cameraRef.current.zoom);
          }
        }

        // 7. Active Field Battles (Meydan Muharebesi clash indicators)
        const battles = getActiveBattles(game);
        for (const battle of battles) {
          const p = screenXY(battle.x, battle.y, view);
          if (p.x < -60 || p.x > width + 60 || p.y < -60 || p.y > height + 60) continue;
          const pulse = 18 + Math.sin(now * 0.012) * 4;
          context.beginPath();
          context.arc(p.x, p.y, pulse, 0, Math.PI * 2);
          context.fillStyle = "rgba(235, 96, 72, 0.18)";
          context.fill();
          context.strokeStyle = "rgba(255, 204, 112, 0.9)";
          context.lineWidth = 2;
          context.stroke();

          // Crossed-swords battle pill
          const label = `SAVAŞ ${formatNumber(battle.attackerArmy)} / ${formatNumber(battle.defenderArmy)}`;
          context.font = "700 10px 'DM Sans', Arial, sans-serif";
          const tw = context.measureText(label).width;
          context.fillStyle = "rgba(56, 17, 20, 0.94)";
          context.strokeStyle = "#f2b863";
          context.lineWidth = 1.2;
          context.beginPath();
          context.roundRect(p.x - (tw + 12) / 2, p.y - 28, tw + 12, 16, 3);
          context.fill();
          context.stroke();
          context.fillStyle = "#ffe8bc";
          context.textAlign = "center";
          context.textBaseline = "middle";
          context.fillText(label, p.x, p.y - 20);

          const dice = game.lastBattleDice;
          if (dice && dice.aId === battle.attackerId && dice.bId === battle.defenderId) {
            context.save();
            context.textAlign = "center";
            context.textBaseline = "middle";
            context.font = "700 9px 'DM Sans', Arial";
            context.fillStyle = "#f4d38e";
            context.fillText("ZAR", p.x, p.y - 62);
            drawDie(context, p.x - 39, p.y - 47, dice.aDice[0], "#7ce5f2");
            drawDie(context, p.x - 21, p.y - 47, dice.aDice[1], "#7ce5f2");
            context.fillStyle = "#e9f1f5";
            context.fillText("vs", p.x, p.y - 47);
            drawDie(context, p.x + 21, p.y - 47, dice.bDice[0], "#f09a86");
            drawDie(context, p.x + 39, p.y - 47, dice.bDice[1], "#f09a86");
            context.fillStyle = dice.totalA >= dice.totalB ? "#7ce5f2" : "#f09a86";
            context.fillText(
              `${dice.totalA} : ${dice.totalB}`,
              p.x,
              p.y - 34,
            );
            context.restore();
          }
        }

        // 8. Effects (Bombardment, siege collapse, sparks, war flare)
        for (const effect of game.effects) {
          if (effect.type === "gold") {
            const goldPoint = screenXY(effect.x, effect.y, view);
            const goldAge = Math.min(1, (game.tick - effect.started) / 44);
            const goldText = `+${formatNumber(effect.amount ?? 0)} ◆`;
            const goldY = goldPoint.y - 18 - goldAge * 36;
            context.save();
            context.globalAlpha = 1 - goldAge * goldAge;
            context.font = "800 16px 'DM Sans', Arial, sans-serif";
            context.textAlign = "center";
            context.textBaseline = "middle";
            context.lineWidth = 4;
            context.strokeStyle = "rgba(14, 26, 38, 0.92)";
            context.strokeText(goldText, goldPoint.x, goldY);
            context.fillStyle = effect.mine ? "#ffe08a" : "#f4f0d8";
            context.fillText(goldText, goldPoint.x, goldY);
            context.restore();
            continue;
          }
          const point = screenXY(effect.x, effect.y, view);
          const age = (game.tick - effect.started) / 22;
          const maxR =
            effect.type === "bombard"
              ? 46
              : effect.type === "siege_fall"
                ? 58
                : effect.type === "war"
                  ? 52
                  : 26;
          const radius = maxR * (0.2 + age * 1.25);
          context.beginPath();
          context.arc(point.x, point.y, radius, 0, Math.PI * 2);
          context.strokeStyle =
            effect.type === "bombard" || effect.type === "siege_fall"
              ? `rgba(255, 210, 128, ${1 - age})`
              : effect.type === "war" || effect.type === "battle"
                ? `rgba(244, 102, 92, ${1 - age})`
                : `rgba(255, 255, 255, ${1 - age})`;
          context.lineWidth = 3.5 * (1 - age) + 1;
          context.stroke();
        }

        // 9. Selected cell ring
        if (game.selected !== null && game.phase !== "spawn") {
          const point = screenPoint(game.selected, view);
          const radius = 10 + Math.sin(now * 0.004) * 1.6;
          context.beginPath();
          context.arc(point.x, point.y, radius, 0, Math.PI * 2);
          context.strokeStyle = "rgba(255, 255, 255, 0.92)";
          context.lineWidth = 1.5;
          context.stroke();
        }

        // 10. Spawn target reticle
        if (game.phase === "spawn" && hoverRef.current !== null && game.map.land[hoverRef.current]) {
          const point = screenPoint(hoverRef.current, view);
          const radius = 20 + Math.sin(now * 0.005) * 3;
          context.beginPath();
          context.arc(point.x, point.y, radius, 0, Math.PI * 2);
          context.strokeStyle = "rgba(246, 224, 152, 0.95)";
          context.lineWidth = 2;
          context.stroke();
          context.beginPath();
          context.arc(point.x, point.y, 3.5, 0, Math.PI * 2);
          context.fillStyle = "#ffffff";
          context.fill();
        }
      }

      frame = requestAnimationFrame(draw);
    };

    const onPointerDown = (event: PointerEvent) => {
      if (preview || callbacksRef.current.disabled) return;
      press = { x: event.clientX, y: event.clientY, moved: false, button: event.button, longPressed: false };
      canvas.setPointerCapture(event.pointerId);
      if (event.pointerType === "touch") {
        longPressTimer = window.setTimeout(() => {
          if (!press || press.moved) return;
          const cell = cellAt(press.x, press.y);
          if (cell !== null && game.map.land[cell]) {
            press.longPressed = true;
            callbacksRef.current.onContext?.(cell, press.x, press.y);
          }
        }, 550);
      }
    };

    const onPointerMove = (event: PointerEvent) => {
      if (preview) return;
      const cell = cellAt(event.clientX, event.clientY);
      if (hoverRef.current !== cell) callbacksRef.current.onHover?.(cell !== null && game.map.land[cell] ? cell : null);
      hoverRef.current = cell;
      canvas.style.cursor = cell !== null && game.map.land[cell] ? "crosshair" : "grab";
      if (!press || press.button !== 0 || callbacksRef.current.disabled) return;
      const dx = event.clientX - press.x;
      const dy = event.clientY - press.y;
      if (Math.abs(dx) + Math.abs(dy) > 5) {
        press.moved = true;
        clearTimeout(longPressTimer);
      }
      if (press.moved) {
        cameraRef.current.panX += dx;
        cameraRef.current.panY += dy;
        press.x = event.clientX;
        press.y = event.clientY;
        canvas.style.cursor = "grabbing";
      }
    };

    const onPointerUp = (event: PointerEvent) => {
      clearTimeout(longPressTimer);
      if (!press || preview || callbacksRef.current.disabled) {
        press = null;
        return;
      }
      if (!press.moved && !press.longPressed) {
        const cell = cellAt(event.clientX, event.clientY);
        if (cell !== null && game.map.land[cell]) {
          if (press.button === 2) callbacksRef.current.onContext?.(cell, event.clientX, event.clientY);
          else callbacksRef.current.onCellClick?.(cell, event.clientX, event.clientY);
        }
      }
      press = null;
    };

    const onWheel = (event: WheelEvent) => {
      if (preview || callbacksRef.current.disabled) return;
      event.preventDefault();
      const rect = canvas.getBoundingClientRect();
      zoomBy(event.deltaY > 0 ? 0.88 : 1.14, event.clientX - rect.left, event.clientY - rect.top);
    };

    const onKeyDown = (event: KeyboardEvent) => {
      if (preview || callbacksRef.current.disabled || event.target instanceof HTMLInputElement) return;
      const key = event.key.toLowerCase();
      const step = event.shiftKey ? 90 : 46;
      if (key === "w" || key === "arrowup") cameraRef.current.panY += step;
      if (key === "s" || key === "arrowdown") cameraRef.current.panY -= step;
      if (key === "a" || key === "arrowleft") cameraRef.current.panX += step;
      if (key === "d" || key === "arrowright") cameraRef.current.panX -= step;
      if (key === "q") zoomBy(0.8);
      if (key === "e") zoomBy(1.25);
      if (["w", "a", "s", "d", "q", "e", "arrowup", "arrowdown", "arrowleft", "arrowright"].includes(key)) {
        event.preventDefault();
      }
    };

    resize();
    const observer = new ResizeObserver(resize);
    observer.observe(canvas);
    canvas.addEventListener("pointerdown", onPointerDown);
    canvas.addEventListener("pointermove", onPointerMove);
    canvas.addEventListener("pointerup", onPointerUp);
    const onLeave = () => {
      hoverRef.current = null;
      callbacksRef.current.onHover?.(null);
    };
    canvas.addEventListener("pointercancel", onPointerUp);
    canvas.addEventListener("pointerleave", onLeave);
    canvas.addEventListener("wheel", onWheel, { passive: false });
    canvas.addEventListener("contextmenu", (event) => event.preventDefault());
    window.addEventListener("keydown", onKeyDown);
    frame = requestAnimationFrame(draw);

    return () => {
      cancelAnimationFrame(frame);
      clearTimeout(longPressTimer);
      observer.disconnect();
      canvas.removeEventListener("pointerdown", onPointerDown);
      canvas.removeEventListener("pointermove", onPointerMove);
      canvas.removeEventListener("pointerup", onPointerUp);
      canvas.removeEventListener("pointercancel", onPointerUp);
      canvas.removeEventListener("pointerleave", onLeave);
      canvas.removeEventListener("wheel", onWheel);
      window.removeEventListener("keydown", onKeyDown);
    };
  }, [game, preview]);

  return (
    <canvas
      ref={canvasRef}
      className={`game-canvas${preview ? " game-canvas--preview" : ""}`}
      aria-label="Etkileşimli strateji haritası"
    />
  );
}
