import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { AnimatePresence, motion, useIsPresent } from "framer-motion";
import {
  Anchor,
  ArrowRight,
  ArrowUpCircle,
  ArrowUpRight,
  BarChart3,
  Castle,
  Check,
  ChevronRight,
  CircleHelp,
  Compass,
  Crown,
  Flame,
  Flag,
  Globe2,
  Hammer,
  Handshake,
  Home,
  Map as MapIcon,
  Menu,
  Minus,
  Pause,
  Play,
  Plus,
  RotateCcw,
  ScrollText,
  Settings2,
  Shield,
  ShieldAlert,
  Ship,
  Store,
  Swords,
  Trophy,
  UserPlus,
  Users,
  Volume2,
  VolumeX,
  Wrench,
  X,
  ZoomIn,
  ZoomOut,
  type LucideIcon,
} from "lucide-react";
import "@fontsource/barlow-condensed/700.css";
import "@fontsource/barlow-condensed/800.css";
import "@fontsource/barlow-condensed/900.css";
import "@fontsource/dm-sans/400.css";
import "@fontsource/dm-sans/500.css";
import "@fontsource/dm-sans/600.css";
import "@fontsource/dm-sans/700.css";
import GameCanvas from "./game/GameCanvas";
import {
  BUILDINGS,
  BUILDING_DETAILS,
  MAX_STRUCTURE_LEVEL,
  buildingSpacing,
  getCapacity,
  getTotalTroops,
  PLAYER_ID,
  STEP_SECONDS,
  bombardTarget,
  buildStructure,
  buySiegeWeapon,
  commandMove,
  createGame,
  createPreviewGame,
  declareWar,
  formatNumber,
  getBuildingCost,
  getBuildingPlacementError,
  getSnapshot,
  proposePeace,
  recruitTroops,
  repairCastle,
  repairCastleCost,
  respondToNotification,
  dismissNotification,
  setAutoExpand,
  setAutoSiege,
  retreatFromSiege,
  sendBoat,
  signTruce,
  spawnPlayer,
  tickGame,
  toggleAlliance,
  upgradeBuilding,
  upgradeCost,
  type BuildingType,
  type Difficulty,
  type GameSnapshot,
  type GameState,
  type RelationStatus,
} from "./game/engine";
import { getTerrainMap, MAPS, type MapId } from "./game/map";

type Screen = "home" | "game";
type Overlay = "setup" | "guide" | "settings" | "scores" | null;
type Tool = "march" | "boat" | "bombard";
type SetupTab = "solo" | "online";

interface SettingsState {
  showNames: boolean;
  showGrid: boolean;
  sound: boolean;
  autoExpand: boolean;
  defaultRatio: number;
}

interface Score {
  name: string;
  map: string;
  percent: number;
  time: number;
  date: string;
}

const PLAYER_COLORS = ["#25a9d3", "#67b58c", "#c491dc", "#e3a25d", "#e47e88"];
const MAP_IDS = Object.keys(MAPS) as MapId[];
const BUILD_ORDER: BuildingType[] = ["castle", "barracks", "town", "market", "port"];
const BUILDING_ICONS: Record<BuildingType, LucideIcon> = {
  castle: Castle,
  barracks: Shield,
  town: Home,
  market: Store,
  port: Anchor,
  siegeworks: Flame,
};

const RELATION_LABEL: Record<RelationStatus, string> = {
  peace: "Barış",
  war: "Savaşta",
  truce: "Ateşkes",
  alliance: "Müttefik",
};

function loadSettings(): SettingsState {
  const defaults: SettingsState = {
    showNames: true,
    showGrid: false,
    sound: false,
    autoExpand: true,
    defaultRatio: 55,
  };
  try {
    const saved = JSON.parse(localStorage.getItem("front-settings") || "null");
    return saved ? { ...defaults, ...saved } : defaults;
  } catch {
    return defaults;
  }
}

function loadScores(): Score[] {
  try {
    const saved = JSON.parse(localStorage.getItem("front-scores") || "[]");
    return Array.isArray(saved) ? saved : [];
  } catch {
    return [];
  }
}

function formatTime(tick: number): string {
  const seconds = Math.floor(tick * STEP_SECONDS);
  return `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;
}

function BrandMark({ className = "" }: { className?: string }) {
  return (
    <span className={`brand-mark ${className}`} aria-hidden="true">
      <svg viewBox="0 0 64 64" fill="none">
        <path
          d="M14 14h8v7h6v-7h8v7h6v-7h8v14l-5 5v19H19V33l-5-5V14Z"
          fill="currentColor"
        />
        <path
          d="M27 52V39a5 5 0 0 1 10 0v13H27Z"
          fill="#132337"
        />
        <path
          d="M32 6l4 5h-8l4-5Z"
          fill="#f2cf78"
        />
      </svg>
    </span>
  );
}

function Brand({ compact = false }: { compact?: boolean }) {
  return (
    <span className={`brand ${compact ? "brand--compact" : ""}`}>
      <BrandMark />
      <span className="brand-word">
        OPEN<span>FRONT</span>
      </span>
    </span>
  );
}

function Modal({
  children,
  onClose,
  wide = false,
  className = "",
}: {
  children: ReactNode;
  onClose: () => void;
  wide?: boolean;
  className?: string;
}) {
  const isPresent = useIsPresent();
  return (
    <motion.div
      className="modal-backdrop"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.2 }}
      style={{ pointerEvents: isPresent ? "auto" : "none" }}
      onMouseDown={onClose}
    >
      <motion.div
        className={`modal-panel ${wide ? "modal-panel--wide" : ""} ${className}`}
        initial={{ opacity: 0, y: 24, scale: 0.97 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 14, scale: 0.98 }}
        transition={{ type: "spring", stiffness: 300, damping: 29 }}
        onMouseDown={(event) => event.stopPropagation()}
        role="dialog"
        aria-modal="true"
      >
        {children}
      </motion.div>
    </motion.div>
  );
}

function ModalHeading({
  kicker,
  title,
  onClose,
  description,
}: {
  kicker: string;
  title: string;
  onClose: () => void;
  description?: string;
}) {
  return (
    <div className="modal-heading">
      <div>
        <div className="section-kicker">{kicker}</div>
        <h2>{title}</h2>
        {description && <p>{description}</p>}
      </div>
      <button className="icon-button modal-close" onClick={onClose} aria-label="Kapat">
        <X size={20} />
      </button>
    </div>
  );
}

function MapThumbnail({ id }: { id: MapId }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const context = canvas.getContext("2d");
    if (!context) return;
    const map = getTerrainMap(id);
    context.imageSmoothingEnabled = false;
    context.drawImage(map.texture, 0, 0, canvas.width, canvas.height);
  }, [id]);
  return <canvas ref={canvasRef} width={156} height={84} aria-hidden="true" />;
}

function MiniMap({ game, revision, onClick }: { game: GameState; revision: number; onClick: () => void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = canvasRef.current;
    const context = canvas?.getContext("2d");
    if (!canvas || !context) return;
    context.drawImage(game.map.texture, 0, 0, canvas.width, canvas.height);
    context.globalAlpha = 0.88;
    for (let i = 0; i < game.owners.length; i++) {
      const owner = game.owners[i];
      if (!owner) continue;
      context.fillStyle = game.factions[owner - 1].color;
      context.fillRect(
        ((i % game.map.width) * canvas.width) / game.map.width,
        (Math.floor(i / game.map.width) * canvas.height) / game.map.height,
        1.1,
        1.1,
      );
    }
    context.globalAlpha = 1;
    // Mark player's Commander dot
    const player = game.factions[0];
    if (player && player.land > 0) {
      context.fillStyle = "#ffffff";
      context.beginPath();
      context.arc(
        (player.commander.x * canvas.width) / game.map.width,
        (player.commander.y * canvas.height) / game.map.height,
        2.5,
        0,
        Math.PI * 2,
      );
      context.fill();
    }
  }, [game, revision]);
  return (
    <button
      className="minimap"
      onClick={onClick}
      title="Kamerayı komutanına odakla"
      aria-label="Kamerayı komutanına odakla"
    >
      <canvas ref={canvasRef} width={236} height={133} />
      <span className="minimap-caption">
        <MapIcon size={13} /> {MAPS[game.map.id].name.toUpperCase()}
      </span>
    </button>
  );
}

function Toggle({ checked, onChange }: { checked: boolean; onChange: () => void }) {
  return (
    <button
      className={`toggle ${checked ? "toggle--on" : ""}`}
      role="switch"
      aria-checked={checked}
      onClick={onChange}
    >
      <span />
    </button>
  );
}

export default function App() {
  const previewGame = useMemo(() => createPreviewGame(getTerrainMap("europe")), []);
  const [screen, setScreen] = useState<Screen>("home");
  const [overlay, setOverlay] = useState<Overlay>(null);
  const [setupTab, setSetupTab] = useState<SetupTab>("solo");
  const [selectedMap, setSelectedMap] = useState<MapId>("europe");
  const [difficulty, setDifficulty] = useState<Difficulty>("normal");
  const [botCount, setBotCount] = useState(38);
  const [name, setName] = useState(() => localStorage.getItem("front-name") || "Anadolu Beyliği");
  const [color, setColor] = useState(PLAYER_COLORS[0]);
  const [settings, setSettings] = useState<SettingsState>(loadSettings);
  const [scores, setScores] = useState<Score[]>(loadScores);
  const [game, setGame] = useState<GameState | null>(null);
  const [snapshot, setSnapshot] = useState<GameSnapshot | null>(null);
  const [paused, setPaused] = useState(false);
  const [speed, setSpeed] = useState(1);
  const [tool, setTool] = useState<Tool>("march");
  const [placingBuilding, setPlacingBuilding] = useState<BuildingType | null>(null);
  const [buildPickerMode, setBuildPickerMode] = useState(false);
  const [hoverCell, setHoverCell] = useState<number | null>(null);
  const [terrainOnly, setTerrainOnly] = useState(false);
  const [context, setContext] = useState<{ index: number; x: number; y: number; promptWar?: number } | null>(null);
  const [toast, setToast] = useState<{ text: string; key: number } | null>(null);
  const [focusSignal, setFocusSignal] = useState(0);
  const [zoomCommand, setZoomCommand] = useState({ key: 0, factor: 1 });
  const [leaderboardOpen, setLeaderboardOpen] = useState(false);
  const [diplomacyOpen, setDiplomacyOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const scoreSaved = useRef(false);
  const [warFlashKey, setWarFlashKey] = useState(0);
  const seenWarNoticeIds = useRef<Set<number>>(new Set());

  useEffect(() => {
    localStorage.setItem("front-settings", JSON.stringify(settings));
  }, [settings]);


  useEffect(() => {
    if (!snapshot) return;
    for (const notice of snapshot.notifications) {
      if (notice.kind === "war" && !seenWarNoticeIds.current.has(notice.id)) {
        seenWarNoticeIds.current.add(notice.id);
        setWarFlashKey(Date.now() + Math.random());
      }
    }
  }, [snapshot]);

  useEffect(() => {
    if (!toast) return;
    const timeout = window.setTimeout(() => setToast(null), 3200);
    return () => clearTimeout(timeout);
  }, [toast]);

  useEffect(() => {
    if (screen !== "game" || !game || paused || overlay || game.phase !== "playing") return;
    const interval = window.setInterval(() => {
      tickGame(game);
      setSnapshot(getSnapshot(game));
    }, (STEP_SECONDS * 1000) / speed);
    return () => clearInterval(interval);
  }, [screen, game, paused, overlay, speed, snapshot?.phase]);

  useEffect(() => {
    if (snapshot?.phase !== "won" || !game || scoreSaved.current) return;
    scoreSaved.current = true;
    const updated = [
      {
        name: game.factions[0].name,
        map: MAPS[game.map.id].name,
        percent: Math.round(snapshot.percent),
        time: snapshot.tick,
        date: new Date().toLocaleDateString("tr-TR"),
      },
      ...scores,
    ]
      .sort((a, b) => b.percent - a.percent || a.time - b.time)
      .slice(0, 10);
    setScores(updated);
    localStorage.setItem("front-scores", JSON.stringify(updated));
  }, [snapshot?.phase, game, scores]);

  const notify = (text: string) => setToast({ text, key: Date.now() + Math.random() });

  const playSound = (frequency = 480) => {
    if (!settings.sound) return;
    try {
      const audio = new window.AudioContext();
      const oscillator = audio.createOscillator();
      const gain = audio.createGain();
      oscillator.type = "sine";
      oscillator.frequency.setValueAtTime(frequency, audio.currentTime);
      oscillator.frequency.exponentialRampToValueAtTime(frequency * 0.72, audio.currentTime + 0.12);
      gain.gain.setValueAtTime(0.045, audio.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audio.currentTime + 0.14);
      oscillator.connect(gain).connect(audio.destination);
      oscillator.start();
      oscillator.stop(audio.currentTime + 0.15);
      oscillator.onended = () => {
        void audio.close();
      };
    } catch {
      // Optional audio feedback
    }
  };

  const startNewGame = () => {
    const next = createGame(getTerrainMap(selectedMap), name, color, difficulty);
    next.attackRatio = settings.defaultRatio;
    next.autoExpand = settings.autoExpand;
    localStorage.setItem("front-name", name.trim() || "Anadolu Beyliği");
    setGame(next);
    setSnapshot(getSnapshot(next));
    setScreen("game");
    setOverlay(null);
    setPaused(false);
    setTool("march");
    setPlacingBuilding(null);
    setContext(null);
    setSpeed(1);
    setLeaderboardOpen(false);
    setDiplomacyOpen(false);
    setTerrainOnly(false);
    scoreSaved.current = false;
    seenWarNoticeIds.current = new Set();
    setWarFlashKey(0);
  };

  const returnHome = () => {
    setScreen("home");
    setGame(null);
    setSnapshot(null);
    setPaused(false);
    setOverlay(null);
    setContext(null);
    setPlacingBuilding(null);
    setToast(null);
  };

  const refresh = () => {
    if (game) setSnapshot(getSnapshot(game));
  };

  const handleRecruit = (buildingIndex?: number) => {
    if (!game || game.phase !== "playing") return;
    const error = recruitTroops(game, PLAYER_ID, buildingIndex);
    if (error) notify(error);
    else {
      playSound(560);
      notify(game.lastEvent);
    }
    refresh();
  };

  const handleCellClick = (index: number, x: number, y: number) => {
    if (!game) return;
    setContext(null);

    if (game.phase === "spawn") {
      if (spawnPlayer(game, index, botCount)) {
        playSound(620);
        notify("Başkent Kalen kuruldu! Haritaya tıklayarak komutanını yürüt.");
        setFocusSignal((value) => value + 1);
        refresh();
      }
      return;
    }
    if (game.phase !== "playing") return;

    // If user selected a building to place on their own territory
    if (placingBuilding) {
      const error = buildStructure(game, index, placingBuilding);
      if (error) {
        notify(error);
      } else {
        playSound(720);
        notify(game.lastEvent);
        setPlacingBuilding(null);
      }
      refresh();
      return;
    }

    if (tool === "bombard") {
      const error = bombardTarget(game, index);
      if (error) notify(error);
      else {
        playSound(210);
        setTool("march");
        notify(game.lastEvent);
      }
      refresh();
      return;
    }

    if (tool === "boat") {
      const error = sendBoat(game, index);
      if (error) notify(error);
      else {
        playSound(380);
        setTool("march");
        notify(game.lastEvent);
      }
      refresh();
      return;
    }

    game.selected = index;

    // Default left-click: March Commander to this destination!
    const result = commandMove(game, PLAYER_ID, index);
    if (result.startsWith("NEED_WAR:")) {
      const targetId = Number(result.split(":")[1]);
      setContext({ index, x, y, promptWar: targetId });
    } else if (result) {
      notify(result);
    } else {
      playSound(520);
    }
    refresh();
  };

  const handleContext = (index: number, x: number, y: number) => {
    if (!game || game.phase !== "playing") return;
    setPlacingBuilding(null);
    setBuildPickerMode(false);
    game.selected = index;
    setContext({ index, x, y });
    refresh();
  };

  const openBuildMenu = () => {
    if (!game) return;
    setPlacingBuilding(null);
    let index =
      game.selected !== null && game.owners[game.selected] === PLAYER_ID && !game.buildings.has(game.selected)
        ? game.selected
        : undefined;
    if (index === undefined) {
      for (const tile of game.factions[0].tiles) {
        if (!game.buildings.has(tile)) {
          index = tile;
          break;
        }
      }
    }
    if (index === undefined) {
      index = game.factions[0].tiles.values().next().value;
    }
    if (index === undefined) return;
    game.selected = index;
    setBuildPickerMode(false);
    setContext({
      index,
      x: window.innerWidth < 700 ? 16 : 345,
      y: window.innerHeight - 485,
    });
    refresh();
  };

  const togglePlacing = (type: BuildingType) => {
    if (!game || game.phase !== "playing") return;
    setContext(null);
    setBuildPickerMode(false);
    setTool("march");
    setPlacingBuilding((current) => (current === type ? null : type));
  };

  const setAutoExpansion = (value: boolean) => {
    setSettings((current) => ({ ...current, autoExpand: value }));
    if (game) {
      setAutoExpand(game, value);
      refresh();
    }
    notify(value ? "Otomatik genişleme açık." : "Otomatik genişleme kapalı.");
  };

  const changeRatio = (value: number) => {
    if (!game) return;
    const clamped = Math.max(10, Math.min(100, value));
    game.attackRatio = clamped;
    game.factions[0].mobilizationRatio = clamped;
    refresh();
  };

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.target instanceof HTMLInputElement || event.target instanceof HTMLTextAreaElement) return;
      const key = event.key.toLowerCase();
      if (key === "escape") {
        if (placingBuilding) setPlacingBuilding(null);
        else if (overlay) setOverlay(null);
        else if (context) setContext(null);
        else if (screen === "game" && game?.phase === "playing") setPaused((value) => !value);
        return;
      }
      if (screen !== "game" || !game || overlay) return;
      if (key === "p") {
        setPaused((value) => !value);
        return;
      }
      if (paused || game.phase !== "playing") return;
      if (key === "[") changeRatio(game.attackRatio - 5);
      if (key === "]") changeRatio(game.attackRatio + 5);
      if (/^[1-5]$/.test(key)) togglePlacing(BUILD_ORDER[Number(key) - 1]);
      if (key === "r") handleRecruit();
      if (key === "b") openBuildMenu();
      if (key === "c") setFocusSignal((value) => value + 1);
      if (event.code === "Space") {
        event.preventDefault();
        setTerrainOnly((value) => !value);
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [screen, game, overlay, context, paused, placingBuilding]);

  const openOverlay = (target: Overlay) => {
    setMobileMenuOpen(false);
    setOverlay(target);
    if (screen === "game") setPaused(true);
  };

  const placementInfo =
    placingBuilding && game
      ? {
          type: placingBuilding as string,
          spacing: (index: number) =>
            buildingSpacing(placingBuilding, game.owners[index] === 0),
          label: BUILDINGS[placingBuilding].name,
          check: (index: number) => getBuildingPlacementError(game, index, placingBuilding, PLAYER_ID),
        }
      : null;
  const hoverOwner = hoverCell !== null && game ? game.owners[hoverCell] : 0;
  const hoverFaction = hoverOwner > 0 && game ? game.factions[hoverOwner - 1] : null;
  const hoverBuilding = hoverCell !== null && game ? game.buildings.get(hoverCell) || null : null;
  const hoverRelation =
    hoverOwner > 1 && snapshot ? snapshot.factions.find((f) => f.id === hoverOwner)?.relation || "peace" : "peace";
  const selectedOwner = context && game ? game.owners[context.index] : 0;
  const selectedFaction = selectedOwner > 0 && game ? game.factions[selectedOwner - 1] : null;
  const selectedBuilding = context && game ? game.buildings.get(context.index) || null : null;
  const selectedRelation =
    selectedOwner > 1 && snapshot
      ? snapshot.factions.find((f) => f.id === selectedOwner)?.relation || "peace"
      : "peace";

  const contextStyle = context
    ? {
        left: Math.max(12, Math.min(context.x + 14, window.innerWidth - 320)),
        top: Math.max(76, Math.min(context.y + 10, window.innerHeight - 465)),
      }
    : undefined;

  const stanceLabel = (stance: GameSnapshot["commanderStance"]) => {
    if (stance === "battle") return "Meydan Savaşı";
    if (stance === "siege") return "Kale Kuşatması";
    if (stance === "march") return "Sefer Halinde";
    if (stance === "retreat") return "Bozgun / Çekilme";
    if (stance === "embarked") return "Denizde / Çıkarma";
    return "Mevzide Hazır";
  };

  return (
    <div className="app-shell">
      {screen === "home" && (
        <div className="home-screen">
          <div className="home-map-plane">
            <GameCanvas game={previewGame} preview />
          </div>
          <div className="home-map-shade" />
          <div className="home-vignette" />

          <header className="home-header">
            <button className="home-header-brand" onClick={() => setOverlay(null)} aria-label="Ana sayfa">
              <Brand compact />
            </button>
            <nav className="home-nav" aria-label="Ana menü">
              <button className="home-nav-active" onClick={() => openOverlay("setup")}>
                OYNA
              </button>
              <button onClick={() => openOverlay("guide")}>NASIL OYNANIR</button>
              <button onClick={() => openOverlay("scores")}>SKORLAR</button>
              <button onClick={() => openOverlay("settings")}>AYARLAR</button>
            </nav>
            <a className="header-source" href="https://github.com/openfrontio/OpenFrontIO" target="_blank" rel="noreferrer">
              AÇIK KAYNAK <ArrowUpRight size={16} />
            </a>
            <button
              className="mobile-menu-button icon-button"
              onClick={() => setMobileMenuOpen((value) => !value)}
              aria-label="Menüyü aç"
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </header>

          {mobileMenuOpen && (
            <div className="mobile-nav">
              <button onClick={() => openOverlay("setup")}>Oyna</button>
              <button onClick={() => openOverlay("guide")}>Nasıl oynanır</button>
              <button onClick={() => openOverlay("scores")}>Skorlar</button>
              <button onClick={() => openOverlay("settings")}>Ayarlar</button>
            </div>
          )}

          <main className="home-hero">
            <motion.div
              className="hero-inner"
              initial="hidden"
              animate="show"
              variants={{
                hidden: {},
                show: { transition: { staggerChildren: 0.03, delayChildren: 0 } },
              }}
            >
              <motion.div
                className="hero-kicker"
                variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.25 } } }}
              >
                <span /> ORTAÇAĞ STRATEJİ &amp; KUŞATMA
              </motion.div>
              <motion.div
                className="hero-brand"
                variants={{ hidden: { opacity: 0, y: 16 }, show: { opacity: 1, y: 0, transition: { duration: 0.28 } } }}
              >
                <BrandMark className="hero-emblem" />
                <h1>
                  OPEN<span>FRONT</span>
                </h1>
              </motion.div>
              <motion.h2 variants={{ hidden: { opacity: 0, y: 12 }, show: { opacity: 1, y: 0, transition: { duration: 0.25 } } }}>
                Ordunu topla. Kaleleri kuşat.
              </motion.h2>
              <motion.p variants={{ hidden: { opacity: 0, y: 12 }, show: { opacity: 1, y: 0, transition: { duration: 0.25 } } }}>
                Avrupa haritasında sancağını dik. Kışlalarda asker yetiştir, meydan savaşlarını kazan, düşman ordusunu arkadanla ve taş kaleleri düşür.
              </motion.p>
              <motion.div
                className="hero-actions"
                variants={{ hidden: { opacity: 0, y: 12 }, show: { opacity: 1, y: 0, transition: { duration: 0.24 } } }}
              >
                <button className="button-primary hero-play" onClick={() => openOverlay("setup")}>
                  SEFERE ÇIK <ArrowRight size={21} strokeWidth={2.5} />
                </button>
                <button className="button-text hero-guide" onClick={() => openOverlay("guide")}>
                  NASIL OYNANIR <ChevronRight size={19} />
                </button>
              </motion.div>
            </motion.div>
          </main>

          <footer className="home-footer">
            <span>ORTAÇAĞ KRALLIKLARI · MEYDAN SAVAŞI &amp; KALE KUŞATMASI</span>
            <span>HARİTAYI SEÇ. SURLARI AŞ.</span>
          </footer>
        </div>
      )}

      {screen === "game" && game && snapshot && (
        <div className="game-screen">
          {warFlashKey > 0 && <div className="war-flash" key={warFlashKey} aria-hidden="true" />}
          <GameCanvas
            game={game}
            disabled={paused || !!overlay || game.phase === "won" || game.phase === "lost"}
            showNames={settings.showNames}
            showGrid={settings.showGrid}
            terrainOnly={terrainOnly}
            focusSignal={focusSignal}
            zoomCommand={zoomCommand}
            onCellClick={handleCellClick}
            onContext={handleContext}
            onHover={setHoverCell}
            placement={placementInfo}
          />

          <header className="game-header">
            <div className="game-header-left">
              <button className="game-brand" onClick={() => setPaused(true)} title="Oyun menüsü">
                <Brand compact />
              </button>
              <span className="header-separator" />
              <div className="match-label">
                <span>FEODAL SEFER</span>
                <strong>{MAPS[game.map.id].name}</strong>
              </div>
            </div>
            <div className="game-header-controls">
              <span className="game-clock">{formatTime(snapshot.tick)}</span>
              <button
                onClick={() => setSpeed((value) => (value >= 2 ? 1 : value === 1 ? 1.5 : 2))}
                title="Oyun hızı"
                aria-label={`Oyun hızı ${speed}x`}
                className="header-control speed-control"
              >
                {speed}x <ChevronRight size={13} />
              </button>
              <button
                onClick={() => setPaused((value) => !value)}
                title={paused ? "Devam et" : "Duraklat"}
                aria-label={paused ? "Devam et" : "Duraklat"}
                className="header-control"
              >
                {paused ? <Play size={18} fill="currentColor" /> : <Pause size={18} fill="currentColor" />}
              </button>
              <button
                onClick={() => {
                  setDiplomacyOpen((value) => !value);
                  setLeaderboardOpen(false);
                }}
                title="Diplomasi & Savaşlar"
                aria-label="Diplomasi"
                className={`header-control diplomacy-toggle ${diplomacyOpen ? "header-control--active" : ""}`}
              >
                <ScrollText size={18} />
                {(snapshot.activeWarsCount > 0 || snapshot.notifications.length > 0) && (
                  <span className="header-badge">
                    {snapshot.notifications.length || snapshot.activeWarsCount}
                  </span>
                )}
              </button>
              <button
                onClick={() => {
                  setLeaderboardOpen((value) => !value);
                  setDiplomacyOpen(false);
                }}
                title="Krallıklar Sıralaması"
                aria-label="Sıralama"
                className={`header-control ${leaderboardOpen ? "header-control--active" : ""}`}
              >
                <BarChart3 size={18} />
              </button>
              <button
                onClick={() => openOverlay("settings")}
                title="Ayarlar"
                aria-label="Ayarlar"
                className="header-control"
              >
                <Settings2 size={18} />
              </button>
              <button onClick={() => setPaused(true)} title="Oyun menüsü" aria-label="Oyun menüsü" className="header-control">
                <Menu size={19} />
              </button>
            </div>
          </header>

          {game.phase === "spawn" && (
            <motion.div className="spawn-prompt" initial={{ opacity: 0, y: -12 }} animate={{ opacity: 1, y: 0 }}>
              <div className="spawn-prompt-icon">
                <Castle size={24} />
              </div>
              <div>
                <strong>Başkent kaleni kur</strong>
                <span>Haritada bir kara bölgesine tıkla, krallığını ve komutanını sahaya indir.</span>
              </div>
            </motion.div>
          )}

          {hoverCell !== null &&
            hoverOwner > 1 &&
            game.phase === "playing" &&
            !context &&
            !placingBuilding &&
            !paused &&
            !overlay &&
            hoverFaction && (
              <div className="hover-card">
                <div className="hover-head">
                  <span className="leaderboard-color" style={{ backgroundColor: hoverFaction.color }} />
                  <strong>{hoverFaction.name}</strong>
                  <span className="hover-tag">
                    {hoverOwner === PLAYER_ID
                      ? "Sen"
                      : hoverFaction.botKind === "major"
                        ? "Büyük Devlet"
                        : "Beylik"}
                  </span>
                  {hoverOwner !== PLAYER_ID && (
                    <span className={`rel-badge rel-badge--${hoverRelation}`}>{RELATION_LABEL[hoverRelation]}</span>
                  )}
                </div>
                <div className="hover-stats">
                  <span className="cb-chip cb-chip--gold">
                    <span className="gold-diamond" /> {formatNumber(hoverFaction.gold)}
                  </span>
                  <span className="hover-troops">
                    <span
                      className="fill"
                      style={{ width: `${Math.min(100, (getTotalTroops(hoverFaction) / getCapacity(hoverFaction)) * 100)}%` }}
                    />
                    <b>
                      {formatNumber(hoverFaction.commander.army)} saha · {formatNumber(getTotalTroops(hoverFaction))} /{" "}
                      {formatNumber(getCapacity(hoverFaction))}
                    </b>
                  </span>
                </div>
                <div className="hover-buildings">
                  {BUILD_ORDER.map((type) => {
                    const Icon = BUILDING_ICONS[type];
                    return (
                      <span key={type} title={BUILDINGS[type].name}>
                        <Icon size={12} />
                        {hoverFaction.buildingLevels[type]}
                      </span>
                    );
                  })}
                </div>
                {hoverBuilding && (
                  <div className="hover-note">
                    <strong>
                      {BUILDINGS[hoverBuilding.type].name} Sv.{hoverBuilding.level}
                    </strong>{" "}
                    ·{" "}
                    {hoverBuilding.type === "castle"
                      ? `Sur ${Math.floor(hoverBuilding.wallHp)} / ${hoverBuilding.maxWallHp}`
                      : hoverBuilding.type === "barracks"
                        ? `Garnizon ${formatNumber(hoverBuilding.garrison || 0)}`
                        : BUILDING_DETAILS[hoverBuilding.type].details[0]}
                  </div>
                )}
              </div>
            )}

          {/* Active Building Placement Banner */}
          {placingBuilding && game.phase === "playing" && (
            <div className="placing-banner">
              <Hammer size={16} />
              <span>
                <strong>{BUILDINGS[placingBuilding].name}</strong> kurmak için kendi toprağına tıkla
              </span>
              <button onClick={() => setPlacingBuilding(null)}>İptal</button>
            </div>
          )}

          {/* Siege status: wall health + defending/attacking armies */}
          {game.phase === "playing" && snapshot.siegingInfo && (
            <div className="siege-panel">
              <div className="siege-head">
                <Castle size={15} />
                <strong>{snapshot.siegingInfo.ownerName} · Sv.{snapshot.siegingInfo.level}</strong>
                <span>KUŞATMA</span>
              </div>
              <div className="siege-row">
                <span>SUR</span>
                <div className="siege-bar">
                  <span
                    style={{
                      width: `${Math.min(
                        100,
                        (snapshot.siegingInfo.wallHp / Math.max(1, snapshot.siegingInfo.maxWallHp)) * 100,
                      )}%`,
                    }}
                  />
                </div>
                <strong>
                  {formatNumber(snapshot.siegingInfo.wallHp)} / {formatNumber(snapshot.siegingInfo.maxWallHp)}
                </strong>
              </div>
              <div className="siege-row">
                <span>Savunma</span>
                <strong>{formatNumber(snapshot.siegingInfo.defenderArmy)}</strong>
                <span>Ordu</span>
                <strong>{formatNumber(snapshot.siegingInfo.attackerArmy)}</strong>
              </div>
            </div>
          )}

          {game.phase !== "spawn" && (
            <>
              <div className="command-bar">
                <div className="cb-top">
                  <span className="cb-chip cb-chip--identity">
                    <span className="cb-flag" style={{ backgroundColor: game.factions[0].color }}>
                      <Flag size={11} fill="currentColor" />
                    </span>
                    <strong>{game.factions[0].name}</strong>
                    <em>%{snapshot.percent.toFixed(1)}</em>
                  </span>
                  <span className="cb-chip cb-chip--stance">
                    <span className={`stance-dot stance-dot--${snapshot.commanderStance}`} />
                    <span className="cb-ellipsis">
                      {snapshot.exhaustionRemaining > 0
                        ? `Toparlanma: ${snapshot.exhaustionRemaining}sn`
                        : snapshot.engagedEnemyName
                          ? `Meydan savaşı: ${snapshot.engagedEnemyName}`
                          : snapshot.siegingInfo
                            ? `Kuşatma Sv.${snapshot.siegingInfo.level}: ${snapshot.siegingInfo.wallHp}/${snapshot.siegingInfo.maxWallHp}`
                            : `Komutan: ${stanceLabel(snapshot.commanderStance)}`}
                    </span>
                  </span>
                  <button
                    className={`cb-chip cb-chip--auto ${snapshot.autoExpand ? "" : "cb-chip--auto-off"}`}
                    onClick={() => setAutoExpansion(!snapshot.autoExpand)}
                    aria-pressed={snapshot.autoExpand}
                    title="Komutan boş toprakları kendiliğinden alsın"
                  >
                    <Compass size={13} /> OTO {snapshot.autoExpand ? "AÇIK" : "KAPALI"}
                  </button>
                  {snapshot.battleDice && (
                    <span className="cb-chip cb-chip--dice" title="Her savaş tikinde iki taraf için 2 zar atılır">
                      ZAR {snapshot.battleDice.aDice[0]}+{snapshot.battleDice.aDice[1]}={snapshot.battleDice.totalA} :{" "}
                      {snapshot.battleDice.bDice[0]}+{snapshot.battleDice.bDice[1]}={snapshot.battleDice.totalB}
                    </span>
                  )}
                  <span
                    className="cb-chip cb-chip--trade tip-host"
                  >
                    <Anchor size={13} />
                    {snapshot.tradeRoutes} rota · {snapshot.tradeShips} gemi · {snapshot.caravans} kervan
                    <b>+{formatNumber(snapshot.tradeIncomePerMin)}/dk</b>
                    <span className="tip">
                      <strong>Deniz ticareti</strong>
                      <span>Portu olan herkesle otomatik ticaret; barış veya ittifak şartı yok.</span>
                      <span>Savaş yalnızca o krallıkla ticareti keser. Minik gemiler konvoy hâlinde az kargo taşır.</span>
                    </span>
                  </span>
                  <span className="cb-tools">
                    <button
                      className={`cb-tool ${tool === "march" && !placingBuilding ? "cb-tool--active" : ""}`}
                      onClick={() => {
                        setTool("march");
                        setPlacingBuilding(null);
                      }}
                      title="Komutan yürüyüşü (haritaya tıkla)"
                      aria-label="Komutan yürüyüşü"
                    >
                      <Crown size={16} />
                    </button>
                    <button
                      className={`cb-tool ${tool === "boat" ? "cb-tool--active" : ""}`}
                      disabled={!snapshot.buildings.port}
                      onClick={() => {
                        setPlacingBuilding(null);
                        setTool("boat");
                        notify("Kıyı seç; komutan limana gidip otomatik yola çıkacak.");
                      }}
                      title="Kıyı seç; komutan limana kendiliğinden gidip otomatik çıkarma yapar"
                      aria-label="Donanma çıkarması"
                    >
                      <Ship size={16} />
                    </button>
                    <button
                      className={`cb-tool ${tool === "bombard" ? "cb-tool--active" : ""}`}
                      disabled={!snapshot.buildings.siegeworks}
                      onClick={() => {
                        setPlacingBuilding(null);
                        setTool("bombard");
                        notify("Mancınık bombardımanı için düşman kalesi seç.");
                      }}
                      title="Mancınık bombardımanı (kuşatma atölyesi gerekli)"
                      aria-label="Mancınık bombardımanı"
                    >
                      <Flame size={16} />
                    </button>
                  </span>
                </div>

                <div className="cb-main">
                  <div className="cb-chip cb-chip--green tip-host">
                    <UserPlus size={14} />
                    {snapshot.trainingOrders.length
                      ? `+${formatNumber(snapshot.queuedTroops)} · ${Math.ceil(snapshot.trainingOrders[0].remainingTicks * STEP_SECONDS)}sn`
                      : "Eğitim yok"}
                    <span className="tip">
                      <strong>Asker kaynağı</strong>
                      <span>Asker havadan gelmez. Kışlada zamanla eğitilir ve o kışlanın garnizonuna katılır.</span>
                      <span className="tip-row">
                        <em>Garnizon</em>
                        <b>{formatNumber(snapshot.reserveTroops)}</b>
                      </span>
                      <span className="tip-row">
                        <em>Komutanın ordusu</em>
                        <b>{formatNumber(snapshot.fieldArmy)}</b>
                      </span>
                      <span className="tip-row">
                        <em>Eğitimde</em>
                        <b>{formatNumber(snapshot.queuedTroops)}</b>
                      </span>
                    </span>
                  </div>

                  <div className="cb-troopbar tip-host">
                    <span className="cb-seg-clip">
                      <span className="seg seg--field" style={{ left: 0, width: `${Math.min(100, (snapshot.fieldArmy / snapshot.capacity) * 100)}%` }} />
                      <span
                        className="seg seg--garrison"
                        style={{
                          left: `${Math.min(100, (snapshot.fieldArmy / snapshot.capacity) * 100)}%`,
                          width: `${Math.min(100, (snapshot.reserveTroops / snapshot.capacity) * 100)}%`,
                        }}
                      />
                      <span
                        className="seg seg--queue"
                        style={{
                          left: `${Math.min(100, (snapshot.totalTroops / snapshot.capacity) * 100)}%`,
                          width: `${Math.min(100, (snapshot.queuedTroops / snapshot.capacity) * 100)}%`,
                        }}
                      />
                    </span>
                    <strong>
                      {formatNumber(snapshot.totalTroops)} / {formatNumber(snapshot.capacity)}
                    </strong>
                    <Swords size={16} />
                    <span className="tip">
                      <strong>Asker kapasitesi</strong>
                      {snapshot.capacityBreakdown.map((row) => (
                        <span className="tip-row" key={row.label}>
                          <em>{row.label}</em>
                          <b>+{formatNumber(row.value)}</b>
                        </span>
                      ))}
                      <span>Mavi: komutanın ordusu · Açık mavi: garnizon · Çizgili: eğitimde</span>
                    </span>
                  </div>

                  <div className="cb-chip cb-chip--gold tip-host">
                    <span className="gold-diamond" />
                    {formatNumber(snapshot.gold)}
                    <small>
                      {snapshot.goldRatePerSec >= 0 ? "+" : ""}
                      {snapshot.goldRatePerSec.toFixed(1)}/sn
                    </small>
                    <span className="tip">
                      <strong>Altın geliri (saniye)</strong>
                      {snapshot.economy.map((row) => (
                        <span className="tip-row" key={row.label}>
                          <em>{row.label}</em>
                          <b>
                            {row.perSec >= 0 ? "+" : "−"}
                            {Math.abs(row.perSec).toFixed(1)}
                          </b>
                        </span>
                      ))}
                      <span>Ticaret gelirleri bunun dışındadır; gemi limana dönünce toplu gelir.</span>
                    </span>
                  </div>
                </div>

                {(snapshot.commanderStance === "siege" || snapshot.commanderStance === "retreat") && (
                  <button
                    className="cb-chip cb-chip--retreat"
                    onClick={() => {
                      const err = retreatFromSiege(game);
                      notify(err || game.lastEvent);
                      refresh();
                    }}
                  >
                    <Shield size={12} /> {snapshot.commanderStance === "siege" ? "KUŞATMAYI KALDIR" : "ORDUYU GERİ ÇEK"}
                  </button>
                )}
                <div className="cb-ratio">
                  <span className="cb-chip cb-chip--ratio" title="Komutanın yanında sefere çıkacak ordu payı">
                    <Swords size={12} /> %{snapshot.attackRatio} ({formatNumber(Math.round((snapshot.totalTroops * snapshot.attackRatio) / 100))})
                  </span>
                  <button className="cb-step" onClick={() => changeRatio(snapshot.attackRatio - 5)} aria-label="Sefer oranını azalt">
                    <Minus size={14} />
                  </button>
                  <input
                    type="range"
                    min="10"
                    max="100"
                    step="5"
                    value={snapshot.attackRatio}
                    onChange={(event) => changeRatio(Number(event.target.value))}
                    aria-label="Komutan sefer oranı"
                  />
                  <button className="cb-step" onClick={() => changeRatio(snapshot.attackRatio + 5)} aria-label="Sefer oranını artır">
                    <Plus size={14} />
                  </button>
                  <button
                    className={`cb-chip cb-chip--auto ${game.factions[0].commander.autoSiege ? "" : "cb-chip--auto-off"}`}
                    onClick={() => {
                      setAutoSiege(game, !game.factions[0].commander.autoSiege);
                      notify(game.factions[0].commander.autoSiege ? "Otomatik kuşatma açık." : "Otomatik kuşatma kapalı.");
                      refresh();
                    }}
                    title="Kale yanından geçerken otomatik kuşatmaya girilsin mi"
                  >
                    <Castle size={12} /> KUŞATMA {game.factions[0].commander.autoSiege ? "OTO" : "MANUEL"}
                  </button>
                  <button
                    className="cb-chip cb-chip--siege"
                    disabled={snapshot.siegeWeapons >= 6 || snapshot.gold < 850 + snapshot.siegeWeapons * 150}
                    onClick={() => {
                      const err = buySiegeWeapon(game);
                      notify(err || game.lastEvent);
                      refresh();
                    }}
                    title="Mancınık orduyla taşınır: kuşatmada sur hasarını artırır, bombardıman açar"
                  >
                    <Flame size={12} /> MANCINIK {snapshot.siegeWeapons}
                  </button>
                  <button
                    className="recruit-button cb-recruit"
                    disabled={
                      !snapshot.buildings.barracks ||
                      snapshot.gold < snapshot.recruitCost ||
                      snapshot.totalTroops + snapshot.queuedTroops >= snapshot.capacity - 50
                    }
                    onClick={() => handleRecruit()}
                    title="Komutana en yakın kışlada piyade eğit (R)"
                  >
                    <UserPlus size={14} /> PİYADE EĞİT +{formatNumber(snapshot.recruitAmount)} · {Math.ceil(snapshot.recruitTicks * STEP_SECONDS)}sn
                    <span>{snapshot.recruitCost} ◆</span>
                  </button>
                </div>

                <div className="build-bar">
                  {BUILD_ORDER.map((type, i) => {
                    const Icon = BUILDING_ICONS[type];
                    const info = BUILDINGS[type];
                    const nextCost = getBuildingCost(type, snapshot.buildings[type]);
                    const poor = snapshot.gold < nextCost;
                    const totalLevel = snapshot.buildingLevels[type];
                    return (
                      <button
                        key={type}
                        className={`build-slot tip-host ${placingBuilding === type ? "build-slot--active" : ""} ${poor ? "build-slot--poor" : ""}`}
                        onClick={() => togglePlacing(type)}
                        aria-label={`${info.name} kur`}
                      >
                        <span className="bs-key">{i + 1}</span>
                        <Icon size={22} />
                        <span className="bs-text">
                          <strong>{BUILDING_DETAILS[type].short}</strong>
                          <small>{formatNumber(nextCost)} ◆</small>
                        </span>
                        <span className="bs-count">{totalLevel}</span>
                        <span className="tip">
                          <strong>
                            {info.name} · {formatNumber(nextCost)} ◆ (sıradaki)
                          </strong>
                          {BUILDING_DETAILS[type].details.map((line) => (
                            <span key={line}>• {line}</span>
                          ))}
                          <span className="tip-hint">
                            {poor
                              ? "Yeterli altının yok."
                              : `Toplam seviye ${totalLevel}. Aynı yapıya tekrar bas: seviye yükselt.`}
                          </span>
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="game-lower-right">
                <div className="zoom-controls">
                  <button
                    onClick={() => setZoomCommand({ key: Date.now(), factor: 1.28 })}
                    aria-label="Yakınlaştır"
                    title="Yakınlaştır"
                  >
                    <ZoomIn size={18} />
                  </button>
                  <button
                    onClick={() => setZoomCommand({ key: Date.now(), factor: 0.78 })}
                    aria-label="Uzaklaştır"
                    title="Uzaklaştır"
                  >
                    <ZoomOut size={18} />
                  </button>
                  <button
                    onClick={() => setFocusSignal((value) => value + 1)}
                    aria-label="Komutana odaklan"
                    title="Komutana odaklan (C)"
                  >
                    <Compass size={18} />
                  </button>
                </div>
                <MiniMap game={game} revision={game.revision} onClick={() => setFocusSignal((value) => value + 1)} />
              </div>

              {snapshot.notifications.length > 0 && (
                <div className="notification-stack" aria-label="Olay bildirimleri">
                  {snapshot.notifications.slice(0, 2).map((item) => (
                    <div className={`notification-card notification-card--${item.kind}`} key={item.id}>
                      <span
                        className="notification-dot"
                        style={{ backgroundColor: item.fromColor || "#7ce5f2" }}
                      />
                      <div className="notification-copy">
                        <strong>{item.title}</strong>
                        <span>{item.message}</span>
                        {item.fromName && <em>{item.fromName}</em>}
                      </div>
                      <div className="notification-actions">
                        {item.actionable ? (
                          <>
                            <button
                              className="notification-accept"
                              onClick={() => {
                                respondToNotification(game, item.id, "accept");
                                playSound(640);
                                refresh();
                              }}
                            >
                              Kabul
                            </button>
                            <button
                              className="notification-reject"
                              onClick={() => {
                                respondToNotification(game, item.id, "reject");
                                refresh();
                              }}
                            >
                              Reddet
                            </button>
                          </>
                        ) : (
                          <button
                            className="notification-ok"
                            onClick={() => {
                              dismissNotification(game, item.id);
                              refresh();
                            }}
                          >
                            Tamam
                          </button>
                        )}
                        <button
                          className="notification-dismiss"
                          onClick={() => {
                            dismissNotification(game, item.id);
                            refresh();
                          }}
                          aria-label="Bildirimi yoksay"
                        >
                          Yoksay
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {snapshot.tick < 48 && !paused && !context && !placingBuilding && (
                <div className="control-hint">
                  <span>
                    Sol tık <b>komutanı yürüt</b>
                  </span>
                  <i />
                  <span>
                    Sağ tık <b>kale / yapı / diplomasi</b>
                  </span>
                  <i />
                  <span>
                    1-5 <b>yapı kur</b>
                  </span>
                </div>
              )}
            </>
          )}

          {/* Diplomacy Drawer */}
          {diplomacyOpen && game.phase !== "spawn" && (
            <motion.div className="diplomacy-panel" initial={{ opacity: 0, x: 15 }} animate={{ opacity: 1, x: 0 }}>
              <div className="leaderboard-heading">
                <span>DİPLOMASİ &amp; KRALLIKLAR</span>
                <button onClick={() => setDiplomacyOpen(false)} aria-label="Diplomasiyi kapat">
                  <X size={15} />
                </button>
              </div>
              <div className="diplomacy-list">
                {snapshot.factions
                  .filter((f) => f.id !== PLAYER_ID)
                  .map((faction) => (
                    <div className="diplomacy-row" key={faction.id}>
                      <div className="diplomacy-row-top">
                        <span className="leaderboard-color" style={{ backgroundColor: faction.color }} />
                        <strong className="diplomacy-name">
                          {faction.name}
                          {faction.botKind === "major" ? " ★" : ""}
                        </strong>
                        <span className={`rel-badge rel-badge--${faction.relation}`}>
                          {RELATION_LABEL[faction.relation]}
                          {faction.relation === "truce" && faction.truceRemaining > 0 ? ` ${faction.truceRemaining}s` : ""}
                        </span>
                      </div>
                      <div className="diplomacy-stats">
                        <span>Asker: {formatNumber(faction.totalTroops)}</span>
                        <span>Kale: {faction.castles}</span>
                        <span>Toprak: %{faction.percent.toFixed(1)}</span>
                      </div>
                      <div className="diplomacy-actions">
                        {faction.relation === "war" ? (
                          <button
                            onClick={() => {
                              const err = proposePeace(game, PLAYER_ID, faction.id);
                              notify(err || game.lastEvent);
                              refresh();
                            }}
                          >
                            <Handshake size={13} /> Barış Teklif Et
                          </button>
                        ) : (
                          <>
                            <button
                              className="dip-war"
                              disabled={faction.relation === "truce"}
                              onClick={() => {
                                const err = declareWar(game, PLAYER_ID, faction.id);
                                notify(err || game.lastEvent);
                                refresh();
                              }}
                            >
                              <Swords size={13} /> Savaş Aç
                            </button>
                            <button
                              onClick={() => {
                                notify(toggleAlliance(game, faction.id));
                                refresh();
                              }}
                            >
                              <Users size={13} /> {faction.relation === "alliance" ? "İttifakı Boz" : "İttifak"}
                            </button>
                            {faction.relation === "peace" && (
                              <button
                                onClick={() => {
                                  notify(signTruce(game, faction.id));
                                  refresh();
                                }}
                              >
                                <Shield size={13} /> Ateşkes
                              </button>
                            )}
                          </>
                        )}
                      </div>
                    </div>
                  ))}
              </div>
            </motion.div>
          )}

          {/* Leaderboard Panel */}
          {leaderboardOpen && game.phase !== "spawn" && (
            <motion.div className="leaderboard-panel" initial={{ opacity: 0, x: 15 }} animate={{ opacity: 1, x: 0 }}>
              <div className="leaderboard-heading">
                <span>SIRALAMA</span>
                <button onClick={() => setLeaderboardOpen(false)} aria-label="Sıralamayı kapat">
                  <X size={15} />
                </button>
              </div>
              {snapshot.factions.slice(0, 9).map((faction, index) => (
                <div
                  className={`leaderboard-row ${faction.id === PLAYER_ID ? "leaderboard-row--me" : ""}`}
                  key={faction.id}
                >
                  <span className="leaderboard-place">{String(index + 1).padStart(2, "0")}</span>
                  <span className="leaderboard-color" style={{ backgroundColor: faction.color }} />
                  <span className="leaderboard-name">
                    {faction.name}
                    {faction.id !== PLAYER_ID && faction.relation === "war" && <em className="war-tag">⚔</em>}
                  </span>
                  <strong>%{faction.percent.toFixed(1)}</strong>
                </div>
              ))}
            </motion.div>
          )}

          {/* Right-Click / War-Prompt Context Menu */}
          {context && game.phase === "playing" && !paused && !overlay && (
            <div className="context-menu" style={contextStyle}>
              <div className="context-heading">
                <div>
                  <span>
                    {selectedOwner === PLAYER_ID
                      ? "SENİN TOPRAĞIN"
                      : selectedFaction
                        ? `${RELATION_LABEL[selectedRelation].toUpperCase()} · ${selectedFaction.buildings.castle} KALE`
                        : "SAHİPSİZ TOPRAK"}
                  </span>
                  <strong>{selectedFaction?.name || "Boş Arazi"}</strong>
                </div>
                <button onClick={() => setContext(null)} aria-label="Menüyü kapat">
                  <X size={17} />
                </button>
              </div>

              {selectedBuilding && selectedBuilding.type === "castle" && (
                <div className="castle-inspect">
                  <div className="castle-inspect-head">
                    <Castle size={15} />
                    <strong>Sv.{selectedBuilding.level} {selectedBuilding.level >= 5 ? "Efsanevi Hisar" : selectedBuilding.level === 4 ? "Büyük Hisar" : selectedBuilding.level === 3 ? "Kale" : selectedBuilding.level === 2 ? "Taş Kale" : "Hisar"}</strong>
                    <span>
                      Sur: {Math.floor(selectedBuilding.wallHp)} / {selectedBuilding.maxWallHp}
                    </span>
                  </div>
                  <div className="castle-wall-bar">
                    <span
                      style={{
                        width: `${Math.min(100, (selectedBuilding.wallHp / Math.max(1, selectedBuilding.maxWallHp)) * 100)}%`,
                      }}
                    />
                  </div>
                </div>
              )}

              {selectedBuilding && selectedBuilding.type !== "castle" && (
                <div className="building-inspect">
                  <strong>{BUILDINGS[selectedBuilding.type].name}</strong>
                  <span>
                    {selectedBuilding.type === "barracks"
                      ? `Yerel garnizon: ${formatNumber(selectedBuilding.garrison || 0)} · Kapasite: ${formatNumber(selectedBuilding.level * 4800)}`
                      : selectedBuilding.type === "port"
                        ? `Sv.${selectedBuilding.level} · Otomatik konvoy ticareti ve çıkarma limanı`
                        : BUILDINGS[selectedBuilding.type].description}
                  </span>
                </div>
              )}

              {selectedOwner === PLAYER_ID ? (
                <>
                  {selectedBuilding && !buildPickerMode ? (
                    <div className="context-actions">
                      <button
                        onClick={() => {
                          const err = commandMove(game, PLAYER_ID, context.index);
                          if (err) notify(err);
                          refresh();
                          setContext(null);
                        }}
                      >
                        <Crown size={17} /> Komutanı Buraya Çağır <ArrowRight size={16} />
                      </button>

                      {upgradeCost(selectedBuilding) !== null && (
                        <button
                          disabled={snapshot.gold < (upgradeCost(selectedBuilding) || 0) || selectedBuilding.level >= MAX_STRUCTURE_LEVEL}
                          onClick={() => {
                            const err = upgradeBuilding(game, context.index);
                            if (err) notify(err);
                            else {
                              playSound(740);
                              notify(game.lastEvent);
                            }
                            refresh();
                            setContext(null);
                          }}
                        >
                          <ArrowUpCircle size={17} /> {BUILDINGS[selectedBuilding.type].name} Sv.{selectedBuilding.level} → Sv.{selectedBuilding.level + 1} ({formatNumber(upgradeCost(selectedBuilding) || 0)} ◆)
                          <ArrowRight size={16} />
                        </button>
                      )}

                      {selectedBuilding.type === "castle" && selectedBuilding.wallHp < selectedBuilding.maxWallHp && (
                        <button
                          disabled={snapshot.gold < repairCastleCost(selectedBuilding)}
                          onClick={() => {
                            const err = repairCastle(game, context.index);
                            if (err) notify(err);
                            else {
                              playSound(690);
                              notify(game.lastEvent);
                            }
                            refresh();
                            setContext(null);
                          }}
                        >
                          <Wrench size={17} /> Surları Onar ({formatNumber(repairCastleCost(selectedBuilding))} ◆)
                          <ArrowRight size={16} />
                        </button>
                      )}

                      {selectedBuilding.type === "barracks" && (
                        <button
                          disabled={
                            snapshot.gold < snapshot.recruitCost ||
                            snapshot.trainingOrders.filter((order) => order.buildingIndex === context.index).length >= selectedBuilding.level
                          }
                          onClick={() => {
                            handleRecruit(context.index);
                            setContext(null);
                          }}
                        >
                          <UserPlus size={17} /> Piyade Eğit (+{formatNumber(snapshot.recruitAmount)} · {Math.ceil(snapshot.recruitTicks * STEP_SECONDS)}sn)
                          <ArrowRight size={16} />
                        </button>
                      )}

                      {selectedBuilding.type === "port" && (
                        <button
                          onClick={() => {
                            setContext(null);
                            setTool("boat");
                            notify("Haritada hedeflediğin kıyı bölgesine tıkla; komutan limana gidip otomatik çıkarma yapacak.");
                          }}
                        >
                          <Ship size={17} /> Komutanla Kıyıya Çık <ArrowRight size={16} />
                        </button>
                      )}

                      <button onClick={() => setBuildPickerMode(true)}>
                        <Hammer size={17} /> Yeni Yapı Yerleştir (Haritada Seç)
                        <ArrowRight size={16} />
                      </button>
                    </div>
                  ) : (
                    <>
                      <div className="context-subhead">
                        {buildPickerMode ? "HARİTADA YERLEŞTİR" : "YAPI İNŞA ET"}{" "}
                        <span>{formatNumber(snapshot.gold)} ALTIN</span>
                      </div>
                      <div className="build-list">
                        {BUILD_ORDER.map((type) => {
                          const Icon = BUILDING_ICONS[type];
                          const info = BUILDINGS[type];
                          const here = game.buildings.get(context.index);
                          const sameHere = !!here && here.owner === PLAYER_ID && here.type === type;
                          const upgradePrice = sameHere && here ? upgradeCost(here) : null;
                          const nextCost =
                            sameHere && upgradePrice !== null
                              ? upgradePrice
                              : getBuildingCost(type, snapshot.buildings[type]);
                          const maxed = sameHere && upgradePrice === null;
                          const placementError = buildPickerMode
                            ? ""
                            : getBuildingPlacementError(game, context.index, type, PLAYER_ID);
                          const unavailable = maxed || snapshot.gold < nextCost || !!placementError;
                          return (
                            <button
                              className="build-option"
                              key={type}
                              disabled={unavailable}
                              onClick={() => {
                                if (buildPickerMode) {
                                  setPlacingBuilding(type);
                                  setBuildPickerMode(false);
                                  setContext(null);
                                  notify(`${info.name} kurmak için toprağına tıkla.`);
                                  return;
                                }
                                const error = buildStructure(game, context.index, type);
                                if (error) notify(error);
                                else {
                                  playSound(720);
                                  notify(game.lastEvent);
                                  setContext(null);
                                }
                                refresh();
                              }}
                              title={placementError || info.description}
                            >
                              <span className="build-option-icon">
                                <Icon size={18} />
                              </span>
                              <span className="build-option-text">
                                <strong>
                                  {sameHere && here ? `${info.name} → Sv.${here.level + 1}` : info.name}
                                </strong>
                                <small>{sameHere ? "Aynı yere bas: seviye yükselt" : info.description}</small>
                              </span>
                              <span className="build-option-cost">
                            {maxed ? "MAX" : formatNumber(nextCost)}
                          </span>
                            </button>
                          );
                        })}
                      </div>
                      <div className="context-footer-actions">
                        <button
                          onClick={() => {
                            setPlacingBuilding(null);
                            const err = commandMove(game, PLAYER_ID, context.index);
                            if (err) notify(err);
                            refresh();
                            setContext(null);
                          }}
                        >
                          <Crown size={14} /> Komutanı Buraya Yürüt
                        </button>
                      </div>
                    </>
                  )}
                </>
              ) : (
                <div className="context-actions">
                  {selectedOwner === 0 || selectedRelation === "war" ? (
                    <button
                      onClick={() => {
                        const err = commandMove(game, PLAYER_ID, context.index);
                        if (err) notify(err);
                        else playSound(520);
                        refresh();
                        setContext(null);
                      }}
                    >
                      <Swords size={17} /> Komutanı Buraya Yürüt <ArrowRight size={16} />
                    </button>
                  ) : (
                    <button
                      className="context-war-btn"
                      disabled={selectedRelation === "truce"}
                      onClick={() => {
                        const err = declareWar(game, PLAYER_ID, selectedOwner);
                        if (err) {
                          notify(err);
                        } else {
                          const moveErr = commandMove(game, PLAYER_ID, context.index);
                          playSound(440);
                          notify(moveErr || game.lastEvent);
                        }
                        refresh();
                        setContext(null);
                      }}
                    >
                      <ShieldAlert size={17} />
                      {selectedRelation === "truce" ? "Ateşkes Sürüyor" : "Savaş İlan Et ve Sefer Başlat"}
                      <ArrowRight size={16} />
                    </button>
                  )}

                  {selectedOwner > 1 && selectedRelation === "war" && (
                    <button
                      onClick={() => {
                        const err = proposePeace(game, PLAYER_ID, selectedOwner);
                        notify(err || game.lastEvent);
                        refresh();
                        setContext(null);
                      }}
                    >
                      <Handshake size={17} /> Barış Teklif Et <ArrowRight size={16} />
                    </button>
                  )}

                  {selectedOwner > 1 && selectedRelation !== "war" && (
                    <button
                      onClick={() => {
                        notify(toggleAlliance(game, selectedOwner));
                        refresh();
                        setContext(null);
                      }}
                    >
                      <Users size={17} /> {selectedRelation === "alliance" ? "İttifakı Boz" : "İttifak Kur"}{" "}
                      <ArrowRight size={16} />
                    </button>
                  )}

                  {selectedOwner > 1 && selectedRelation === "peace" && (
                    <button
                      onClick={() => {
                        notify(signTruce(game, selectedOwner));
                        refresh();
                        setContext(null);
                      }}
                    >
                      <Shield size={17} /> Saldırmazlık Paktı <ArrowRight size={16} />
                    </button>
                  )}

                  {!!snapshot.buildings.port && (selectedOwner === 0 || selectedRelation === "war") && (
                    <button
                      onClick={() => {
                        const error = sendBoat(game, context.index);
                        notify(error || game.lastEvent);
                        refresh();
                        setContext(null);
                      }}
                    >
                      <Ship size={17} /> Donanma Çıkarması <ArrowRight size={16} />
                    </button>
                  )}

                  {!!snapshot.buildings.siegeworks && selectedRelation === "war" && (
                    <button
                      onClick={() => {
                        const error = bombardTarget(game, context.index);
                        notify(error || game.lastEvent);
                        refresh();
                        setContext(null);
                      }}
                    >
                      <Flame size={17} /> Mancınıkla Bombala (1.4K) <ArrowRight size={16} />
                    </button>
                  )}
                </div>
              )}
            </div>
          )}

          <AnimatePresence>
            {toast && (
              <motion.div
                className="game-toast"
                key={toast.key}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 7 }}
              >
                <span />
                {toast.text}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      )}

      <AnimatePresence mode="wait">
        {overlay === "setup" && (
          <Modal key="setup" wide onClose={() => setOverlay(null)} className="setup-modal">
            <ModalHeading
              kicker="YENİ SEFER"
              title="Savaş alanını seç."
              description="Geniş Avrupa haritasında krallığını kur, ordunu topla ve diplomasiyi yönet."
              onClose={() => setOverlay(null)}
            />
            <div className="setup-tabs">
              <button className={setupTab === "solo" ? "setup-tab--active" : ""} onClick={() => setSetupTab("solo")}>
                <Swords size={17} /> TEK OYUNCULU
              </button>
              <button className={setupTab === "online" ? "setup-tab--active" : ""} onClick={() => setSetupTab("online")}>
                <Users size={17} /> ÇOK OYUNCULU
              </button>
            </div>
            {setupTab === "solo" ? (
              <>
                <div className="setup-content">
                  <div className="form-label">
                    <span>01</span> HARİTA SEÇ
                  </div>
                  <div className="map-choices">
                    {MAP_IDS.map((id) => (
                      <button
                        className={`map-choice ${selectedMap === id ? "map-choice--selected" : ""}`}
                        key={id}
                        onClick={() => setSelectedMap(id)}
                      >
                        <div className="map-choice-image">
                          <MapThumbnail id={id} />
                          {selectedMap === id && (
                            <span className="map-check">
                              <Check size={13} strokeWidth={3} />
                            </span>
                          )}
                        </div>
                        <strong>{MAPS[id].name}</strong>
                      </button>
                    ))}
                  </div>
                  <div className="setup-two-columns">
                    <div className="setup-field">
                      <label className="form-label" htmlFor="commander-name">
                        <span>02</span> KRALLIK ADI
                      </label>
                      <input
                        id="commander-name"
                        className="text-input"
                        maxLength={20}
                        value={name}
                        onChange={(event) => setName(event.target.value)}
                        placeholder="Krallık adını yaz"
                      />
                    </div>
                    <div className="setup-field">
                      <div className="form-label">
                        <span>03</span> SANCAK RENGİ
                      </div>
                      <div className="color-choices">
                        {PLAYER_COLORS.map((option) => (
                          <button
                            key={option}
                            className={`color-choice ${color === option ? "color-choice--selected" : ""}`}
                            style={{ backgroundColor: option }}
                            onClick={() => setColor(option)}
                            aria-label={`Renk ${option}`}
                          >
                            {color === option && <Check size={17} strokeWidth={3} />}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                  <div className="setup-two-columns setup-bottom-fields">
                    <div className="setup-field">
                      <div className="form-label">
                        <span>04</span> ZORLUK
                      </div>
                      <div className="difficulty-choices">
                        {(["easy", "normal", "hard"] as Difficulty[]).map((value) => (
                          <button
                            key={value}
                            className={difficulty === value ? "difficulty--selected" : ""}
                            onClick={() => setDifficulty(value)}
                          >
                            {({ easy: "Kolay", normal: "Normal", hard: "Zor" })[value]}
                          </button>
                        ))}
                      </div>
                    </div>
                    <div className="setup-field">
                      <div className="form-label">
                        <span>05</span> RAKİP KRALLIKLAR <strong>{botCount}</strong>
                      </div>
                      <input
                        className="setup-range"
                        type="range"
                        min="14"
                        max="60"
                        step="1"
                        value={botCount}
                        onChange={(event) => setBotCount(Number(event.target.value))}
                        aria-label="Rakip sayısı"
                      />
                      <div className="range-ends">
                        <span>14 KRALLIK</span>
                        <span>60 KRALLIK</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="setup-footer">
                  <span>Önce barış dönemiyle başla; kışlalar kur, asker topla ve savaş ilan ederek fethet.</span>
                  <button className="button-primary" onClick={startNewGame}>
                    SEFERİ BAŞLAT <ArrowRight size={19} />
                  </button>
                </div>
              </>
            ) : (
              <div className="online-state">
                <div className="online-icon">
                  <Globe2 size={32} />
                </div>
                <h3>Dünyaya karşı oyna.</h3>
                <p>
                  Bu sürüm yerel tek oyunculu ortaçağ seferini içerir. Çevrimiçi eşleşme için resmi OpenFront sunucusunu açabilirsin.
                </p>
                <a href="https://openfront.io/" target="_blank" rel="noreferrer" className="button-primary">
                  RESMİ SUNUCUYU AÇ <ArrowUpRight size={19} />
                </a>
                <button className="online-back" onClick={() => setSetupTab("solo")}>
                  Yerel sefere dön
                </button>
              </div>
            )}
          </Modal>
        )}

        {overlay === "guide" && (
          <Modal key="guide" onClose={() => setOverlay(null)} wide className="guide-modal">
            <ModalHeading
              kicker="SEFER REHBERİ"
              title="Nasıl oynanır?"
              description="Savaş ilanı, meydan muharebesi, arkadanlama ve kale kuşatması."
              onClose={() => setOverlay(null)}
            />
            <div className="guide-steps">
              <div>
                <span>01</span>
                <Castle size={24} />
                <h3>Krallığını ve Ordunu Kur</h3>
                <p>Kasaba kapasitesini artır, yakınına kışla kur. Piyade eğitimi zaman alır ve askerler o kışlanın garnizonuna katılır.</p>
              </div>
              <div>
                <span>02</span>
                <Swords size={24} />
                <h3>Meydan Savaşı &amp; Arkadanlama</h3>
                <p>Savaş açtığında önce iki komutanın ordusu meydanda çarpışır. Düşman komutanı başka cephedeyse doğrudan kalelerine gir!</p>
              </div>
              <div>
                <span>03</span>
                <Crown size={24} />
                <h3>İkmal ve Deniz Ticareti</h3>
                <p>Savaş sırasında yeni kale kurulamaz; barışta ikmal hattını genişlet. Limanlar yalnızca açık denize bağlı kıyılara kurulur ve uzak rotalarda çok kazandırır.</p>
              </div>
            </div>
            <div className="guide-controls">
              <h3>KONTROLLER</h3>
              <div>
                <span>Sol tık</span>
                <strong>Komutanı yürüt / fethet</strong>
              </div>
              <div>
                <span>Sağ tık</span>
                <strong>Kale yükselt / yapı kur / savaş aç</strong>
              </div>
              <div>
                <span>R / B</span>
                <strong>Kışlada eğit / Yapı menüsü</strong>
              </div>
              <div>
                <span>W A S D</span>
                <strong>Haritada gezin</strong>
              </div>
              <div>
                <span>[ / ]</span>
                <strong>Sefer ordusu payını değiştir</strong>
              </div>
              <div>
                <span>1 – 6</span>
                <strong>Yapı seç, haritada yerleştir</strong>
              </div>
              <div>
                <span>Fare üstü</span>
                <strong>Krallığın altın, asker ve yapı bilgisi</strong>
              </div>
              <div>
                <span>C / P / Boşluk</span>
                <strong>Komutana odaklan / Duraklat / Arazi</strong>
              </div>
            </div>
            <div className="guide-buildings">
              <h3>YAPILAR VE TAM KATKILARI</h3>
              {BUILD_ORDER.map((type) => {
                const Icon = BUILDING_ICONS[type];
                return (
                  <div className="guide-building" key={type}>
                    <span className="guide-building-icon">
                      <Icon size={20} />
                    </span>
                    <div>
                      <strong>
                        {BUILDINGS[type].name} <em>{formatNumber(BUILDINGS[type].cost)} ◆</em>
                      </strong>
                      <ul>
                        {BUILDING_DETAILS[type].details.map((line) => (
                          <li key={line}>{line}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                );
              })}
              <p className="guide-economy-note">
                Genel kurallar: Asker topraktan gelmez; kışla seviyesi arttıkça eğitim daha hızlı ve daha kalabalık olur. Aynı yapıya tekrar basarak seviye yükseltebilirsin. Kapasite kasaba, kışla, kale ve liman seviyelerinden gelir. Meydan savaşlarında her tik 2'şer zar atılır.
                Yapı yerleştirirken fare imleci yeşilse kurulabilir, kırmızıysa nedeni haritada yazar.
              </p>
            </div>
            <div className="guide-footer">
              <span>Haritanın %68'ini ele geçirerek imparatorluk zaferi kazan.</span>
              <button
                className="button-primary"
                onClick={() => {
                  setSetupTab("solo");
                  setOverlay("setup");
                }}
              >
                SEFERE ÇIK <ArrowRight size={19} />
              </button>
            </div>
          </Modal>
        )}

        {overlay === "settings" && (
          <Modal key="settings" onClose={() => setOverlay(null)} className="settings-modal">
            <ModalHeading
              kicker="TERCİHLER"
              title="Ayarlar"
              description="Savaş haritası ve komutan kontrollerini düzenle."
              onClose={() => setOverlay(null)}
            />
            <div className="settings-group-title">GÖRÜNÜM</div>
            <div className="settings-row">
              <div>
                <strong>Krallık isimleri</strong>
                <span>Krallık adlarını harita üzerinde göster.</span>
              </div>
              <Toggle
                checked={settings.showNames}
                onChange={() => setSettings((value) => ({ ...value, showNames: !value.showNames }))}
              />
            </div>
            <div className="settings-row">
              <div>
                <strong>Koordinat ızgarası</strong>
                <span>Haritanın üstünde stratejik kareleme göster.</span>
              </div>
              <Toggle
                checked={settings.showGrid}
                onChange={() => setSettings((value) => ({ ...value, showGrid: !value.showGrid }))}
              />
            </div>
            <div className="settings-row">
              <div>
                <strong>Ses efektleri</strong>
                <span>Sefer, inşa ve savaş bildirim sesleri.</span>
              </div>
              <button
                className="settings-sound"
                onClick={() => setSettings((value) => ({ ...value, sound: !value.sound }))}
                aria-label={settings.sound ? "Sesi kapat" : "Sesi aç"}
              >
                {settings.sound ? <Volume2 size={20} /> : <VolumeX size={20} />}
              </button>
            </div>
            <div className="settings-row">
              <div>
                <strong>Otomatik genişleme</strong>
                <span>Komutan savaşmadığında yakındaki boş toprakları kendiliğinden alsın.</span>
              </div>
              <Toggle
                checked={settings.autoExpand}
                onChange={() => setAutoExpansion(!settings.autoExpand)}
              />
            </div>
            <div className="settings-group-title settings-group-title--second">ORDU</div>
            <div className="settings-slider-label">
              <span>Varsayılan komutan sefer payı</span>
              <strong>%{settings.defaultRatio}</strong>
            </div>
            <input
              className="setup-range"
              type="range"
              min="10"
              max="100"
              step="5"
              value={settings.defaultRatio}
              onChange={(event) => setSettings((value) => ({ ...value, defaultRatio: Number(event.target.value) }))}
              aria-label="Varsayılan komutan sefer payı"
            />
            <div className="settings-note">
              <CircleHelp size={17} /> Ayarlar bu tarayıcıda otomatik olarak kaydedilir.
            </div>
          </Modal>
        )}

        {overlay === "scores" && (
          <Modal key="scores" onClose={() => setOverlay(null)} className="scores-modal">
            <ModalHeading
              kicker="KRONİKLER"
              title="Zafer kayıtların"
              description="Bu tarayıcıda kazandığın seferler."
              onClose={() => setOverlay(null)}
            />
            {scores.length ? (
              <div className="score-list">
                {scores.map((score, index) => (
                  <div className="score-row" key={`${score.date}-${index}`}>
                    <span className="score-rank">{String(index + 1).padStart(2, "0")}</span>
                    <div>
                      <strong>{score.name}</strong>
                      <span>
                        {score.map} · {score.date}
                      </span>
                    </div>
                    <strong>%{score.percent}</strong>
                    <span>{formatTime(score.time)}</span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="scores-empty">
                <Trophy size={39} />
                <h3>İlk zaferin kroniklere yazılacak.</h3>
                <p>Bir seferi zaferle tamamla, krallığının adı burada yer alsın.</p>
                <button
                  className="button-primary"
                  onClick={() => {
                    setSetupTab("solo");
                    setOverlay("setup");
                  }}
                >
                  SEFER KUR <ArrowRight size={18} />
                </button>
              </div>
            )}
          </Modal>
        )}

        {!overlay && screen === "game" && game && snapshot && (paused || snapshot.phase === "won" || snapshot.phase === "lost") && (
          <Modal
            key={snapshot.phase === "playing" ? "paused" : snapshot.phase}
            onClose={() => {
              if (snapshot.phase === "playing") setPaused(false);
            }}
            className="pause-modal"
          >
            {snapshot.phase === "won" || snapshot.phase === "lost" ? (
              <div className="result-content">
                <div className={`result-icon ${snapshot.phase === "lost" ? "result-icon--lost" : ""}`}>
                  {snapshot.phase === "won" ? <Trophy size={34} /> : <Shield size={34} />}
                </div>
                <div className="section-kicker">{snapshot.phase === "won" ? "ZAFER" : "YENİLGİ"}</div>
                <h2>{snapshot.phase === "won" ? "Kıta senin önünde diz çöktü." : "Kalelerin düştü."}</h2>
                <p>
                  {snapshot.phase === "won"
                    ? "Tüm rakiplerini aştın ve büyük bir imparatorluk kurdun."
                    : "Sancak düştü. Yeni bir strateji ve daha güçlü kalelerle yeniden sefere çık."}
                </p>
                <div className="result-stats">
                  <div>
                    <span>TOPRAK</span>
                    <strong>%{snapshot.percent.toFixed(1)}</strong>
                  </div>
                  <div>
                    <span>SÜRE</span>
                    <strong>{formatTime(snapshot.tick)}</strong>
                  </div>
                </div>
                <button className="button-primary result-primary" onClick={startNewGame}>
                  <RotateCcw size={18} /> YENİDEN SEFER
                </button>
                <button className="pause-secondary" onClick={returnHome}>
                  Ana menüye dön
                </button>
              </div>
            ) : (
              <div className="pause-content">
                <BrandMark className="pause-emblem" />
                <div className="section-kicker">SEFER DURAKLATILDI</div>
                <h2>Bir nefes al.</h2>
                <p>Orduların ve kalelerin bekliyor. Hazır olduğunda kaldığın yerden devam et.</p>
                <button className="button-primary pause-primary" onClick={() => setPaused(false)}>
                  <Play size={18} fill="currentColor" /> DEVAM ET
                </button>
                <button className="pause-option" onClick={() => openOverlay("settings")}>
                  <Settings2 size={18} /> Ayarlar <ChevronRight size={17} />
                </button>
                <button className="pause-option" onClick={startNewGame}>
                  <RotateCcw size={18} /> Yeniden başlat <ChevronRight size={17} />
                </button>
                <button className="pause-option" onClick={returnHome}>
                  <Globe2 size={18} /> Ana menüye dön <ChevronRight size={17} />
                </button>
              </div>
            )}
          </Modal>
        )}
      </AnimatePresence>
    </div>
  );
}
